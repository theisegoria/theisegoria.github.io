Integrated Medical Foundations
Module 017-02: chapter 17, TTS module 2

  English : Glomerular Filtration, Tubular Transport, Concentration, and Clearance
            TTS module 2: Glomerular haemodynamics, tubular energetics, and renal diagnostic patterns
  日本語   : 糸球体濾過、尿細管輸送、尿濃縮、クリアランス
            TTSモジュール2：糸球体血行動態、尿細管エネルギー、そして腎診断パターン

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  b9e77b98c8bc7464d595944cfc3cf9977d51fc52800e335e821634c841e7397b
  日本語    be0f8731e58cfd5ee3026284f1020d8e8a6397065dc43b31e70d1f8d9bcaf695

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
