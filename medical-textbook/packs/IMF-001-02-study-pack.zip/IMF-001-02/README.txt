Integrated Medical Foundations
Module 001-02: chapter 1, TTS module 2

  English : Homeostasis, Cellular Energetics, and Physiological Reserve
            TTS module 2: Control systems, energy failure, and hidden reserve
  日本語   : ホメオスタシス、細胞エネルギー学、そして生理学的予備能
            TTSモジュール2：制御系、エネルギー破綻、そして隠れた予備能

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_English_01-2_Homeostasis_and_Physiological_Reserve.mp3
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_Japanese_01-2_ホメオスタシスと生理学的予備能.mp3

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  b19010ccf07115be061f9a03a752375a9ce52157faa84471e5bf0ccc547b0fa0
  日本語    86d25e12c24bf8ac9fa507446c10740cf8307c7821ac7ab47715e06434c5959d

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
