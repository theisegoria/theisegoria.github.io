Integrated Medical Foundations
Module 006-02: chapter 6, TTS module 2

  English : Clinical Reasoning, History, Examination, and Diagnostic Probability
            TTS module 2: Bayesian updating, decision thresholds, and diagnostic safety
  日本語   : 臨床推論、病歴、診察、そして診断確率
            TTSモジュール2：ベイズ更新、意思決定閾値、そして診断安全性

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  dba09072c4d938db627ddcbc2607b770711d3ff15ae1b730fbf7f9762875162d
  日本語    4842ee4f9830e917edcdf221af57194be4a1bfd3f1a95a1536de81d7a0a8463b

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
