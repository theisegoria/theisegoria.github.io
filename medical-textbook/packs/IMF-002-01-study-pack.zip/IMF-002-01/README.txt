Integrated Medical Foundations
Module 002-01: chapter 2, TTS module 1

  English : Membranes, Signalling, and Excitable Cells
            TTS module 1: Foundations
  日本語   : 膜、シグナル伝達、興奮性細胞
            TTSモジュール1：基礎

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_English_02-1_Membranes_Signalling_and_Excitable_Cells.mp3
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_Japanese_02-1_膜シグナル伝達興奮性細胞.mp3

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  1166bd3bfef580b29dfcfc623eb4031de6cb5ebeead3e1516d6a1bf3e2dab0a7
  日本語    3a14865eaf3364850ccfeba4bb1c5f3881bb0ad019f1602f2d0c20fa196b8bbb

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
