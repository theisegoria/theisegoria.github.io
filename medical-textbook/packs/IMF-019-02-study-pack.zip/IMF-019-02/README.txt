Integrated Medical Foundations
Module 019-02: chapter 19, TTS module 2

  English : Acid-Base Physiology and Clinical Interpretation
            TTS module 2: Quantitative compensation, hidden mixtures, and acid-base treatment traps
  日本語   : 酸塩基生理学と臨床的解釈
            TTSモジュール2：定量的代償、隠れた混合、そして酸塩基治療の落とし穴

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  f84635f2d747d94bd6530a6e1cfffc0058ac459ca86b2388bcaf7e3267f40b48
  日本語    4c8fcede2ea1a520ff210cc0f6e1019ed860ab0d0eca9d0cdb08b7f32a1d509b

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
