Integrated Medical Foundations
Module 018-01: chapter 18, TTS module 1

  English : Sodium, Water, Potassium, and Volume Regulation
            TTS module 1: Foundations
  日本語   : ナトリウム、水、カリウム、体液量の調節
            TTSモジュール1：基礎

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  2c64fd063237bb4cb850701dfcf0439ad08d9dbfe86ebbbe89546802513e7136
  日本語    09328a3965f0a2fa1bb335d54145bb587a6a24381ccbbe465dc3b3c7d69dab0e

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
