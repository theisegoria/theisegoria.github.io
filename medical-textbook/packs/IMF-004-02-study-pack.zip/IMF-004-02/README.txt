Integrated Medical Foundations
Module 004-02: chapter 4, TTS module 2

  English : Inflammation, Healing, Immunity, and Infection
            TTS module 2: Resolution, immune architecture, and repair under stress
  日本語   : 炎症、治癒、免疫、および感染
            TTSモジュール2：炎症の収束、免疫構築、そしてストレス下の修復

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_English_04-2_Inflammation_Healing_Immunity_and_Infection.mp3
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_Japanese_04-2_炎症治癒免疫および感染.mp3

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  4f1b6eebf99962c513578d79d5521d11d6c61b3c394c023f72dd0c0ac2c5a336
  日本語    c0fc3080a3c67bbc80afc7815dea865bd1492767b2d9ed3fcaace6f47a16cca6

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
