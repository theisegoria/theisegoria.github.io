Integrated Medical Foundations
Module 015-02: chapter 15, TTS module 2

  English : Obstructive, Restrictive, Vascular, Infectious, and Neoplastic Lung Disease
            TTS module 2: Respiratory phenotypes, progression mechanisms, and treatment selection
  日本語   : 閉塞性、拘束性、血管性、感染性、腫瘍性肺疾患
            TTSモジュール2：呼吸器表現型、進行機序、そして治療選択

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  e780d7dff20e8b556d35b8d39b236d1ba4d9d37ea4161dd0da9dc35af3f15efe
  日本語    87f9d0a7cd45c248a75d18876483697d6838e9439cbe4bed6a0447d468fdc842

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
