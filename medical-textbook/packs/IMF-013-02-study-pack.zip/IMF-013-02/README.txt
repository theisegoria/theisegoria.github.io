Integrated Medical Foundations
Module 013-02: chapter 13, TTS module 2

  English : Ventilation, Perfusion, Diffusion, and Gas Transport
            TTS module 2: Alveolar gas reasoning, shunt behaviour, and oxygen-delivery traps
  日本語   : 換気、灌流、拡散、ガス運搬
            TTSモジュール2：肺胞気推論、シャント挙動、そして酸素供給の落とし穴

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  28db2195aa76b456df8e467ce36aff479f5540d17db4c7e2d9af907b4001a4d3
  日本語    48e76fc0a9d4fdd73c003953d91b5cc849eb732aa1138c4637fa86da4ff41006

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
