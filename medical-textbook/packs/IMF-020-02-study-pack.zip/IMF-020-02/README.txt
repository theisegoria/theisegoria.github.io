Integrated Medical Foundations
Module 020-02: chapter 20, TTS module 2

  English : Acute Kidney Injury, Chronic Kidney Disease, and Renal Pharmacology
            TTS module 2: Kidney injury phenotypes, recovery trajectories, and replacement decisions
  日本語   : 急性腎傷害、慢性腎臓病、腎薬理学
            TTSモジュール2：腎傷害表現型、回復軌跡、そして腎代替の決定

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    Not recorded for this module yet.

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  730abd69efc1ba2f4e35d336761b4cac2ac3298e57aa5a4f6f210bd448031b09
  日本語    e44198e018c292e7940ae96378ac8736fe3ee35f20f8c0e23d4058d583e64d5b

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
