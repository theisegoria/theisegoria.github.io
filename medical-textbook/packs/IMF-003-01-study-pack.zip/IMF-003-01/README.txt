Integrated Medical Foundations
Module 003-01: chapter 3, TTS module 1

  English : Genes, Proteins, Adaptation, Injury, and Cell Death
            TTS module 1: Foundations
  日本語   : 遺伝子、タンパク質、適応、傷害、細胞死
            TTSモジュール1：基礎

WHAT IS IN THIS PACK

  text/      The module's own Markdown, exactly as it appears in the published
             master manuscripts.
  mindmap/   The same module as a mindmap. Open the PDF to print or read it,
             the PNG to drop into slides or notes, the SVG to scale it into a
             document, or the OPML in MindNode, XMind, iThoughts or Freeplane
             to edit it. The .md outline is the source all of them are built
             from: headings are nodes, and heading depth is node depth.
  anki/      Retrieval cards. Import the .apkg directly, or the .tsv if you want
             to map the fields yourself. English and Japanese are separate
             decks; the note IDs carry a language suffix and are stable across
             releases, so re-importing updates notes rather than duplicating
             them.

WHAT IS NOT IN IT

  Narration. The MP3s run to tens of megabytes each, so they are linked rather
  than packed:
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_English_03-1_Genes_Proteins_Adaptation_Injury_and_Cell_Death.mp3
    https://theisegoria.github.io/medical-textbook/audio/ElevenLabs_IMF_Japanese_03-1_遺伝子タンパク質適応傷害細胞死.mp3

  Review. Nothing here has had independent scientific or translation review, and
  the Anki imports have not yet been tested in the Anki application itself. This
  is study material written by a medical student, not clinical guidance.

SOURCE FINGERPRINTS

  Every file in this pack was built from these two manuscript modules. If a
  digest below no longer matches the published master, the master has been
  revised since this pack was built.

  English  f9ffbfb705bb39cf840463c25ea0f9f5a2e1331e9cd731a5adf9b94c4213ddf7
  日本語    232ef804d415725a3c128c5f8908b1df9b3c24f77afe702b7d7a140e9577f52c

  Masters: https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-english.md
           https://theisegoria.github.io/medical-textbook/integrated-medical-foundations-expanded-japanese.md

Built 2026-09-15. https://theisegoria.github.io/medical-textbook/
