# Cold, explained — refrigerator lab

Bilingual English/Japanese educational site with an original orbitable Three.js refrigerator, four-stage refrigerant circuit, heat-balance experiment, thermostat response, support-system explanations and primary references.

## Build

Node.js with npm. Run `npm ci`, `npm run build`, then serve `dist/` with any static HTTP server. English entry point: `/`; Japanese: `/ja/` (or `?lang=ja`). Deployment under a subdirectory is supported. Run `npm test` for bounded numerical checks.

Source files are in `src/`. Scientific assumptions and provenance are documented in `MODEL_SOURCES.md`. Third-party license text remains in the generated bundle's companion LICENSE text.

## Verification

Actual browser rendering inspected in the Codex browser on desktop and at a 390-pixel viewport (375-pixel content width). English/Japanese navigation, stage changes, circuit view, door controls, pause/reset and parameter/thermostat controls checked. Parameter tests cover 243 combinations; thermostat step-size comparison uses 1 s and 0.25 s. No claim of physical-device performance testing or measured appliance accuracy.

A WebGL-unavailable fallback preserves the diagrams and experiments. Reduced-motion preference stops automatic flow playback. Frame time steps are bounded; offscreen/hidden animation pauses. Resource sizes and pixel ratio are bounded. This is a generic teaching model, not a brand-specific CAD model, fluid solver or energy label prediction.
