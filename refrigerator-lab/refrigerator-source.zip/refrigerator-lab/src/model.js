export function energy({room=25,freezer=-18,doors=12,insulation=1,vent=0}={}){
 const fridge=4,evap=freezer-7,cond=room+10+vent*15;
 const carnot=(evap+273.15)/(cond-evap),cop=.36*carnot;
 const conduction=(.6*(room-fridge)+.3*(room-freezer))/insulation;
 const infiltration=doors*1800/86400;
 const load=conduction+infiltration+4;
 const capacity=110*cop;
 const duty=Math.min(1,load/capacity);
 const work=load/cop;
 return {evap,cond,carnot,cop,conduction,infiltration,load,work,heat:load+work,duty,kwh:(work+3)*24/1000,capacity};
}
export function thermostat({room=25,door=false,dt=1}={}){
 let t=4,on=false;const samples=[];let switches=0;
 for(let s=0;s<=21600;s+=dt){
  if(t>=5&&!on){on=true;switches++} if(t<=3&&on){on=false;switches++}
  const added=door&&s>=7200&&s<7500?180:0;
  t+=(1.2*(room-t)+added-(on?105:0))*dt/9000;
  if(Math.abs(s/60-Math.round(s/60))<1e-8)samples.push({hours:s/3600,temp:t,on});
 }
 return {samples,switches};
}
