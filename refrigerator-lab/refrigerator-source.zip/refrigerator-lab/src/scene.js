import * as T from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
export function createScene(container,state,onSelect){
 const renderer=new T.WebGLRenderer({antialias:true,alpha:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0x000000,0);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;
 container.prepend(renderer.domElement);renderer.domElement.setAttribute('aria-label','Orbitable refrigerator teaching model');renderer.domElement.setAttribute('role','img');
 const scene=new T.Scene();const pmrem=new T.PMREMGenerator(renderer),environment=new RoomEnvironment();const env=pmrem.fromScene(environment,.04);scene.environment=env.texture;environment.dispose();pmrem.dispose();
 scene.add(new T.HemisphereLight(0xe7f5ff,0xa6a6a6,2.2));const key=new T.DirectionalLight(0xffffff,3);key.position.set(3,5,4);scene.add(key);
 const camera=new T.PerspectiveCamera(34,1,.05,50);const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=false;controls.enablePan=false;controls.minDistance=2.5;controls.maxDistance=8;controls.maxPolarAngle=Math.PI*.86;controls.target.set(0,1,0);controls.touches.ONE=T.TOUCH.ROTATE;controls.touches.TWO=T.TOUCH.DOLLY_PAN;
 const root=new T.Group();scene.add(root);const shell=new T.Group(),doors=new T.Group(),hardware=new T.Group();root.add(shell,doors,hardware);
 const mat=(color,metalness=0,roughness=.5)=>new T.MeshStandardMaterial({color,metalness,roughness});
 const white=mat('#e7edf0',.25,.3),liner=mat('#f6fafb',.05,.55),steel=mat('#a4b2bc',.85,.28),dark=mat('#252e32',.4,.42),rubber=mat('#535f64',0,.85),glass=new T.MeshPhysicalMaterial({color:'#bedee0',transparent:true,opacity:.5,roughness:.16,metalness:.1,depthWrite:false});
 const colors=['#d27635','#c34527','#ba9860','#007eaa'];const componentMats=colors.map(c=>mat(c,.42,.32));const picks=[];
 function box(parent,size,pos,material,r=.014){const mesh=new T.Mesh(new RoundedBoxGeometry(...size,3,r),material);mesh.position.set(...pos);parent.add(mesh);return mesh}
 function cylinder(parent,r,h,pos,material){const mesh=new T.Mesh(new T.CylinderGeometry(r,r,h,32),material);mesh.position.set(...pos);parent.add(mesh);return mesh}
 function tube(parent,points,r,material,stage){const curve=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p)),false,'centripetal');const mesh=new T.Mesh(new T.TubeGeometry(curve,Math.max(32,points.length*8),r,8,false),material);parent.add(mesh);if(stage!==undefined){mesh.userData.stage=stage;picks.push(mesh)}return curve}
 // Generic 0.78 × 1.88 × 0.72 m top-freezer enclosure, no branded dimensions.
 box(shell,[.78,.07,.72],[0,.2,0],steel);box(shell,[.78,.07,.72],[0,2.02,0],white);box(shell,[.07,1.78,.72],[-.355,1.11,0],white);box(shell,[.07,1.78,.72],[.355,1.11,0],white);box(shell,[.65,1.72,.055],[0,1.11,-.326],liner);box(shell,[.64,.08,.65],[0,1.45,.012],liner);
 // Inner rounded lining strips, shelf lips, crisper drawers, freezer shelf.
 for(const x of [-.31,.31])box(shell,[.014,1.14,.61],[x,.86,0],liner,.006);
 for(const y of [.53,.86,1.16,1.73]){box(shell,[.62,.014,.54],[0,y,.012],glass,.004);box(shell,[.63,.022,.024],[0,y,.28],steel,.003);for(const x of [-.3,.3])box(shell,[.025,.025,.47],[x,y-.018,.01],liner,.003)}
 box(shell,[.60,.19,.48],[0,.37,.03],glass,.025);box(shell,[.59,.03,.49],[0,.47,.03],liner,.004);
 for(const x of [-.29,.29])for(const z of [-.25,.25])cylinder(shell,.036,.08,[x,.125,z],rubber);
 // Vented freezer evaporator cover; visible cold coil when cabinet is cut away.
 for(let i=0;i<9;i++)box(shell,[.25,.01,.02],[-.08,1.58+i*.033,-.28],steel,.003);
 const fan=new T.Group();fan.position.set(.19,1.80,-.258);shell.add(fan);const hub=new T.Mesh(new T.SphereGeometry(.025,16,12),steel);fan.add(hub);
 for(let i=0;i<5;i++){const blade=box(fan,[.029,.12,.012],[0,.055,0],steel,.009);const g=new T.Group();g.add(blade);g.rotation.z=i*Math.PI*2/5;fan.add(g)}
 // Hinged doors with gasket, liner, bins and metal handles, correct shared pivots.
 const hinges=[];for(const [bottom,top] of [[.245,1.405],[1.49,2.04]]){
  const pivot=new T.Group();pivot.position.set(-.383,bottom,.385);doors.add(pivot);hinges.push(pivot);const h=top-bottom,cx=.383;
  box(pivot,[.775,h,.073],[cx,h/2,0],steel,.033);box(pivot,[.719,h-.055,.018],[cx,h/2,-.045],rubber,.017);box(pivot,[.685,h-.087,.017],[cx,h/2,-.060],liner,.02);
  box(pivot,[.024,h*.6,.044],[.695,h*.51,.058],steel,.012);
  for(const y of (h>.8?[.17,.52,.91]:[.13])){box(pivot,[.56,.115,.084],[cx,y,-.108],glass,.012);box(pivot,[.57,.02,.1],[cx,y-.056,-.11],liner,.006)}
 }
 // Exposed rear condenser, connections and low-pressure freezer evaporator.
 const compressorMat=mat('#252e32',.4,.42);const compressor=cylinder(hardware,.135,.22,[-.18,.37,-.41],compressorMat);const cap=new T.Mesh(new T.SphereGeometry(.135,32,20),compressorMat);cap.scale.y=.63;cap.position.set(-.18,.48,-.41);hardware.add(cap);compressor.userData.stage=0;cap.userData.stage=0;picks.push(compressor,cap);
 for(const x of [-.29,-.07])box(hardware,[.055,.04,.23],[x,.245,-.41],rubber,.007);
 box(hardware,[.08,.10,.08],[-.03,.36,-.41],dark,.014);
 const condenser=[[-.18,.51,-.42],[-.18,.58,-.46],[-.30,.62,-.46]];for(let i=0;i<13;i++){let y=.64+i*.09;let end=i%2===0?.30:-.30;condenser.push([end,y,-.46],[end,y+.042,-.46])}condenser.push([.30,1.88,-.46],[.33,1.88,-.46],[.33,.49,-.46]);
 const ccurve=tube(hardware,condenser,.012,componentMats[1],1);for(let i=0;i<17;i++)box(hardware,[.004,1.18,.006],[-.28+i*.035,1.23,-.448],dark,.001);
 const drier=cylinder(hardware,.027,.17,[.30,.40,-.46],componentMats[2]);drier.userData.stage=2;picks.push(drier);
 const capillary=[[.33,.49,-.46],[.30,.49,-.46],[.30,.31,-.46]];for(let i=0;i<=80;i++){let t=i/80*Math.PI*10;capillary.push([.16+Math.cos(t)*.045,.34+Math.sin(t)*.045,-.46+i*.0008])}capillary.push([.10,.5,-.395],[.10,1.55,-.395],[-.26,1.55,-.395]);const tcurve=tube(hardware,capillary,.004,componentMats[2],2);
 const evaporator=[[-.26,1.55,-.395],[-.26,1.55,-.25]];for(let i=0;i<6;i++){let x=i%2?.27:-.27,y=1.58+i*.065;evaporator.push([x,y,-.25],[-x,y,-.25],[-x,y+.03,-.25])}evaporator.push([.28,1.94,-.25],[.34,1.94,-.38],[.34,.56,-.38],[-.20,.56,-.38],[-.20,.49,-.38]);const ecurve=tube(hardware,evaporator,.012,componentMats[3],3);
 // Fin plates give the evaporator real depth and surface-area structure.
 const fins=new T.Group();hardware.add(fins);for(let i=0;i<18;i++)box(fins,[.005,.37,.063],[-.25+i*.03,1.77,-.25],mat('#77aebc',.55,.4),.001);
 const flowCurves=[ccurve,tcurve,ecurve];const markers=[];for(let c=0;c<3;c++)for(let i=0;i<12;i++){let m=new T.Mesh(new T.SphereGeometry(c===1?.008:.016,10,8),new T.MeshBasicMaterial({color:c===2?'#b7f6ff':'#ffe2ad'}));hardware.add(m);markers.push({mesh:m,curve:flowCurves[c],offset:i/12})}
 // Floor with subtle contact impression.
 const floor=new T.Mesh(new T.CircleGeometry(.85,64),new T.MeshBasicMaterial({color:'#667d86',transparent:true,opacity:.1,depthWrite:false}));floor.rotation.x=-Math.PI/2;floor.position.y=.081;scene.add(floor);
 const labels=new T.Group();root.add(labels);for(const [i,pos] of [[0,[-.38,.39,-.48]],[1,[-.41,1.15,-.48]],[2,[.41,.38,-.48]],[3,[-.41,1.81,-.39]]]){const cv=document.createElement('canvas');cv.width=cv.height=128;const ctx=cv.getContext('2d');ctx.fillStyle='#123541';ctx.beginPath();ctx.arc(64,64,52,0,Math.PI*2);ctx.fill();ctx.fillStyle='white';ctx.font='bold 44px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('0'+(i+1),64,66);const texture=new T.CanvasTexture(cv);texture.colorSpace=T.SRGBColorSpace;const sprite=new T.Sprite(new T.SpriteMaterial({map:texture,depthTest:false}));sprite.position.set(...pos);sprite.scale.set(.12,.12,1);sprite.renderOrder=20;labels.add(sprite)}
 let mode='inside';function frame(view){mode=view;labels.visible=view==='circuit';const narrow=container.clientWidth<550;const d=narrow?1.17:1;const presets={inside:[2.65,2.35,3.2],exterior:[2.6,2.25,3.65],rear:[-2.1,2.25,-3.4],circuit:[1.9,2.1,-3.3]};let p=presets[view]||presets.inside;camera.position.set(p[0]*d,(p[1]-1)*d+1,p[2]*d);controls.target.set(0,1.06,0);shell.visible=view!=='circuit';doors.visible=view!=='circuit';floor.visible=view!=='circuit';controls.update();draw()}
 let raf=0,last=0,progress=0,visible=true;
 function update(){compressorMat.emissive.set(0xe08b38);compressorMat.emissiveIntensity=state.stage===0?.2:0;hinges.forEach(h=>h.rotation.y=-state.door/100*Math.PI*.64);componentMats.forEach((m,i)=>{m.emissive.set(colors[i]);m.emissiveIntensity=state.stage===i?.3:0});fins.visible=mode==='rear'||mode==='circuit';markers.forEach(m=>m.mesh.position.copy(m.curve.getPointAt((progress+m.offset)%1)));fan.rotation.z=progress*40;}
 function draw(){update();renderer.render(scene,camera);container.dataset.renderer='webgl';}
 function animate(now){raf=0;if(!visible)return;if(state.playing){progress=(progress+Math.max(0,Math.min((now-last)/1000,.05))*.10)%1;draw();raf=requestAnimationFrame(animate)}last=now}
 function refresh(){draw();if(state.playing&&visible&&!raf){last=performance.now();raf=requestAnimationFrame(animate)}}
 function resize(){const w=container.clientWidth,h=container.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();draw()}
 controls.addEventListener('change',draw);const observer=new ResizeObserver(resize);observer.observe(container);
 const vis=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting&&!document.hidden;if(visible)refresh();else if(raf){cancelAnimationFrame(raf);raf=0}});vis.observe(container);
 document.addEventListener('visibilitychange',()=>{visible=!document.hidden;if(visible)refresh();else if(raf){cancelAnimationFrame(raf);raf=0}});
 const ray=new T.Raycaster(),pointer=new T.Vector2();let down;renderer.domElement.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(root.children,true).find(h=>h.object.visible);if(hit?.object.userData.stage!==undefined)onSelect(hit.object.userData.stage)});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();container.dataset.renderer='lost';cancelAnimationFrame(raf)});renderer.domElement.addEventListener('webglcontextrestored',refresh);
 frame('inside');resize();refresh();return {frame,refresh,renderer,camera,scene};
}
