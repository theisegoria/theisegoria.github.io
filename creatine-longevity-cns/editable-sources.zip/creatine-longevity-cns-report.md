# Creatine, longevity and the central nervous system
## Plausible mechanisms, human evidence and the limits of translation
Research brief | 19 September 2026

### The answer
Creatine is a biologically credible way to support cellular energy buffering. Its strongest practical case for healthy aging is as an adjunct to resistance exercise, with evidence for additional strength and lean-tissue gains. Selected cognitive and mood benefits are plausible, especially when energy supply is challenged. **Human lifespan extension, dementia prevention and general neurodegenerative disease modification remain unproven.** [1-4,7-13]

The distinction is consequential: an intervention can improve a short-term task or strengthen muscle without slowing the underlying rate of aging. This report uses longevity to mean survival, healthspan to mean preserved health and function, and CNS effects to include cognition, mood and neurological disease. These endpoints are not interchangeable.

### Evidence at a glance
| Claim | Best evidence considered here | Calibrated conclusion |
|---|---|---|
| More usable energy reserve | Established creatine kinase chemistry; human brain spectroscopy | Strong mechanism; variable brain uptake [1,2] |
| Better aging-related physical capacity | Controlled resistance-training studies | Supported adjunct; falls and survival are separate questions [3,20] |
| Better cognition during sleep loss | Small randomized crossover trials | Promising, context-specific signal [7,8] |
| Everyday cognitive enhancement | Mixed placebo-controlled studies | Small benefit possible; dependable broad improvement not established [9,10] |
| Antidepressant augmentation | Small randomized adjunctive trials | Promising; not established monotherapy [11,12] |
| Alzheimer disease treatment | Uncontrolled target-engagement pilot | Feasible; efficacy unproven [13] |
| Longer human life | Animal experiment and human dietary association | No causal human survival evidence identified [4,5] |

### How to read the diagrams
Solid connections describe established biochemical steps or findings within the tested setting. Dashed connections describe plausible extensions that require additional evidence. Neither arrow thickness nor position represents an effect size. Qualitative judgments are this report's synthesis, not formal GRADE ratings.

### Most defensible interpretation
Creatine may help maintain functional reserve: the capacity to meet physical or mental demands despite stress or aging. That is a useful research hypothesis and, for muscle, a practical training application. It is a substantially narrower claim than a general anti-aging treatment.

**Disclosure context:** some creatine publications report manufacturer relationships or related patents, including the mortality analysis and safety synthesis. These do not invalidate results, but strengthen the case for independent replication and assessment of the actual methods. [5,23]

<!-- PAGE -->
# 1. The mechanistic core
### A rechargeable phosphate buffer
ATP is the immediate energy currency used by cellular machinery. Creatine kinase reversibly transfers a phosphate between ATP and creatine: **phosphocreatine + ADP + H+ <=> creatine + ATP**. When demand suddenly increases, phosphocreatine can rapidly regenerate ATP. When ATP production catches up, the reserve is recharged. This redistributes and buffers energy; it does not generate energy from nothing. [2,9]

Conceptual figure: ATP production -> phosphocreatine reserve -> ATP use. The reserve recharges as ATP becomes available.

### Why this could matter in the brain
Neurons need energy for ion gradients, signalling and recovery after firing. A larger accessible reserve could help sustain these processes when ATP supply temporarily lags demand. Preserving ion-pump function could, in principle, limit calcium overload and excitotoxic injury. This is a mechanistic inference, supported by experimental neuroprotection, rather than evidence that ordinary supplementation prevents neuronal loss in humans. [2,6]

### Delivery is a biological bottleneck
Creatine is both synthesized in the body and obtained from food. Brain availability depends on local metabolism and transport, including SLC6A8; blood concentrations do not directly specify neuronal concentrations. Dechent et al. measured an average 8.7% rise in brain total creatine in six volunteers after 20 g/day for four weeks. This demonstrates possible target engagement, not a universal uptake rate. [1]

Magnetic resonance spectroscopy measures tissue-level metabolites. Total creatine includes free creatine and phosphocreatine; a higher signal does not, by itself, demonstrate faster ATP flux, healthier mitochondria or improved cognition. Region, measurement method, dose, duration and baseline state can all affect interpretation. [1,7,13]

### Mechanisms beyond ATP buffering
**Redox protection.** Laboratory assays found selective scavenging of reactive species, but not a broad effect against hydrogen peroxide or lipid peroxidation. Direct antioxidant activity is plausible; its contribution at achievable human brain concentrations is uncertain. [14]

**Mitochondrial stability.** Preserving energy balance could reduce downstream injury. Yet a mouse experiment retained creatine's neuroprotection even without ubiquitous mitochondrial creatine kinase, weakening the claim that protection must operate through that enzyme's control of mitochondrial pore opening. Multiple mechanisms may coexist. [2]

**Methyl-group sparing.** Endogenous synthesis uses a methylation step. Supplementation can suppress synthesis, potentially reducing methyl-group demand. A randomized trial reduced guanidinoacetate but did not lower homocysteine with creatine alone. Sparing synthesis is not demonstrated epigenetic rejuvenation. [15]

<!-- PAGE -->
# 2. Longevity: plausible routes, missing endpoints
### The strongest route is indirect
Resistance exercise repeatedly taxes the phosphocreatine system. Supporting training performance could improve the stimulus for retaining strength and muscle, helping preserve daily function. In a 14-week randomized study of 28 adults over 65, creatine added to training improved several strength and body-composition outcomes beyond placebo. This establishes an adjunctive physical benefit in that setting; it does not establish fewer fractures, less disability or longer survival. [3]

Lean tissue is also not synonymous with newly built contractile muscle. In a 2025 randomized study, a seven-day creatine phase before training increased measured lean body mass by about 0.5 kg; subsequent training did not show an additional between-group advantage. Water-related changes can inflate apparent early tissue gains. Functional measures therefore matter alongside body composition. [20]

Conceptual figure: energy buffering -> strength with training --(unproven human link)--> longer life.

### What the mouse longevity result actually says
Bender et al. studied 162 aged mice and reported a 9% higher median **healthy lifespan**, alongside better neurobehavioral performance and less brain lipofuscin. The abstract reports a trend toward lower reactive oxygen species, not a confirmed reduction. The healthy-lifespan endpoint should not be casually relabelled maximum lifespan or converted into extra human years. One strain and experimental environment provide a hypothesis, not a human effect estimate. [4]

### Human associations do not settle causality
A 2025 NHANES analysis followed 4,041 adults, with 858 deaths over a median 19.8 years. Intake estimated from a single dietary recall showed a borderline association for at least 1 g/day versus less: hazard ratio 0.85, 95% CI 0.72-1.00. The association weakened with demographic and lifestyle adjustment. Diet quality, protein intake, socioeconomic conditions and health status can confound such relationships. Food-derived exposure is not a randomized supplement intervention; the cutoff is not an established longevity dose. [5]

### Additional routes worth testing
**Metabolic health:** In 25 people with type 2 diabetes undergoing exercise, 5 g/day for 12 weeks improved HbA1c and muscle GLUT4 translocation. This supports a possible glucose-handling pathway in a specific population, not prevention of cardiovascular events or diabetes in healthy adults. [16]

**Lower cumulative neural injury:** Better buffering during stress might reduce downstream damage over years. However, demonstrating less fatigue today is not demonstrating fewer neurons lost later. Large disease trials offer a direct warning against assuming that this extrapolation works. [17,18]

**Aging pathways:** This search did not establish human evidence that creatine clears senescent cells, restores telomeres, reliably enhances autophagy or reverses biological aging. These claims require direct intervention evidence, not an inference from ATP metabolism or a biomarker association.

<!-- PAGE -->
# 3. Cognition and mental fatigue
### Acute stress is the most coherent test of the mechanism
If buffering is helpful principally when energy demand exceeds supply, benefits should be easier to detect during sleep loss or other metabolic stress than during well-rested everyday performance. That prediction is plausible, but differences between populations must be tested rather than assumed.

**2024 sleep-deprivation trial:** Fifteen adults completed a placebo-controlled crossover experiment using a single 0.35 g/kg dose during 21 hours awake. Selected cognitive outcomes improved and spectroscopy detected altered cerebral energy metabolites. The sample was small and the exposure acute; it does not establish protection from the long-term harms of poor sleep. [7]

**2026 follow-up:** Twenty-nine young adults received 0.2 g/kg or placebo in a randomized crossover experiment. Results suggested modest attenuation of performance deterioration. Many individual time-point findings did not survive multiplicity correction, and brain creatine was not measured. This extends the stress-specific signal, but is not independent proof of a dose-response relationship: comparing two separate trials does not isolate dose. [8]

### Rested adults: smaller and less reliable effects
A preregistered crossover study of 123 adults tested 5 g/day for six weeks per condition. Working-memory performance gave a small, uncertain signal (p=0.064); abstract reasoning did not significantly improve (p=0.327), and exploratory tasks did not show benefit. Bayesian analysis allowed a small benefit. Vegetarians did not benefit more than omnivores. The appropriate interpretation is uncertainty about small effects, rather than either a large enhancement claim or proof of zero effect. [9]

### Why positive pooled estimates need scrutiny
In 2024 EFSA concluded that the submitted evidence did not establish the proposed cause-and-effect cognition claim. Its critique included pooling correlated cognitive tests as if they represented independent evidence, inflating effective sample size. That judgment is about the evaluated claim and evidence, not a finding that the biochemistry is false. Later trials must be assessed on their own merits. [10]

A newly indexed August 2026 trial randomized supplementation after participants selected exercise/diet or non-exercise conditions. Seventy-three entered and 64 completed 12 weeks; ages were 45-65 and the dose was 10 g/day. The abstract reports selected favorable cognitive and physical outcomes. Small groups, numerous outcomes and nonrandom selection into exercise limit broad conclusions. Full methods were inaccessible in this search, so this study receives limited weight here. [21]

### Who might benefit more?
Low baseline reserve, high energy demand or impaired metabolism are plausible modifiers. Dietary pattern, age and sex alone are imperfect proxies for brain creatine. Exploratory subgroup differences should not be treated as a reliable way to identify responders. Adequately powered trials need to measure baseline status and formally test interactions.

**Interpretation:** creatine is a candidate for modest, conditional support of cognition. There is no established dose that reliably enhances all cognitive domains, and no evidence here that improved test performance replaces sleep or prevents dementia.

<!-- PAGE -->
# 4. Mood, neurological disease and injury
### Depression: a promising adjunctive signal
An eight-week trial in 52 women compared escitalopram plus 5 g/day creatine with escitalopram plus placebo and found better depressive-symptom outcomes with creatine. A separate eight-week trial in 100 adults tested creatine alongside cognitive behavioural therapy and reported a 5.12-point advantage on PHQ-9. Both support further study of augmentation; neither establishes creatine alone as an antidepressant. [11,12]

Energy support could plausibly assist neuronal function and treatment response. These trials do not establish that a specific mitochondrial, neurotransmitter or neuroplasticity pathway mediated the clinical change. Mood improvement also does not prove improved cognition or longevity. Long-term remission, relapse prevention and generalizability need stronger evidence.

### Alzheimer disease: engagement is ahead of efficacy
In the 2025 CABA single-arm pilot, 20 patients took 20 g/day for eight weeks. Brain total creatine increased by 11%, and some NIH Toolbox scores improved, while MMSE did not significantly change. With no placebo arm, practice effects and other time-related changes cannot be separated from treatment. The study supports feasibility and brain exposure, not slowed disease progression or prevention. [13]

### Two major tests where the attractive mechanism failed
| Trial | Tested setting | What it constrains |
|---|---|---|
| Parkinson disease, LS-1 [17] | 1,741 participants; 10 g/day; long-term randomized placebo comparison | Stopped for futility; no improvement in clinical progression. |
| Huntington disease, CREST-E [18] | 553 participants; high-dose randomized placebo comparison | Stopped for futility; no demonstrated slowing of functional decline. |

These are meaningful negative results, not merely a lack of research. They show that biochemical plausibility and favorable animal experiments do not guarantee disease modification. They do not rule out every preventive, earlier-stage or biomarker-selected use, but those possibilities remain new hypotheses rather than established benefits.

### Injury and deficiency require separate reasoning
An open-label randomized pediatric traumatic-brain-injury pilot enrolled 39 children and adolescents and reported favorable recovery outcomes. Lack of blinding, small size and a different clinical setting prevent extrapolation to routine concussion prevention in adults. It is preliminary treatment evidence, not a reason to assume brain injuries are less dangerous when taking creatine. [19]

Inherited defects of creatine synthesis provide a different situation: replacing a deficient metabolite can be clinically important. In a 14-case pediatric cohort, responses differed between synthesis defects and transporter defects; creatine alone is not a universal solution when transport is impaired. Rescue of pathological deficiency does not establish enhancement in an adequately supplied brain. [22]

**Overall:** promising depression augmentation and measurable brain uptake coexist with unsuccessful large neurodegeneration trials. The evidence is indication-specific.

<!-- PAGE -->
# 5. Doses, safety and the research priorities
### Studied doses are not a single recommendation
| Setting | Example exposure | Interpretation |
|---|---|---|
| Training / selected cognition or mood trials | Around 5 g/day [3,9,11] | Common research exposure; no proven longevity dose. |
| Midlife 2026 trial | 10 g/day for 12 weeks [21] | Does not establish superiority over 5 g/day. |
| Brain spectroscopy / Alzheimer pilot | 20 g/day for 4-8 weeks [1,13] | Target engagement; not an established treatment regimen. |
| Acute sleep deprivation | Single 0.2 or 0.35 g/kg [7,8] | About 14 or 24.5 g at 70 kg; not a routine daily protocol. |

Creatine monohydrate is the formulation used in the central trials discussed here. Bigger doses and faster increases in blood levels do not ensure greater brain benefit. No evidence reviewed establishes that a premium formulation extends life or reliably delivers superior clinical CNS effects.

### Safety should be interpreted in context
Gastrointestinal symptoms and water-related weight gain can occur. A 2025 analysis covering 685 clinical trials found broadly reassuring safety patterns, but heterogeneous reporting and follow-up cannot exclude rare harms or establish lifetime safety at high doses. A small controlled diabetes study using directly measured filtration found no impairment over 12 weeks; it does not establish safety in advanced kidney disease. [23,24]

Creatine can increase serum creatinine, complicating creatinine-based estimates of kidney function. An unexpected change should be interpreted with the supplementation history and clinical context; it should not automatically be labelled either kidney injury or harmless. Clinicians may use other filtration measures when indicated. [13,24]

Psychiatric context matters: two creatine-treated participants in a small bipolar-depression trial switched to hypomania/mania. That is a safety signal, not a precise risk estimate. Psychiatric use, known kidney disease, pregnancy and pediatric use warrant condition-specific clinical guidance rather than extrapolation from healthy-adult studies. [25]

### What would change the conclusion?
1. **Longevity:** long-duration randomized evidence for disability-free survival, major disease events or mortality, with prespecified endpoints.
2. **CNS mechanism:** concurrent measurement of brain exposure, energy handling and meaningful clinical outcomes, followed by mediation analysis.
3. **Cognition:** preregistered trials with sufficient sample size, multiplicity control and replication across rested and stressed settings.
4. **Clinical disease:** placebo-controlled confirmation of Alzheimer and mood signals, measuring daily function and sustained outcomes.
5. **Responder selection:** prospective tests of baseline brain creatine or metabolic impairment, rather than post-hoc demographic subgroup claims.

### Search scope and limitations
Targeted narrative review searched 19 September 2026 across PubMed/PMC, publishers, EFSA and an institutional repository, including 2025-2026 studies. This is not a systematic review. Source access is labelled in the references; several full texts were inaccessible. Primary findings were checked afresh. Search topics and study extraction accompany the report. No new meta-analysis was performed.

<!-- PAGE -->
# References and evidence access
## Sources 1-13
The linked records identify the studies underlying the report. F = full text inspected for relevant sections; A = abstract/record inspected; R = original regulatory assessment. Access status is not a quality rating. Full statistical replication was not performed.

[1] Dechent P et al. (1999). Increase of total creatine in human brain after oral supplementation of creatine-monohydrate. Am J Physiol 277:R698-704. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/10484486/)

[2] Klivenyi P et al. (2004). Neuroprotective mechanisms of creatine occur in the absence of mitochondrial creatine kinase. Neurobiol Dis 15:610-617. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/15056469/)

[3] Brose A, Parise G, Tarnopolsky MA. (2003). Creatine supplementation enhances isometric strength and body composition improvements following strength exercise training in older adults. J Gerontol A 58:B11-19. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/12560406/)

[4] Bender A et al. (2008; online 2007). Creatine improves health and survival of mice. Neurobiol Aging 29:1404-1411. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/17416441/)

[5] Ostojic SM. (2025). Dietary creatine intake and all-cause mortality among U.S. adults: a linked mortality analysis from the NHANES study. Appl Physiol Nutr Metab. DOI: 10.1139/apnm-2025-0001. [A] [Source](https://doi.org/10.1139/apnm-2025-0001)

[6] Matthews RT et al. (1999). Creatine and cyclocreatine attenuate MPTP neurotoxicity. Exp Neurol. PMID: 10222117. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/10222117/)

[7] Gordji-Nejad A et al. (2024). Single dose creatine improves cognitive performance and induces changes in cerebral high energy phosphates during sleep deprivation. Sci Rep 14:4937. [F] [Source](https://www.nature.com/articles/s41598-024-54249-9)

[8] Gordji-Nejad A et al. (2026). Single-Dose Creatine Reduces Sleep Deprivation-Induced Deterioration in Cognitive Performance. Nutrients 18:1192. DOI: 10.3390/nu18081192. [F] [Source](https://juser.fz-juelich.de/record/1055998/files/nutrients-18-01192-v2.pdf?version=1)

[9] Sandkuhler JF et al. (2023). The effects of creatine supplementation on cognitive performance - a randomised controlled study. BMC Med 21:440. [F] [Source](https://doi.org/10.1186/s12916-023-03146-5)

[10] EFSA NDA Panel (2024). Creatine and improvement in cognitive function: evaluation of a health claim. EFSA Journal 22:e9100. [R] [Source](https://doi.org/10.2903/j.efsa.2024.9100)

[11] Lyoo IK et al. (2012). A randomized, double-blind placebo-controlled trial of oral creatine monohydrate augmentation for enhanced response to a selective serotonin reuptake inhibitor in women with major depressive disorder. Am J Psychiatry 169:937-945. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/22864465/)

[12] (2025; online 2024). Efficacy and safety profile of oral creatine monohydrate in add-on to cognitive-behavioural therapy in depression. Eur Neuropsychopharmacol 90:28-35. PMID: 39488067. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/39488067/)

[13] Smith AN et al. (2025). Creatine monohydrate pilot in Alzheimer's: feasibility, brain creatine, and cognition. Alzheimers Dement (N Y) 11:e70101. [F] [Source](https://pmc.ncbi.nlm.nih.gov/articles/PMC12089086/)

<!-- PAGE -->
# References and evidence access
## Sources 14-25
[14] Lawler JM et al. (2002). Direct antioxidant properties of creatine. Biochem Biophys Res Commun 290:47-52. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/11779131/)

[15] Peters BA et al. (2015). Low-dose creatine supplementation lowers plasma guanidinoacetate, but not plasma homocysteine, in a double-blind, randomized, placebo-controlled trial. J Nutr 145:2245-2252. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/26311810/)

[16] Gualano B et al. (2011). Creatine in type 2 diabetes: a randomized, double-blind, placebo-controlled trial. Med Sci Sports Exerc 43:770-778. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/20881878/)

[17] Writing Group for the NINDS NET-PD Investigators (2015). Effect of creatine monohydrate on clinical progression in patients with Parkinson disease: a randomized clinical trial. JAMA. PMID: 25668262. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/25668262/)

[18] Hersch SM et al. (2017). The CREST-E study of creatine for Huntington disease: a randomized controlled trial. Neurology. DOI: 10.1212/WNL.0000000000004209. [A] [Source](https://www.neurology.org/doi/10.1212/WNL.0000000000004209)

[19] Sakellaris G et al. (2006). Prevention of complications related to traumatic brain injury in children and adolescents with creatine administration: an open label randomized pilot study. PMID: 16917445. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/16917445/)

[20] Desai I et al. (2025). The Effect of Creatine Supplementation on Lean Body Mass with and Without Resistance Training. Nutrients 17:1081. DOI: 10.3390/nu17061081. [F] [Source](https://pmc.ncbi.nlm.nih.gov/articles/PMC11944689/)

[21] Chun J et al. (2026). Effects of creatine supplementation with and without exercise and diet intervention on body composition, cognitive function, and markers of health in middle-aged and older adults. J Int Soc Sports Nutr 23(sup1):2716273. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/42578920/)

[22] (2023). Fourteen cases of cerebral creatine deficiency syndrome in children: a cohort study in China. PMCID: PMC10248938. [A] [Source](https://pmc.ncbi.nlm.nih.gov/articles/PMC10248938/)

[23] Kreider RB et al. (2025). Safety of creatine supplementation: analysis of the prevalence of reported side effects in clinical trials and adverse event reports. J Int Soc Sports Nutr 22(sup1):2488937. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/40198156/)

[24] Gualano B et al. (2011). Creatine supplementation does not impair kidney function in type 2 diabetic patients: a randomized, double-blind, placebo-controlled clinical trial. Eur J Appl Physiol. DOI: 10.1007/s00421-010-1676-3. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/20976468/)

[25] (2018; online 2017). A randomized, double-blind, placebo-controlled, proof-of-concept trial of creatine monohydrate as adjunctive treatment for bipolar depression. PMID: 29177955. [A] [Source](https://pubmed.ncbi.nlm.nih.gov/29177955/)

### Evidence boundaries retained throughout
Biochemical necessity is not evidence that more is always better. Tissue uptake is not proof of clinical benefit. Biomarker improvement is not proof of longer life. A positive small trial is not confirmation across populations. Negative large trials constrain the tested indication. Lack of a human survival trial leaves longevity unproven rather than disproven.
