import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import { existsSync, readFileSync } from "node:fs";
import { relative, join } from "node:path";
// Japanese edition: the same app with translated source files from i18n/ja overlaid at load time.
const root = fileURLToPath(new URL(".", import.meta.url));
const overlay = join(root, "i18n/ja");
const ja: Plugin = {
  name: "ja-overlay",
  enforce: "pre",
  load(id) {
    const file = id.split("?")[0];
    const rel = relative(root, file);
    if (rel.startsWith("..") || rel.startsWith("i18n") || rel.includes("node_modules")) return null;
    const alt = join(overlay, rel);
    return existsSync(alt) ? readFileSync(alt, "utf8") : null;
  },
};
export default defineConfig({
  base: "/neuron-action-potential/",
  plugins: [ja, react()],
  resolve: { alias: { "@": root } },
  build: { outDir: "dist-ja", emptyOutDir: true, chunkSizeWarningLimit: 1700 },
});
