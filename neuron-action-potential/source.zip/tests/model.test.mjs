import assert from "node:assert/strict";
import { CableModel, rates, COUNT } from "../lib/neuron/model.mjs";
function run(params = {}, duration = 80, dt = 0.01) {
  const m = new CableModel();
  Object.assign(m.params, params);
  const peaks = Array(COUNT).fill(-Infinity),
    first = Array(COUNT).fill(null);
  for (let t = 0; t < duration; t += dt) {
    m.step(dt);
    for (let i = 0; i < COUNT; i++) {
      assert(Number.isFinite(m.v[i]));
      assert(m.v[i] > -110 && m.v[i] < 65);
      peaks[i] = Math.max(peaks[i], m.v[i]);
      if (m.v[i] > 0 && first[i] === null) first[i] = m.time;
    }
  }
  return { m, peaks, first };
}
for (const v of [-40, -55])
  assert(rates(v).every(Number.isFinite), "removable rate singularity");
const rest = run({ current: 0 });
assert.equal(rest.m.spikes, 0);
assert(Math.abs(rest.m.v[0] + 65) < 0.05);
const active = run();
assert(active.m.spikes > 3);
assert(
  active.first[0] < active.first[18] && active.first[18] < active.first[63],
);
assert(
  active.peaks.every((v) => v > 20),
  "spikes reach every compartment",
);
const blocked = run({ gNa: 0 });
assert.equal(blocked.m.spikes, 0);
assert(blocked.peaks[63] < -60);
const low = run({ current: 10 }),
  high = run({ current: 30 });
assert(high.m.spikes > low.m.spikes, "current changes firing rate");
const fine = run({}, 25, 0.005);
assert(
  Math.abs(fine.first[63] - active.first[63]) < 0.35,
  "propagation converges when timestep is halved",
);
for (const params of [
  { current: 40, gNa: 200, gK: 0 },
  { current: 40, gNa: 0, gK: 80 },
  { current: 0, gNa: 200, gK: 80 },
])
  run(params, 50);
const paused = new CableModel();
paused.paused = true;
paused.advance(1);
assert.equal(paused.time, 0);
paused.paused = false;
paused.advance(0.05);
assert(paused.time > 0);
paused.reset();
assert.equal(paused.time, 0);
assert.equal(paused.v[18], -65);
const pulse = new CableModel();
pulse.params.current = 0;
pulse.pulse();
for (let i = 0; i < 2000; i++) pulse.step();
assert(pulse.spikes >= 1);
console.log(
  "PASS: rest, spiking, propagation, sodium blockade, current sensitivity, numerical convergence, parameter extremes, pause/reset and stimulus pulse.",
);
console.log(
  JSON.stringify({
    arrivalMs: {
      hillock: active.first[0],
      probe: active.first[18],
      terminal: active.first[63],
    },
    peakMv: active.peaks[18],
    spikes80ms: active.m.spikes,
  }),
);

// Kirchhoff balance at the fork, including unequal daughter membrane areas.
const { BRANCHES, createTopology, axialCurrents } =
  await import("../lib/neuron/topology.mjs");
const topology = createTopology();
const voltage = Float64Array.from(
  { length: COUNT },
  (_, i) => -65 + 25 * Math.sin(i),
);
const axial = axialCurrents(voltage, topology, new Float64Array(COUNT));
assert(
  Math.abs(axial.reduce((sum, x, i) => sum + x * topology.area[i], 0)) < 1e-10,
  "junction conserves total axial current",
);
for (const b of BRANCHES) {
  assert(
    active.m.firstArrival[b.end] > active.m.firstArrival[63],
    "branch arrives after fork",
  );
  assert(
    Math.abs(fine.m.firstArrival[b.end] - active.m.firstArrival[b.end]) < 0.35,
    "branch arrival converges",
  );
  assert(blocked.peaks[b.end] < -60, "sodium block prevents terminal spikes");
}
assert(
  new Set(BRANCHES.map((b) => Math.round(active.m.firstArrival[b.end] * 100)))
    .size === 5,
  "branches have independent arrival times",
);
const { ChannelPopulation } = await import("../lib/neuron/channels.mjs");
const sample = new ChannelPopulation(),
  r = rates(-20);
const expectedNa = (r[0] / (r[0] + r[1])) ** 3 * (r[2] / (r[2] + r[3])),
  expectedK = (r[4] / (r[4] + r[5])) ** 4;
let na = 0,
  k = 0,
  count = 0;
for (let i = 0; i < 30000; i++) {
  sample.step(r, 0.1);
  if (i > 1000) {
    na += sample.naState.filter((s) => s === 1).length;
    k += sample.kState.filter((s) => s === 1).length;
    count += 32;
  }
}
assert(
  Math.abs(na / count - expectedNa) < 0.015,
  "sampled Na gates reproduce HH equilibrium probability",
);
assert(
  Math.abs(k / count - expectedK) < 0.025,
  "sampled K gates reproduce HH equilibrium probability",
);
const a = new CableModel(),
  b = new CableModel();
for (let i = 0; i < 800; i++) {
  a.step();
  b.step();
}
assert.deepEqual(
  a.population.naGates,
  b.population.naGates,
  "seeded stochastic sample reproducible",
);
a.paused = true;
const saved = Array.from(a.population.naGates);
a.advance(0.1);
assert.deepEqual(
  Array.from(a.population.naGates),
  saved,
  "pause freezes channel gates",
);
a.reset();
b.reset();
assert.deepEqual(
  a.population.naGates,
  b.population.naGates,
  "reset restores channel seed and gates",
);
console.log(
  "PASS: conservative branch coupling, distinct and converged terminal arrivals, branch blockade, stochastic gate statistics, seeded reset and channel pause.",
);
console.log(
  JSON.stringify(
    BRANCHES.map((b) => ({
      branch: b.label,
      arrivalMs: active.m.firstArrival[b.end],
      peakMv: active.peaks[b.end],
    })),
  ),
);
const recording = new CableModel();
recording.params.current = 0;
recording.params.speed = 4;
recording.pulse();
recording.stopAt = 40;
for (let i = 0; i < 100; i++) recording.advance(0.1);
assert(
  recording.paused && Math.abs(recording.time - 40) < 0.001,
  "single-spike recording stops at 40 ms independent of speed",
);
assert.equal(
  recording.spikes,
  1,
  "single-pulse experiment generates one hillock spike",
);
assert(
  BRANCHES.every((b) => Number.isFinite(recording.firstArrival[b.end])),
  "single pulse reaches all terminals",
);
recording.paused = false;
recording.advance(0.1);
assert(recording.time > 40, "completed recording can resume");
console.log(
  "PASS: bounded single-spike recording, all five arrivals and resume.",
);
