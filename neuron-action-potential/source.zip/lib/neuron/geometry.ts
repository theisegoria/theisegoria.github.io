import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { BRANCHES } from "./topology.mjs";
// Procedural, illustrative morphology (not an anatomical reconstruction). The axon and branch
// curves are the solver's cable layout, so every voltage sample lands on the compartment it belongs to.
export const soma = new THREE.Vector3(-4.15, 0, 0);
export const axonCurve = new THREE.CatmullRomCurve3([
  new THREE.Vector3(-3.45, 0, 0),
  new THREE.Vector3(-2.3, -0.2, 0),
  new THREE.Vector3(-0.4, -0.55, 0.1),
  new THREE.Vector3(1.6, -0.48, -0.15),
  new THREE.Vector3(3.3, 0.05, 0),
  new THREE.Vector3(5.3, 0.1, 0.15),
  new THREE.Vector3(6.4, -0.15, 0),
]);
// Seeded pseudo-random numbers keep the morphology identical on every load.
function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
export function tube(
  points: THREE.Vector3[] | THREE.CatmullRomCurve3,
  radius: number,
  endRadius: number,
  segments = 36,
  cable = false,
  compartment = 0,
  endCompartment = 63,
  radiusAt?: (t: number) => number,
  radialSegments = 20,
) {
  const curve =
    points instanceof THREE.CatmullRomCurve3
      ? points
      : new THREE.CatmullRomCurve3(points, false, "centripetal");
  const geo = new THREE.TubeGeometry(curve, segments, 1, radialSegments, false);
  const p = geo.attributes.position;
  const u = new Float32Array(p.count);
  for (let j = 0; j <= segments; j++) {
    const t = j / segments,
      c = curve.getPointAt(t),
      r = radiusAt ? radiusAt(t) : radius + (endRadius - radius) * t;
    for (let k = 0; k <= radialSegments; k++) {
      const i = j * (radialSegments + 1) + k;
      p.setXYZ(
        i,
        c.x + (p.getX(i) - c.x) * r,
        c.y + (p.getY(i) - c.y) * r,
        c.z + (p.getZ(i) - c.z) * r,
      );
      u[i] = cable
        ? compartment + t * (endCompartment - compartment)
        : compartment;
    }
  }
  geo.setAttribute("aCable", new THREE.BufferAttribute(u, 1));
  geo.computeVertexNormals();
  return geo;
}
// The axon flares into a conical hillock where it leaves the soma, then tapers gently.
export const axonRadius = (t: number) =>
  0.105 + 0.04 * (1 - t) + 0.34 * Math.exp(-((t / 0.038) ** 2));
// Five daughter branches with small en-passant swellings (varicosities) along their length.
export const branchRadius = (diameter: number, id: number) => (t: number) => {
  const base = 0.105 * diameter;
  let bump = 0;
  for (const c of [0.34 + id * 0.03, 0.66 - id * 0.02])
    bump += Math.exp(-(((t - c) / 0.035) ** 2));
  return base * (1 + 0.55 * bump) * (1 + 0.6 * Math.exp(-((t / 0.06) ** 2)));
};
export function somaGeometry() {
  const g = new THREE.SphereGeometry(1, 96, 64),
    p = g.attributes.position;
  const lobes = [0.85, 1.45, 2.05, 2.65, 3.25, 3.8, 4.35, 5.0].map(
    (a, i) => new THREE.Vector3(Math.cos(a), Math.sin(a), Math.sin(i * 5) * 0.28).normalize(),
  );
  const hill = new THREE.Vector3(1, 0, 0);
  for (let i = 0; i < p.count; i++) {
    const n = new THREE.Vector3(p.getX(i), p.getY(i), p.getZ(i));
    // Smooth swellings where each dendrite and the axon hillock leave the cell body.
    let f = 1 + 0.03 * Math.sin(n.x * 5 + n.y * 3) * Math.cos(n.z * 4 - n.y * 2);
    for (const l of lobes) f += 0.22 * Math.pow(Math.max(0, n.dot(l)), 9);
    f += 0.32 * Math.pow(Math.max(0, n.dot(hill)), 6);
    p.setXYZ(i, soma.x + n.x * 0.82 * f, n.y * 0.96 * f, n.z * 0.7 * f);
  }
  g.setAttribute("aCable", new THREE.BufferAttribute(new Float32Array(p.count), 1));
  g.computeVertexNormals();
  return g;
}
// Mushroom-shaped dendritic spine: thin neck, rounded head. Size is magnified for visibility.
function spineGeometry() {
  const prof = [
    [0.0001, 0], [0.012, 0], [0.009, 0.02], [0.008, 0.045], [0.02, 0.055],
    [0.027, 0.07], [0.022, 0.088], [0.0001, 0.094],
  ].map(([x, y]) => new THREE.Vector2(x, y));
  return new THREE.LatheGeometry(prof, 8);
}
function addSpines(
  curve: THREE.Curve<THREE.Vector3>,
  radius: (t: number) => number,
  density: number,
  random: () => number,
  out: THREE.BufferGeometry[],
  proto: THREE.BufferGeometry,
) {
  const L = curve.getLength(),
    n = Math.floor(L * density);
  const up = new THREE.Vector3(0, 1, 0),
    q = new THREE.Quaternion(),
    m = new THREE.Matrix4();
  for (let k = 0; k < n; k++) {
    const t = 0.12 + 0.86 * random(),
      c = curve.getPointAt(t),
      tan = curve.getTangentAt(t);
    const side = new THREE.Vector3(random() - 0.5, random() - 0.5, random() - 0.5)
      .cross(tan)
      .normalize();
    const r = radius(t),
      s = 0.45 + 0.4 * random();
    q.setFromUnitVectors(up, side);
    m.compose(
      c.clone().addScaledVector(side, r * 0.85),
      q,
      new THREE.Vector3(s, s * (0.8 + 0.5 * random()), s),
    );
    out.push(proto.clone().applyMatrix4(m));
  }
}
function wavy(a: THREE.Vector3, b: THREE.Vector3, random: () => number, amp: number, steps = 4) {
  const pts = [a.clone()];
  for (let i = 1; i < steps; i++) {
    const p = a.clone().lerp(b, i / steps);
    p.add(new THREE.Vector3(random() - 0.5, random() - 0.5, random() - 0.5).multiplyScalar(amp));
    pts.push(p);
  }
  pts.push(b.clone());
  return new THREE.CatmullRomCurve3(pts, false, "centripetal");
}
// Eight primary dendrites that taper and branch twice, studded with spines.
// Returns one merged geometry (with the soma voltage, compartment 0) for a single draw call.
export function morphology() {
  const random = rng(7);
  const parts: THREE.BufferGeometry[] = [];
  const spines: THREE.BufferGeometry[] = [];
  const proto = spineGeometry();
  const angles = [0.85, 1.45, 2.05, 2.65, 3.25, 3.8, 4.35, 5.0];
  for (let i = 0; i < angles.length; i++) {
    const a = angles[i],
      len = 2.2 + (i % 3) * 0.42,
      dir = new THREE.Vector3(Math.cos(a), Math.sin(a), Math.sin(i * 5) * 0.28);
    const base = soma.clone().addScaledVector(dir, 0.5),
      tip = soma.clone().addScaledVector(dir, len);
    tip.z += Math.cos(i * 3) * 0.5;
    const primary = wavy(base, tip, random, 0.22, 5);
    const pr = (t: number) => 0.2 * Math.pow(1 - t, 1.3) + 0.016 + 0.07 * Math.exp(-((t / 0.08) ** 2));
    parts.push(tube(primary, 0, 0, 48, false, 0, 0, pr, 14));
    addSpines(primary, pr, 9, random, spines, proto);
    for (let j = 0; j < 3; j++) {
      const t0 = 0.25 + j * 0.22,
        split = primary.getPointAt(t0),
        ang = a + (j % 2 ? -0.62 : 0.58) + (random() - 0.5) * 0.3,
        L2 = 0.8 + random() * 0.7;
      const end = split.clone().add(
        new THREE.Vector3(Math.cos(ang) * L2, Math.sin(ang) * L2, (random() - 0.5) * 0.7),
      );
      const sec = wavy(split, end, random, 0.14, 4);
      const r0 = pr(t0) * 0.62;
      const sr = (t: number) => r0 * Math.pow(1 - t, 1.15) + 0.006;
      parts.push(tube(sec, 0, 0, 24, false, 0, 0, sr, 10));
      addSpines(sec, sr, 12, random, spines, proto);
      const t1 = 0.45 + random() * 0.3,
        ang2 = ang + (random() > 0.5 ? 0.6 : -0.6);
      const s2 = sec.getPointAt(t1),
        e2 = s2.clone().add(
          new THREE.Vector3(Math.cos(ang2) * 0.55, Math.sin(ang2) * 0.55, (random() - 0.5) * 0.4),
        );
      const ter = wavy(s2, e2, random, 0.08, 3),
        tr = (t: number) => sr(t1) * 0.7 * (1 - t) + 0.004;
      parts.push(tube(ter, 0, 0, 14, false, 0, 0, tr, 8));
      addSpines(ter, tr, 8, random, spines, proto);
    }
  }
  for (const s of spines) {
    s.setAttribute("aCable", new THREE.BufferAttribute(new Float32Array(s.attributes.position.count), 1));
  }
  for (const g of parts) g.deleteAttribute("uv");
  for (const g of spines) g.deleteAttribute("uv");
  const merged = mergeGeometries([...parts, ...spines], false)!;
  parts.forEach((g) => g.dispose());
  spines.forEach((g) => g.dispose());
  proto.dispose();
  return [merged];
}
export const branchCurves = BRANCHES.map((b, i) => {
  const root = axonCurve.getPointAt(1),
    angle = (i - 2) * 0.43;
  const direction = new THREE.Vector3(
    Math.cos(angle),
    Math.sin(angle),
    Math.sin(i * 2) * 0.16,
  ).normalize();
  const end = root.clone().addScaledVector(direction, b.segments * 0.155);
  const mid = root
    .clone()
    .lerp(end, 0.5)
    .add(new THREE.Vector3(0, (i - 2) * 0.09, 0));
  return new THREE.CatmullRomCurve3([root, mid, end]);
});
// Presynaptic bouton: a swollen, slightly flattened ending that carries the terminal's own voltage.
export function boutonGeometry(compartment: number) {
  const g = new THREE.SphereGeometry(0.13, 32, 20);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const f = 1 + 0.25 * Math.max(0, x / 0.13);
    p.setXYZ(i, x * f, y * 0.9, z * 0.95);
  }
  g.computeVertexNormals();
  g.setAttribute(
    "aCable",
    new THREE.BufferAttribute(new Float32Array(p.count).fill(compartment), 1),
  );
  return g;
}
export function probePosition(index: number) {
  if (index < 64) return axonCurve.getPointAt(index / 63);
  const b = BRANCHES.find((b) => index >= b.start && index <= b.end)!;
  return branchCurves[b.id].getPointAt((index - b.start) / (b.segments - 1));
}
export const channelSites = [
  ...Array.from({ length: 14 }, (_, i) => ({
    t: 0.08 + i * 0.063,
    index: Math.round((0.08 + i * 0.063) * 63),
    curve: axonCurve,
    radius: 0.16,
    scale: 1,
  })),
  ...BRANCHES.flatMap((b) =>
    [0.28, 0.58, 0.9].map((t) => ({
      t,
      index: b.start + Math.round(t * (b.segments - 1)),
      curve: branchCurves[b.id],
      radius: 0.105 * b.diameter,
      scale: 0.55,
    })),
  ),
];
export function membranePosition(
  t: number,
  angle: number,
  radius: number,
  curve = axonCurve,
) {
  const p = curve.getPointAt(Math.max(0, Math.min(1, t))),
    tangent = curve.getTangentAt(Math.max(0, Math.min(1, t))),
    normal = new THREE.Vector3(0, Math.cos(angle), Math.sin(angle));
  normal.addScaledVector(tangent, -normal.dot(tangent)).normalize();
  return { p: p.addScaledVector(normal, radius), normal };
}
