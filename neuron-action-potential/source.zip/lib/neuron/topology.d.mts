export const TRUNK_COUNT: number;
export const COUNT: number;
export const BRANCH_SEGMENTS: number[];
export const BRANCH_DIAMETERS: number[];
export type Branch = {
  id: number;
  label: string;
  start: number;
  end: number;
  segments: number;
  diameter: number;
};
export const BRANCHES: Readonly<Branch>[];
export type Topology = { area: Float64Array; edges: number[][] };
export function createTopology(): Topology;
export function axialCurrents(
  v: Float64Array,
  topology: Topology,
  out: Float64Array,
): Float64Array;
export function probeLabel(index: number): string;
