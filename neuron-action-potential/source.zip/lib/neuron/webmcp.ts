import { CableModel, BRANCHES } from "./model.mjs";
export function registerSimulationTools(
  model: CableModel,
  refresh: () => void,
) {
  const context = (
    document as Document & {
      modelContext?: {
        registerTool: (tool: unknown, options: unknown) => unknown;
      };
    }
  ).modelContext;
  if (!context?.registerTool) return () => {};
  const controller = new AbortController();
  const register = (tool: unknown) => {
    try {
      void Promise.resolve(
        context.registerTool(tool, { signal: controller.signal }),
      ).catch(() => {});
    } catch {
      /* Optional browser capability. */
    }
  };
  register({
    name: "read_neuron_simulation",
    title: "Read neuron simulation",
    description:
      "Read current membrane potential, gate fractions and experiment settings.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true },
    execute: () => ({
      ...model.snapshot(),
      parameters: { ...model.params },
      paused: model.paused,
      recordingCompartment: model.probe,
      channels: {
        sodiumOpen: Array.from(model.population.naState).filter((s) => s === 1)
          .length,
        potassiumOpen: Array.from(model.population.kState).filter(
          (s) => s === 1,
        ).length,
      },
      terminals: BRANCHES.map((b) => ({
        label: b.label,
        voltage: model.v[b.end],
        firstArrivalMs: Number.isFinite(model.firstArrival[b.end])
          ? model.firstArrival[b.end]
          : null,
      })),
    }),
  });
  register({
    name: "configure_neuron_simulation",
    title: "Configure neuron simulation",
    description:
      "Change the same current, conductance, speed and pause settings as the visible experiment controls.",
    inputSchema: {
      type: "object",
      properties: {
        current: { type: "number", minimum: 0, maximum: 40 },
        gNa: { type: "number", minimum: 0, maximum: 200 },
        gK: { type: "number", minimum: 0, maximum: 80 },
        speed: { type: "number", minimum: 0.1, maximum: 4 },
        paused: { type: "boolean" },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false },
    execute: async (input: unknown) => {
      if (!input || typeof input !== "object" || Array.isArray(input))
        throw Error("Expected experiment settings.");
      const o = input as Record<string, unknown>,
        bounds: Record<string, [number, number]> = {
          current: [0, 40],
          gNa: [0, 200],
          gK: [0, 80],
          speed: [0.1, 4],
        };
      for (const [k, v] of Object.entries(o)) {
        if (k === "paused") {
          if (typeof v !== "boolean") throw Error("paused must be boolean.");
        } else if (
          !bounds[k] ||
          typeof v !== "number" ||
          !Number.isFinite(v) ||
          v < bounds[k][0] ||
          v > bounds[k][1]
        )
          throw Error("Invalid setting: " + k);
      }
      for (const [k, v] of Object.entries(o)) {
        if (k === "paused") model.paused = v as boolean;
        else model.params[k as keyof typeof model.params] = v as number;
      }
      refresh();
      await new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      );
      return { parameters: { ...model.params }, paused: model.paused };
    },
  });
  return () => controller.abort();
}
