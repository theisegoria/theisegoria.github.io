export type CircuitParameters={mode:'pair'|'chain'|'feedforward'|'feedback';stochastic:boolean;seed:number;release:number;recovery:number;clearance:number;enzyme:number;plasticity:boolean;inhibitionTime:number};
export type Contact={source:number;terminal?:number;target:number;site:number;kind:'E'|'I';weight:number;label:string;enabled:boolean;density:number;delay:number};
export const CIRCUIT_DEFAULTS: Readonly<CircuitParameters>;
export const CELL_NAMES: string[];
export const CONTACTS: Contact[];
export type SynapseSample={ca:number;C:number;S:number;ready:number;R:number;B:number;O:number;D:number;weight:number;current:number;released:number;uptaken:number;degraded:number;escaped:number};
export type CircuitSample={time:number;pre:number;voltages:number[];synapses:SynapseSample[]};
export class ChemicalSynapse {
 config:Contact; id:number;caFlux:number;dissociated:number;motion:number;releaseActivity:number; ca:number; q:number; ready:number; recycling:number; facilitation:number; C:number; S:number; states:number[]; released:number; uptaken:number; degraded:number;escaped:number; weight:number; arrivals:number; preVoltage:number; lastRelease:number; releaseEvents:{time:number;dose:number}[];g:number;current:number;
 constructor(config:Partial<Contact>,id:number); reset():void;massError():number;
}
export class CircuitModel {
 params:CircuitParameters;synapses:ChemicalSynapse[];v:Float64Array;time:number;spikes:number[];lastSpike:number[];raster:{cell:number;time:number}[];record:CircuitSample[];inhibitoryPulse:boolean;
 constructor();reset():void;active(s:ChemicalSynapse):boolean;cellActive(id:number):boolean;step(dt:number,time:number,pre:Float64Array):void;
}
