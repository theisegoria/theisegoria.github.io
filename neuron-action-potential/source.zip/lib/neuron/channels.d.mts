export const CHANNELS_PER_SPECIES: number;
export class ChannelPopulation {
  naGates: Uint8Array;
  kGates: Uint8Array;
  naState: Uint8Array;
  kState: Uint8Array;
  seed: number;
  constructor();
  random(): number;
  reset(m: number, h: number, n: number): void;
  step(r: number[], dt: number): void;
  updateStates(): void;
}
