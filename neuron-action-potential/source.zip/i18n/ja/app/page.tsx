"use client";
import { lazy, Suspense, useState, useEffect, useRef, memo } from "react";
import {
  Activity,
  Move,
  Focus,
  Maximize2,
  ArrowUpRight,
  ChevronDown,
} from "lucide-react";
import { CableModel, DEFAULTS, BRANCHES } from "@/lib/neuron/model.mjs";
import { registerSimulationTools } from "@/lib/neuron/webmcp";
import SimulationControls, {
  type Parameters,
} from "@/components/neuron/SimulationControls";
import VoltageGraph from "@/components/neuron/VoltageGraph";
import ChannelPopulation from "@/components/neuron/ChannelPopulation";
import BranchSignals from "@/components/neuron/BranchSignals";
import { probeLabel } from "@/lib/neuron/topology.mjs";
import CircuitControls from "@/components/neuron/CircuitControls";
import CircuitPlots from "@/components/neuron/CircuitPlots";
import {CIRCUIT_DEFAULTS,CONTACTS} from "@/lib/neuron/circuit.mjs";
import MyelinLab from "@/components/neuron/MyelinLab";
import MembraneInset from "@/components/neuron/MembraneInset";
const NeuronScene = memo(lazy(() => import("@/components/neuron/NeuronScene")));
export default function Home() {
  const [sceneMode,setSceneMode]=useState<"axon"|"synapse"|"circuit">("axon");
  const [selectedContact,setSelectedContact]=useState(0);
  const [model] = useState(() => new CableModel());
  const [mounted, setMounted] = useState(false);
  const [params, setParams] = useState<Parameters>({ ...DEFAULTS });
  const [paused, setPaused] = useState(false);
  const [labels, setLabels] = useState(true),
    [ions, setIons] = useState(true),
    [focus, setFocus] = useState(false),
    [branchView, setBranchView] = useState(false),
    [viewRevision, setViewRevision] = useState(0);
  const [live, setLive] = useState(() => model.snapshot());
  const [cutaway, setCutaway] = useState(false);
  const [myelinRevision, setMyelinRevision] = useState(0);
  const changeMyelin = (config: Partial<CableModel["myelin"]>) => {
    model.configureMyelin(config);
    setMyelinRevision(n=>n+1);
    setLive(model.snapshot());
  };
  const onCell = (id:number) => changeMyelin({removed: model.myelin.removed.includes(id) ? model.myelin.removed.filter(x=>x!==id) : [...model.myelin.removed,id]});
  const editCircuit=()=>{model.reset();setLive(model.snapshot());setViewRevision(n=>n+1);};
  const protocol=(mode:"message"|"burst"|"inhibit"|"learning")=>{
    if(mode==='inhibit')model.circuit.params.mode='feedforward';
    if(mode==='learning')model.circuit.params.plasticity=true;
    model.params.current=0;model.reset();model.paused=false;
    model.scheduledPulses=mode==='burst'?[0,12,24,36,48]:mode==='learning'?[0,30,60,90,120,150]:[0];
    model.circuit.inhibitoryPulse=mode==='inhibit';model.stopAt=mode==='learning'?220:mode==='burst'?130:90;
    setParams({...model.params});setPaused(false);setLive(model.snapshot());setViewRevision(n=>n+1);
  };
  const selectContact=(i:number)=>{setSelectedContact(i);};
  const [pulseNote, setPulseNote] = useState("");
  const pulseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onProbe = useRef((i: number) => {
    model.setProbe(i);
    setViewRevision((n) => n + 1);
    setLive(model.snapshot());
  }).current;
  useEffect(() => {
    setMounted(true);
    let raf = 0,
      previous = performance.now(),
      lastUI = 0;
    const tick = (now: number) => {
      model.advance((now - previous) / 1000);
      previous = now;
      if (now - lastUI > 66) {
        setLive(model.snapshot());
        setPaused(model.paused);
        lastUI = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const unregister = registerSimulationTools(model, () => {
      setParams({ ...model.params });
      setPaused(model.paused);
      setLive(model.snapshot());
    });
    return () => {
      cancelAnimationFrame(raf);
      unregister();
      if (pulseTimer.current) clearTimeout(pulseTimer.current);
    };
  }, [model]);
  const setParam = (k: keyof Parameters, v: number) => {
    model.params[k] = v;
    setParams({ ...model.params });
  };
  const togglePause = () => {
    model.paused = !model.paused;
    setPaused(model.paused);
  };
  const reset = () => {
    model.params = { ...DEFAULTS };
    model.circuit.params={...CIRCUIT_DEFAULTS};
    model.circuit.synapses.forEach((s,i)=>Object.assign(s.config,CONTACTS[i],{enabled:true,density:1,delay:.3}));
    setSelectedContact(0);
    model.paused = false;
    model.probe = 18;
    model.configureMyelin({enabled:false,length:5,gap:1,removed:[]});
    setMyelinRevision(n=>n+1);
    setParams({ ...DEFAULTS });
    setPaused(false);
    setFocus(false);
    setCutaway(false);
    setBranchView(false);
    setViewRevision((n) => n + 1);
    setLive(model.snapshot());
    setPulseNote("");
  };
  const pulse = () => {
    model.pulse();
    setPulseNote("+35 μA/cm² · 1 ms");
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    pulseTimer.current = setTimeout(() => setPulseNote(""), 1800);
  };
  const scenario = (mode: "rest" | "single" | "train") => {
    model.params = {
      ...DEFAULTS,
      current: mode === "train" ? 18 : 0,
      speed: params.speed,
    };
    model.paused = false;
    model.reset();
    if (mode === "single") {
      model.pulse();
      model.stopAt = 40;
    }
    setParams({ ...model.params });
    setPaused(false);
    setLive(model.snapshot());
    setPulseNote(
      mode === "single"
        ? "単発スパイク · 35 μA/cm² を 1 ms"
        : mode === "rest"
          ? "注入電流なし"
          : "持続電流 · 18 μA/cm²",
    );
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    pulseTimer.current = setTimeout(() => setPulseNote(""), 2200);
  };
  const viewBranches = () => {
    setFocus(false);
    setBranchView(true);
    setViewRevision((n) => n + 1);
    document.querySelector(".visual")?.scrollIntoView({
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
      block: "start",
    });
  };
  return (
    <main className="lab">
      <header>
        <div className="brand">
          <Activity size={24} strokeWidth={1.4} />
          <span>MEMBRANE</span>
        </div>
        <span className="eyebrow">インタラクティブ神経科学</span>
        <span className="edition">
          図 <b>01</b>
          <span className="edition-line" />
          ライブモデル
        </span>
      </header>
      <div className={`workspace ${sceneMode!=="axon"?"circuit-workspace":""}`}>
        <div className="figure-column">
          <section className="visual" aria-label="インタラクティブな3Dニューロン">
            <div className="figure-title">
              <p className="eyebrow">細胞電気生理学</p>
              <h1>{sceneMode==="synapse"?"シナプスを越えて":sceneMode==="circuit"?"つながった回路":"活動電位"}</h1>
              <p>{sceneMode==="axon"?"一つのニューロン、伝わっていく電気信号。":sceneMode==="synapse"?"電気信号が化学のメッセージに変わる。":"局所のダイナミクスが、回路全体に響く。"}</p>
            </div>
            <div className="scene-mode-tabs" aria-label="3D表示の切り替え">{(["axon","synapse","circuit"] as const).map(mode=><button key={mode} aria-pressed={sceneMode===mode} onClick={()=>{setSceneMode(mode);setFocus(false);setBranchView(false);setViewRevision(n=>n+1);}}>{mode==="axon"?"軸索とミエリン":mode==="synapse"?"シナプス間隙":"神経回路"}</button>)}</div>
            <div className="scene-badge">
              <span className="na-dot" />{" "}
              {sceneMode!=="axon" ? (sceneMode==="synapse" ? `接点 ${selectedContact+1} · 断面` : "ライブ回路") : focus
                ? "膜の拡大"
                : branchView
                  ? "分岐する軸索"
                  : "多極ニューロン"}
            </div>
            <div className="scene-canvas">
              {mounted && (
                <Suspense
                  fallback={
                    <div className="scene-loading">ニューロンを準備しています…</div>
                  }
                >
                  <NeuronScene
                    model={model}
                    mode={sceneMode}
                    selectedContact={selectedContact}
                    onContact={selectContact}
                    myelinRevision={myelinRevision}
                    cutaway={cutaway}
                    onCell={onCell}
                    probeIndex={model.probe}
                    labels={labels && (sceneMode!=="axon" || !focus)}
                    ions={ions}
                    focus={focus}
                    branchView={branchView}
                    viewRevision={viewRevision}
                    onProbe={onProbe}
                  />
                </Suspense>
              )}
            </div>
            {sceneMode==="axon" && <div className="scene-tools">
              {model.myelin.enabled && <button aria-pressed={cutaway} onClick={()=>setCutaway(v=>!v)}>{cutaway?"断面を閉じる":"ミエリンの断面"}</button>}
              <button
                aria-pressed={focus}
                onClick={() => {
                  setFocus(!focus);
                  setBranchView(false);
                }}
                title="記録部位のチャネルを拡大する"
              >
                <Focus size={16} />
                {focus ? "ニューロン全体" : "膜を拡大する"}
              </button>
              <button
                aria-pressed={branchView}
                onClick={() => {
                  setFocus(false);
                  setBranchView(!branchView);
                }}
              >
                分岐
              </button>
              <button
                className="icon-button"
                aria-label="カメラをリセット"
                onClick={() => {
                  setFocus(false);
                  setBranchView(false);
                  setViewRevision((n) => n + 1);
                }}
              >
                <Maximize2 size={16} />
              </button>
            </div>
            }
            {sceneMode!=="axon" && <div className="scene-tools">{sceneMode==="synapse"&&<button aria-pressed={focus} onClick={()=>setFocus(!focus)}><Focus size={16}/>{focus?"シナプス全体":"受容体を拡大"}</button>}<button onClick={()=>{setFocus(false);setViewRevision(n=>n+1);}}>表示をリセット</button></div>}
            <div className="voltage-legend">
              <span>膜電位</span>
              <div className="voltage-ramp" />
              <div>
                <span>−80</span>
                <span>−65</span>
                <span>+40 mV</span>
              </div>
            </div>
            <div className="scene-foot">
              <span>
                <Move size={13} /> ドラッグで回転 · スクロールで拡大縮小 · 右ドラッグで移動
              </span>
              <span>{sceneMode==="synapse"?"金：伝達物質 · 紫：カルシウム":sceneMode==="circuit"?"番号のついたシナプス接点を選ぶ":cutaway ? "断面 · 層は説明用" : "軸索をクリックして記録部位を移動"}</span>
            </div>
            <span role="status" className="pulse-note">
              {pulseNote}
            </span>
          </section>
          {sceneMode!=="axon" ? <CircuitPlots model={model} selected={selectedContact}/> : <section
            className="trace-panel"
            aria-label="膜電位の記録"
          >
            <div className="trace-header">
              <div>
                <p className="eyebrow">
                  膜電位 <span className="unit">mV</span>
                </p>
                <div className="trace-key">
                  <span>
                    <i />
                    {probeLabel(model.probe)}
                  </span>
                  <span>
                    <i />
                    軸索小丘
                  </span>
                </div>
              </div>
              <div className="live-voltage">
                <strong>{live.v.toFixed(1)}</strong>
                <span>mV</span>
                <small className={"phase " + live.phase.toLowerCase()}>
                  {({Hyperpolarization:"過分極",Depolarization:"脱分極",Repolarization:"再分極",Charging:"充電中",Resting:"静止"} as Record<string,string>)[live.phase]??live.phase}</small>
              </div>
            </div>
            <div className="probe-selector">
              <label htmlFor="probe-location">記録部位</label>
              <select
                id="probe-location"
                value={model.probe}
                onChange={(e) => {
                  onProbe(Number(e.target.value));
                  setViewRevision((n) => n + 1);
                }}
              >
                {[
                  0,
                  18,
                  40,
                  63,
                  ...BRANCHES.map((b) => b.end),
                  ...(![0, 18, 40, 63, ...BRANCHES.map((b) => b.end)].includes(
                    model.probe,
                  )
                    ? [model.probe]
                    : []),
                ].map((i) => (
                  <option key={i} value={i}>
                    {probeLabel(i)}
                  </option>
                ))}
              </select>
            </div>
            <VoltageGraph model={model} />
            <div className="trace-foot">
              <span>40 ms の表示幅 · 静止電位の基準 −65 mV</span>
              <span>
                t = <b>{live.time.toFixed(1)}</b> ms
              </span>
            </div>
          </section>}
        </div>
        <aside className="controls">
          <SimulationControls
            params={params}
            paused={paused}
            labels={labels}
            ions={ions}
            setParam={setParam}
            togglePause={togglePause}
            reset={reset}
            pulse={pulse}
            setLabels={setLabels}
            setIons={setIons}
          />
          {sceneMode!=="axon"?<CircuitControls model={model} selected={selectedContact} onSelect={selectContact} onEdit={editCircuit} onProtocol={protocol}/>:<MyelinLab model={model} onChange={changeMyelin} onInspect={()=>{ onProbe(32); setFocus(true); setBranchView(false); setViewRevision(n=>n+1); document.querySelector(".visual")?.scrollIntoView({block:"start"}); }} />}
          {sceneMode==="axon" && <MembraneInset model={model} />}
        </aside>
      </div>
      {sceneMode==="axon" && <div className="mechanism-grid">
        <ChannelPopulation model={model} />
        <BranchSignals
          model={model}
          onProbe={onProbe}
          onView={viewBranches}
          onScenario={scenario}
          onPause={togglePause}
        />
      </div>}
      <footer>
        <div className="figure-caption">
          <span className="caption-number">01</span>
          <p>
            脱分極で <span className="sodium-text">Na⁺</span> が流入し、遅れて起こる <span className="potassium-text">K⁺</span> の流出が膜電位を元に戻します。
            <br />
            <span>
              軸索を進む光る脱分極の波を追い、膜を拡大してゲートの反応を見てください。
            </span>
          </p>
        </div>
        <details className="model-details">
          <summary>
            モデルについて <ChevronDown size={14} />
          </summary>
          <div>
            <p>シナプスと回路の表示では、それぞれ5つのHHコンパートメントをもつ受け手の細胞を4つ加えています。終末の電位がカルシウム流入、有限の小胞プール、伝達物質の結合、受容体の開口と脱感作を駆動します。輸送、任意の酵素分解、拡散は伝達物質の総量を保存します。興奮性と抑制性の電流が受け手の細胞を駆動し、乱数シード付きの放出と上限つきのスパイクタイミング可塑性は任意で使えます。パラメータはすべて説明用で、実際の標本に合わせたものではありません。粒子は集団としての流れを表し、個々の分子を追ったものではありません。</p>
            <p>
              電気的に結合した144のコンパートメントで、電位依存性の m・h・n ゲートをもつホジキン–ハクスリーのケーブルを解いています。親軸索に64、5本の娘枝に計80です。注入電流は最初の4つのコンパートメントに入ります。各区間の局所電位が膜の色を決め、そのイオン電流が粒子の移動を駆動します。
            </p>
            <p className="equation">
              Cₘ dV/dt = Iᵢₙⱼ + Iₐₓᵢₐₗ − ḡNa m³h(V − ENa) − ḡK n⁴(V − EK) − gL(V
              − EL)
            </p>
            <p>
              6.3 °C における古典的なイカ巨大軸索の速度論：Cₘ = 1 μF/cm²、ENa = +50 mV、EK = −77 mV、EL = −54.387 mV、gL = 0.3 mS/cm²。ケーブルの両端は閉じており、親軸索の隣接結合は 4 mS/cm²、時間刻みは 0.01 ms です。娘枝の膜面積は相対直径に、軸方向コンダクタンスは直径の2乗に比例し、各分岐点で軸方向電流が保存されます。ゲートは指数関数的に更新し、電位は各ステップ内でコンダクタンスを固定して更新します。
            </p>
            <p>
              教育用の近似です。様式化した多極ニューロンの形（樹状突起のスパイン、軸索小丘、シナプス前ボタンは位置関係を示すための描画で、計測値ではありません）に、無髄の分岐ケーブルを載せています。 樹状突起と細胞体は軸索小丘と同じ色を使い、各娘枝の区間と終末はそれぞれが解いた電位を使います。娘枝の相対直径は親軸索の 0.32–0.36 で、区間の長さは等しいと仮定しています。形、チャネルの大きさ、イオンの数は説明用です。3D表示と断面図では、孔の幅が集団としての開口率を表し、64チャネルの膜パッチは個々の HH ゲートを別に標本化しています。 膜の拡大表示では、記録部位の膜の一部を大きく見せています。孔の幅は局所の開口率に、S4 電位センサーの高さは m または n に、ナトリウムチャネルの不活性化ゲートは h に従います。タンパク質と脂質の形は模式的で、縮尺は正確ではありません。 粒子の流れは見やすいように拡大しています。反転電位を固定しているのは、濃度勾配が保たれていると仮定しているためです。イオン勾配のゆっくりした調節と代謝はこのモデルの範囲外です。距離と伝導速度は特定のニューロンに合わせていません。リセットすると電気的な設定がすべて元に戻り、記録が消えます。
            </p>
            <a
              href="https://neuronaldynamics.epfl.ch/online/Ch2.S2.html"
              target="_blank"
              rel="noreferrer"
            >
              ホジキン–ハクスリーモデル · Neuronal Dynamics{" "}
              <ArrowUpRight size={13} />
            </a>
            <a
              href="https://doi.org/10.1113/jphysiol.1952.sp004764"
              target="_blank"
              rel="noreferrer"
            >
              Hodgkin & Huxley（1952）· 原論文 <ArrowUpRight size={13} />
            </a>
          </div>
        </details>
      </footer>
    </main>
  );
}
