"use client";
import { useEffect, useRef } from "react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Pause, Play, RotateCcw, Zap } from "lucide-react";
export type Parameters = {
  current: number;
  gNa: number;
  gK: number;
  speed: number;
};
type Props = {
  params: Parameters;
  paused: boolean;
  labels: boolean;
  ions: boolean;
  setParam: (k: keyof Parameters, v: number) => void;
  togglePause: () => void;
  reset: () => void;
  pulse: () => void;
  setLabels: (b: boolean) => void;
  setIons: (b: boolean) => void;
};
export default function SimulationControls(p: Props) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    root.current?.querySelectorAll('[role="slider"]').forEach((element, i) => {
      element.setAttribute(
        "aria-label",
        [
          "注入電流",
          "ナトリウムコンダクタンス",
          "カリウムコンダクタンス",
          "シミュレーション速度",
        ][i],
      );
    });
  }, []);
  return (
    <div ref={root}>
      <div className="control-heading">
        <p className="eyebrow">実験</p>
        <span className="live-indicator">
          <i className={p.paused ? "paused" : ""} />
          {p.paused ? "一時停止中" : "実行中"}
        </span>
      </div>
      <h2>信号を起こす。</h2>
      <div className="transport">
        <button className="primary-button" onClick={p.togglePause}>
          {p.paused ? <Play size={15} /> : <Pause size={15} />}{" "}
          {p.paused ? "再開" : "一時停止"}
        </button>
        <button
          className="icon-button"
          onClick={p.reset}
          title="パラメータ、電位、時間をリセット"
          aria-label="シミュレーションをリセット"
        >
          <RotateCcw size={16} />
        </button>
        <button
          className="pulse-button"
          onClick={p.pulse}
          disabled={p.paused}
          title="シミュレーション時間で 1 ms、35 μA/cm² を加える"
        >
          <Zap size={14} /> パルス
        </button>
      </div>
      {[
        {
          key: "current" as const,
          label: "注入電流",
          unit: "μA/cm²",
          max: 40,
          step: 0.5,
          note: "軸索小丘への持続的な入力。",
        },
        {
          key: "gNa" as const,
          label: "ナトリウムコンダクタンス",
          unit: "mS/cm²",
          max: 200,
          step: 1,
          note: "ḡNa · すばやく活性化し、その後不活性化。",
        },
        {
          key: "gK" as const,
          label: "カリウムコンダクタンス",
          unit: "mS/cm²",
          max: 80,
          step: 1,
          note: "ḡK · 遅れて活性化し、回復させる。",
        },
      ].map((o) => (
        <div className={"control-field " + o.key} key={o.key}>
          <label id={o.key + "-label"}>
            {o.label}
            <output>
              {p.params[o.key]} <small>{o.unit}</small>
            </output>
          </label>
          <Slider
            aria-labelledby={o.key + "-label"}
            value={[p.params[o.key]]}
            min={0}
            max={o.max}
            step={o.step}
            onValueChange={(v) => p.setParam(o.key, v[0])}
          />
          <p>{o.note}</p>
        </div>
      ))}
      <div className="speed-control">
        <label id="speed-label">
          シミュレーション速度 <output>{p.params.speed.toFixed(1)}×</output>
        </label>
        <Slider
          aria-labelledby="speed-label"
          value={[p.params.speed]}
          min={0.1}
          max={4}
          step={0.1}
          onValueChange={(v) => p.setParam("speed", v[0])}
        />
        <p>1× = 1 秒あたり 8 ms の活動</p>
      </div>
      <div className="view-options">
        <label htmlFor="show-ions">
          イオン粒子

          <Switch id="show-ions" checked={p.ions} onCheckedChange={p.setIons} />
        </label>
        <label htmlFor="show-labels">
          構造のラベル

          <Switch
            id="show-labels"
            checked={p.labels}
            onCheckedChange={p.setLabels}
          />
        </label>
      </div>
    </div>
  );
}
