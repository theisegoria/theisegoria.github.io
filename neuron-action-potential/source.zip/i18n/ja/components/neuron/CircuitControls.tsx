import {useState,useRef,useEffect} from 'react';
import {CableModel} from '@/lib/neuron/model.mjs';
import type {CircuitParameters,Contact} from '@/lib/neuron/circuit.mjs';
type Protocol='message'|'burst'|'inhibit'|'learning';
export default function CircuitControls({model,selected,onSelect,onEdit,onProtocol}:{model:CableModel;selected:number;onSelect:(i:number)=>void;onEdit:()=>void;onProtocol:(p:Protocol)=>void}){
 const c=model.circuit,s=c.synapses[selected];
 const [burstResult,setBurstResult]=useState<{key:string;pulse:number[];burst:number[]}|null>(null);
 const [trials,setTrials]=useState<{key:string;values:number[]}|null>(null),[busy,setBusy]=useState(false);const cancel=useRef(false);
 useEffect(()=>()=>{cancel.current=true;},[]);
 const key=JSON.stringify([selected,c.params,c.synapses.map(s=>s.config),model.myelin,model.params.gNa,model.params.gK]);
 const set=(k:keyof CircuitParameters,v:any)=>{Object.assign(c.params,{[k]:v});onEdit();};
 const edit=(k:keyof Contact,v:any)=>{Object.assign(s.config,{[k]:v});onEdit();};
 const compareBurst=()=>{
   const settings={params:{...c.params},contacts:c.synapses.map(s=>({...s.config})),myelin:{...model.myelin,removed:[...model.myelin.removed]},membrane:{...model.params,current:0}};
   onProtocol('burst');
   const run=(burst:boolean)=>{const m=new CableModel();m.params={...settings.membrane};m.circuit.params={...settings.params};m.circuit.synapses.forEach((s,i)=>Object.assign(s.config,settings.contacts[i]));m.configureMyelin(settings.myelin);m.scheduledPulses=burst?[0,12,24,36,48]:[0];let peak=0,minReady=8;for(let i=0;i<13000;i++){m.step();peak=Math.max(peak,m.circuit.synapses[selected].C);minReady=Math.min(minReady,m.circuit.synapses[selected].ready);}return [m.circuit.spikes[1],peak,minReady,m.circuit.synapses[selected].released];};
   setBusy(true);setTimeout(()=>{try{setBurstResult({key,pulse:run(false),burst:run(true)});}finally{setBusy(false);}},30);
 };
 const repeat=async()=>{
  setBusy(true);cancel.current=false;const settings={params:{...c.params,stochastic:true},contacts:c.synapses.map(s=>({...s.config})),myelin:{...model.myelin,removed:[...model.myelin.removed]},membrane:{...model.params,current:0}};const values:number[]=[];
  try{for(let seed=0;seed<12;seed++){if(cancel.current)break;const m=new CableModel();m.params={...settings.membrane};m.circuit.params={...settings.params,seed:settings.params.seed+seed};m.circuit.synapses.forEach((s,i)=>Object.assign(s.config,settings.contacts[i]));m.configureMyelin(settings.myelin);m.pulse();for(let i=0;i<8000;i++)m.step();values.push(m.circuit.spikes[1]);setTrials({key,values:[...values]});await new Promise(r=>setTimeout(r,0));}}finally{if(!cancel.current)setBusy(false);}
 };
 return <section className="circuit-controls" aria-labelledby="circuit-controls-title">
  <p className="eyebrow">シナプス伝達</p><h2 id="circuit-controls-title">メッセージを追う。</h2>
  <label>ネットワーク<select aria-label="回路の構成" value={c.params.mode} onChange={e=>{set('mode',e.target.value);onSelect(0);}}><option value="pair">ニューロン2個 · 分散した接点</option><option value="chain">ニューロン3個 · 中継の連鎖</option><option value="feedforward">ニューロン5個 · フィードフォワード抑制</option><option value="feedback">ニューロン5個 · フィードバック回路</option></select></label>
  <div className="protocol-buttons">{([['message','メッセージは届くか？'],['burst','単発とバーストを比べる'],['inhibit','抑制で止められるか？'],['learning','繰り返しの活動と学習']] as const).map(([p,label])=><button key={p} disabled={busy} onClick={()=>p==='burst'?compareBurst():onProtocol(p)}>{label}</button>)}</div>
  {burstResult&&burstResult.key===key&&<div className="burst-result"><b>条件をそろえた単発とバーストの比較</b><table><thead><tr><th>結果</th><th>単発</th><th>バースト</th></tr></thead><tbody>{['受け手のスパイク数','間隙のピーク µM','放出可能数の最小値','放出量¹'].map((label,i)=><tr key={label}><th>{label}</th><td>{burstResult.pulse[i].toFixed(i===0?0:1)}</td><td>{burstResult.burst[i].toFixed(i===0?0:1)}</td></tr>)}</tbody></table><small>130 ms の試行。シードと設定は同じで、バーストは 12 ms 間隔の5パルスです。¹ 選んだ接点での µM × 間隙体積。</small></div>}
  <label>選んだ接点<select aria-label="選んだシナプス接点" value={selected} onChange={e=>onSelect(+e.target.value)}>{c.synapses.filter(s=>c.active(s)||s.id===selected||!s.config.enabled).map(s=><option value={s.id} key={s.id}>{s.id+1}. {s.config.label}</option>)}</select></label>
  <label className="check-line"><input type="checkbox" checked={s.config.enabled} onChange={e=>edit('enabled',e.target.checked)}/> 接点を有効にする</label>
  <div className="contact-buttons">{c.synapses.filter(s=>s.id<4||c.params.mode==='feedback'||(c.params.mode==='feedforward'&&s.id<8)||(c.params.mode==='chain'&&s.id===5)).map(s=><button key={s.id} aria-pressed={s.id===selected} onClick={()=>onSelect(s.id)}>{s.id+1}</button>)}</div>
  <label>受容体の作用<select aria-label="受容体の作用" value={s.config.kind} onChange={e=>edit('kind',e.target.value)}><option value="E">興奮性 · 反転電位 0 mV</option><option value="I">抑制性 · 反転電位 −75 mV</option></select></label>
  <label>シナプス後の位置<select aria-label="シナプス後の位置" value={s.config.site} onChange={e=>edit('site',+e.target.value)}>{['細胞体','近位樹状突起','中間の樹状突起','遠位樹状突起','樹状突起の先端'].map((x,i)=><option key={x} value={i}>{x}</option>)}</select></label>
  {([['weight','初期の強さ',0,3,.05,'×'],['density','結合部位の密度',0,2,.1,'×'],['delay','入力の遅延',0,8,.1,'ms']] as const).map(([k,label,min,max,step,unit])=><label key={k}>{label}<output>{s.config[k].toFixed(2)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={s.config[k]} onChange={e=>edit(k,+e.target.value)}/></label>)}
  <details open><summary>放出と除去</summary>
   <label className="check-line"><input type="checkbox" checked={c.params.stochastic} onChange={e=>set('stochastic',e.target.checked)}/> 確率的な小胞放出</label>
   <label>乱数シード<input aria-label="乱数シード" type="number" min="1" max="99999" value={c.params.seed} onChange={e=>set('seed',Math.max(1,Math.min(99999,Math.round(+e.target.value)||1)))}/></label>
   {([['release','放出の駆動',0,1,.01,'×'],['recovery','小胞の回復',10,300,10,'ms'],['clearance','トランスポーターの能力',0,3,.1,'×'],['enzyme','酵素による除去',0,3,.1,'×']] as const).map(([k,label,min,max,step,unit])=><label key={k}>{label}<output>{c.params[k].toFixed(2)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={c.params[k]} onChange={e=>set(k,+e.target.value)}/></label>)}
  </details>
  <label className="check-line"><input type="checkbox" checked={c.params.plasticity} onChange={e=>set('plasticity',e.target.checked)}/> スパイクタイミング可塑性</label>
  <p className="science-note">説明用のペア規則：シナプス前のスパイクがシナプス後のスパイクより先なら興奮性の接点が強まり、順序が逆なら弱まります。重みは 0.05 から 3 の範囲に保たれ、リセットで初期値に戻ります。</p>
  <label>抑制刺激の時刻<output>{c.params.inhibitionTime} ms</output><input aria-label="抑制刺激の時刻" type="range" min="0" max="45" step="1" value={c.params.inhibitionTime} onChange={e=>set('inhibitionTime',+e.target.value)}/></label>
  <p className="science-note">「抑制で止められるか？」で使います。発信元への刺激からこの時間のあとに、1 ms のパルスで介在ニューロンを直接駆動します。</p>
  <button className="run-trials" disabled={busy} onClick={repeat}>{busy?'試行中…':'確率的な試行を12回繰り返す'}</button>
  {trials&&trials.key===key&&<div className="trial-result" role="status"><b>{trials.values.filter(n=>n>0).length} / {trials.values.length} 回の試行で受け手に到達</b><div className="trial-dots">{trials.values.map((n,i)=><span key={i} title={`シード ${c.params.seed+i}：受け手のスパイク ${n} 回`} className={n?'success':''}>{n}</span>)}</div><small>数字は 80 ms 間の受け手のスパイク数です。シードは連番で、単発パルスと設定は同じです。この一括試行はライブの記録を変えません。</small></div>}
  <p className="science-note">変更すると記録はリセットされます。速い受容体の速度論と伝達物質の除去は一般的な教育用モデルです。酵素による除去は任意で、既定ではオフです。グルタミン酸作動性やコリン作動性のシナプスに合わせて較正したものではありません。</p>
 </section>;
}
