import {useState,useEffect} from 'react';
import {CableModel} from '@/lib/neuron/model.mjs';
import {CELL_NAMES} from '@/lib/neuron/circuit.mjs';
const COLORS=['#b2d1c6','#eabd7b','#9d9ae1','#da98b6','#76b9da'];
export default function CircuitPlots({model,selected}:{model:CableModel;selected:number}){
 const [compact,setCompact]=useState(false);useEffect(()=>{const q=matchMedia('(max-width: 700px)');const update=()=>setCompact(q.matches);update();q.addEventListener('change',update);return()=>q.removeEventListener('change',update);},[]);const width=compact?440:800,plotWidth=width-77;
 const [tab,setTab]=useState('voltage');const c=model.circuit,s=c.synapses[selected];
 const records=c.record.filter((_,i)=>i%2===0),start=records[0]?.time??0,end=Math.max(start+1,model.time);
 const specs:Record<string,{labels:string[];unit:string;values:(r:any)=>number[];min:number;max:number}>={
  voltage:{labels:['シナプス前 A',...CELL_NAMES.slice(1)],unit:'mV',values:r=>[r.pre,...r.voltages],min:-85,max:50},
  chemistry:{labels:['間隙','シナプス周囲'],unit:'µM',values:r=>[r.synapses[selected].C,r.synapses[selected].S],min:0,max:Math.max(1,...records.map(r=>r.synapses[selected].C))},
  current:{labels:['シナプスの内向き電流'],unit:'µA/cm²',values:r=>[r.synapses[selected].current],min:Math.min(0,...records.map(r=>r.synapses[selected].current)),max:Math.max(1,...records.map(r=>r.synapses[selected].current))},
  calcium:{labels:['遊離カルシウム'],unit:'µM',values:r=>[r.synapses[selected].ca],min:0,max:Math.max(.1,...records.map(r=>r.synapses[selected].ca))},
  receptors:{labels:['非結合','結合・閉','開','脱感作'],unit:'割合',values:r=>[r.synapses[selected].R,r.synapses[selected].B,r.synapses[selected].O,r.synapses[selected].D],min:0,max:1},
  vesicles:{labels:['放出可能な小胞'],unit:'個',values:r=>[r.synapses[selected].ready],min:0,max:8},
  plasticity:{labels:['シナプスの重み'],unit:'相対的な重み',values:r=>[r.synapses[selected].weight],min:0,max:3},
  fate:{labels:['放出','取り込み','分解','周囲へ流出'],unit:'µM × 間隙体積',values:r=>[r.synapses[selected].released,r.synapses[selected].uptaken,r.synapses[selected].degraded,r.synapses[selected].escaped],min:0,max:Math.max(1,s.released)},
 };
 const spec=specs[tab]??specs.voltage;
 return <section className="circuit-plots" aria-label="シナプスと回路の記録">
  <div className="plot-tabs" aria-label="記録の種類">{['voltage','chemistry','calcium','current','receptors','vesicles','plasticity','fate','raster'].map(t=><button key={t} aria-pressed={tab===t} onClick={()=>setTab(t)}>{({voltage:'電位',chemistry:'化学',calcium:'カルシウム',current:'電流',receptors:'受容体',vesicles:'小胞',plasticity:'可塑性',fate:'行方',raster:'ラスター'} as Record<string,string>)[t]??t}</button>)}</div>
  <svg viewBox={`0 0 ${width} 235`} role="img" aria-label={tab==='raster'?'ニューロンごとのスパイク時刻':'シミュレーション時間に沿った記録'}>
   {[0,.25,.5,.75,1].map(p=><g key={p}><line x1="52" x2={width-25} y1={195-p*165} y2={195-p*165} stroke="#273d48"/><text x="4" y={199-p*165} fill="#b3c3ce" fontSize={compact?14:12}>{tab==='raster' ? Math.round(p*4)+1 : (spec.min+p*(spec.max-spec.min)).toFixed(tab==='receptors'?2:0)}</text></g>)}
   <text x="52" y="17" fill="#b3c3ce" fontSize={compact?14:12}>{tab==='raster'?(compact?'ニューロン（色の凡例を参照）':'ニューロン 1=発信元、2=受け手、3=中継、4=介在、5=読み出し'):spec.unit}</text>
   {tab==='raster'? c.raster.filter(e=>e.time>=start).map((e,i)=><line key={i} x1={52+(e.time-start)/(end-start)*plotWidth} x2={52+(e.time-start)/(end-start)*plotWidth} y1={195-e.cell/4*165-5} y2={195-e.cell/4*165+5} stroke={COLORS[e.cell]} strokeWidth="2"/>):spec.labels.map((label,j)=><path key={label} d={records.map((r,i)=>`${i?'L':'M'}${52+(r.time-start)/(end-start)*plotWidth},${195-(spec.values(r)[j]-spec.min)/(spec.max-spec.min)*165}`).join(' ')} fill="none" stroke={COLORS[j]} strokeWidth="2"/>)}
   <text x="52" y="223" fill="#b3c3ce" fontSize={compact?14:12}>{start.toFixed(0)} ms</text><text x={width-96} y="223" fill="#b3c3ce" fontSize={compact?14:12}>{end.toFixed(0)} ms</text>
  </svg>
  <div className="plot-key">{(tab==='raster'?CELL_NAMES:spec.labels).map((l,i)=><span key={l}><i style={{background:COLORS[i]}}/>{l}</span>)}</div>
  <div className="synapse-metrics"><span>Ca²⁺ <b>{s.ca.toFixed(2)} µM</b></span><span>伝達物質 <b>{s.C.toFixed(1)} µM</b></span><span>放出可能 <b>{s.ready.toFixed(1)} / 8</b></span><span>受容体の開口 <b>{(s.states[2]*100).toFixed(1)}%</b></span><span>受け手のスパイク <b>{c.spikes[1]}</b></span><span>重み <b>{s.weight.toFixed(3)}</b></span></div>
 </section>;
}
