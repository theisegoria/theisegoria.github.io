import { CableModel } from "@/lib/neuron/model.mjs";
import { probeLabel } from "@/lib/neuron/topology.mjs";
// The parent page refreshes readouts at 15 Hz; gate transitions use solver time.
export default function ChannelPopulation({ model }: { model: CableModel }) {
  const states = [model.population.naState, model.population.kState];
  const s = model.snapshot();
  return (
    <section className="population-panel" aria-labelledby="population-title">
      <p className="eyebrow">02 / 局所の膜</p>
      <div className="section-heading">
        <h2 id="population-title">一つの電位、多くのゲート。</h2>
        <span className="patch-voltage">
          {s.v.toFixed(1)} <small>mV</small>
        </span>
      </div>
      <p>
        この範囲のチャネルはすべて同じ局所電位を受けます。個々のゲートはゆらぎ、そろって開くわけではありません。
      </p>
      <div className="patch-location">
        記録部位：<strong>{probeLabel(model.probe)}</strong>
      </div>
      <div className="channel-populations">
        {states.map((array, species) => {
          const open = Array.from(array).filter((v) => v === 1).length;
          const blocked =
            species === 0 ? model.params.gNa === 0 : model.params.gK === 0;
          return (
            <div
              className={species ? "population potassium" : "population sodium"}
              key={species}
            >
              <div className="population-heading">
                <h3>{species ? "K⁺" : "Na⁺"} チャネル</h3>
                <span>{open} / 32 開</span>
              </div>
              <div
                className="pore-grid"
                role="img"
                aria-label={`${species ? "カリウム" : "ナトリウム"}ゲート 32 個中 ${open} 個が開いています。${blocked ? "コンダクタンスが 0 のため輸送はありません。" : ""}`}
              >
                {Array.from(array).map((state, i) => (
                  <span
                    key={i}
                    className={"pore state-" + state}
                    aria-hidden="true"
                  >
                    <i />
                    {state === 1 && !blocked && <b>{species ? "↑" : "↓"}</b>}
                  </span>
                ))}
              </div>
              <div className="population-bottom">
                <span>
                  {species ? "↑ K⁺ 流出" : "↓ Na⁺ 流入"}
                  {blocked ? " · 遮断" : ""}
                </span>
                <span>
                  HH の開口率{" "}
                  {((species ? s.openK : s.openNa) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="pore-legend">
        <span>
          <i className="open-symbol" /> 開
        </span>
        <span>
          <i /> 閉
        </span>
        <span>
          <i className="unavailable-symbol" /> Na⁺ 不活性化
        </span>
      </div>
      <p className="science-note">
        上から見た模式図です。矢印は主な輸送の向きを示します。乱数シードで固定した Na⁺ 32 個と K⁺ 32 個のチャネルが、電位依存の HH ゲート速度に従います。ケーブルは集団としてのコンダクタンスを使うため、この有限個のサンプルのゆらぎは電位に戻されません。コンダクタンスが 0 でも電位の感知は続き、輸送だけが止まります。
      </p>
    </section>
  );
}
