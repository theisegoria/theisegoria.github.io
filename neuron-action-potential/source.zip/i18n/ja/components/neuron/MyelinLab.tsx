import { useState } from 'react';
import { CableModel } from '@/lib/neuron/model.mjs';

type Trial = { arrivals: number[]; delay: number | null };
export function trial(model: CableModel, intact = false): Trial {
  const test = new CableModel();
  test.params = { ...model.params, current: 0 };
  test.configureMyelin({ ...model.myelin, removed: intact ? [] : model.myelin.removed });
  test.pulse();
  for (let i = 0; i < 4000; i++) test.step();
  const a = test.firstArrival;
  return { arrivals: Array.from(a.slice(0,64)), delay: Number.isFinite(a[63]) && Number.isFinite(a[0]) ? a[63]-a[0] : null };
}
export default function MyelinLab({ model, onChange, onInspect }: {
  model: CableModel; onChange: (config: Partial<CableModel['myelin']>) => void; onInspect: () => void;
}) {
  const [comparison, setComparison] = useState<{ selected: Trial; intact: Trial; key: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const c = model.myelin;
  const key = JSON.stringify([c,model.params.gNa,model.params.gK]);
  const result = comparison?.key === key ? comparison : null;
  const cells = model.membrane.cells;
  const toggle = (id: number) => onChange({removed: c.removed.includes(id) ? c.removed.filter(x=>x!==id) : [...c.removed,id]});
  const compare = () => {
    setBusy(true);
    const experiment = new CableModel();
    experiment.params = {...model.params};
    experiment.configureMyelin({...model.myelin,removed:[...model.myelin.removed]});
    // Yield a paint before the bounded numerical experiment.
    setTimeout(() => { try { setComparison({ selected: trial(experiment), intact: trial(experiment,true), key }); } finally { setBusy(false); } }, 30);
  };
  const delay = (v: number|null) => v === null ? '40 ms 以内に到達せず' : `${v.toFixed(2)} ms`;
  return <section className="myelin-panel" aria-labelledby="myelin-title">
    <p className="eyebrow">ミエリンと伝導</p>
    <div className="section-heading"><h2 id="myelin-title">絶縁を組み立てる。</h2><button onClick={onInspect}>軸索を拡大する ↗</button></div>
    <label className="myelin-enable"><input type="checkbox" checked={c.enabled} onChange={e=>onChange({enabled:e.target.checked,removed:[]})}/> 有髄軸索</label>
    <p>鞘の一つひとつがシュワン細胞一個を表します。すき間にはランヴィエ絞輪が露出し、そこで活動電位が再生されます。</p>
    <fieldset disabled={!c.enabled || busy}>
      <label htmlFor="internode-length">鞘の長さ <output>{c.length} コンパートメント</output></label>
      <input id="internode-length" type="range" min="2" max="10" step="1" value={c.length} onChange={e=>onChange({length:+e.target.value,removed:[]})}/>
      <label htmlFor="node-gap">露出部の間隔 <output>{c.gap} コンパートメント</output></label>
      <input id="node-gap" type="range" min="1" max="4" step="1" value={c.gap} onChange={e=>onChange({gap:+e.target.value,removed:[]})}/>
      <div className="myelin-actions"><button onClick={()=>onChange({removed:[]})}>すべて追加</button><button onClick={()=>onChange({removed:cells.map(x=>x.id)})}>すべて除去</button></div>
      <div className="cell-toggles" aria-label="個々のシュワン細胞">{cells.map(cell=><button key={cell.id} aria-label={`シュワン細胞 ${cell.id+1}`} aria-pressed={cell.present} title={`細胞 ${cell.id+1} を${cell.present?'除去':'追加'}`} onClick={()=>toggle(cell.id)}>{cell.id+1}</button>)}</div>
      <p className="science-note">{cells.filter(x=>x.present).length} / {cells.length} 個の細胞があります · 番号か鞘をタップすると除去されます。長さや間隔を変えると配置が作り直されます。</p>
      <button className="primary-button" onClick={compare}>{busy?'計測中…':'無傷のミエリンと比べる'}</button>
    </fieldset>
    {result && <div className="myelin-result" role="status">
      <div><span>選んだ配置</span><b>{delay(result.selected.delay)}</b></div>
      <div><span>すべての鞘が無傷</span><b>{delay(result.intact.delay)}</b></div>
      <svg viewBox="0 0 300 150" role="img" aria-label="親軸索に沿った位置ごとの最初のスパイク到達時刻。金が選んだ配置、灰色が無傷のミエリン。">
        {[0,10,20,30,40].map(ms=><g key={ms}><line x1="30" x2="280" y1={120-ms*2.5} y2={120-ms*2.5} stroke="#30414b"/><text x="4" y={124-ms*2.5} fill="#b4c2cc" fontSize="10">{ms}</text></g>)}
        {[result.intact,result.selected].map((r,j)=> <path key={j} d={r.arrivals.map((t,i)=>Number.isFinite(t)?`${i===0 || !Number.isFinite(r.arrivals[i-1])?'M':'L'}${30+i/63*250},${120-t*2.5}`:'').join(' ')} fill="none" stroke={j?'#e8bb78':'#92a4ae'} strokeWidth="2"/>)}
        <text x="30" y="143" fill="#b4c2cc" fontSize="11">軸索小丘</text><text x="210" y="143" fill="#b4c2cc" fontSize="11">分岐点</text><text x="30" y="12" fill="#b4c2cc" fontSize="11">刺激からの到達時間 (ms)</text>
      </svg>
      <p className="science-note">金：選んだ配置 · 灰色：無傷。遅延は軸索小丘から分岐点まで。線が欠けている部分は、40 ms 以内に 0 mV を上向きに越えなかったことを示します。どちらの試行も同じ 1 ms のパルスとチャネルコンダクタンスを使います。</p>
    </div>}
    <p className="science-note">形を変えると記録はやり直しになります。鞘を除くと容量とリークが増えますが、節間のチャネルはまばらなままです。髄鞘化をオフにすると元の無髄ケーブルに戻ります。寸法は説明用で、すき間は見やすく拡大しています。</p>
    <a className="science-link" href="https://pmc.ncbi.nlm.nih.gov/articles/PMC1331199/" target="_blank" rel="noreferrer">脱髄と伝導 · モデルの背景 ↗</a>
  </section>;
}
