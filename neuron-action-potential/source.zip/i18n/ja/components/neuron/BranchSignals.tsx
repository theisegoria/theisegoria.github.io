import { CableModel, BRANCHES } from "@/lib/neuron/model.mjs";
import VoltageGraph, { BRANCH_COLORS } from "./VoltageGraph";
export default function BranchSignals({
  model,
  onProbe,
  onView,
  onScenario,
  onPause,
}: {
  model: CableModel;
  onProbe: (i: number) => void;
  onView: () => void;
  onPause: () => void;
  onScenario: (mode: "rest" | "single" | "train") => void;
}) {
  const fork = model.firstArrival[63];
  return (
    <section className="branches-panel" aria-labelledby="branches-title">
      <p className="eyebrow">03 / 分岐と再生</p>
      <div className="section-heading">
        <h2 id="branches-title">一つのスパイク、別々の到達。</h2>
        <button onClick={onView}>分岐を見る ↗</button>
      </div>
      <p>
        局所電流がそれぞれの娘枝を興奮させ、その枝自身の Na⁺ チャネルがスパイクを再生します。ピーク電位が似ていても、同じ瞬間に同じ電位とは限りません。
      </p>
      <div className="scenario-buttons" aria-label="実験">
        <button onClick={() => onScenario("rest")}>静止</button>
        <button onClick={() => onScenario("single")}>スパイクを一つ送る</button>
        <button onClick={() => onScenario("train")}>スパイク列</button>
        <button onClick={onPause}>
          {model.paused ? "実験を再開" : "実験を一時停止"}
        </button>
      </div>
      <VoltageGraph model={model} branches />
      <div
        className="branch-table"
        role="table"
        aria-label="終末の記録"
      >
        <div role="row" className="branch-table-head">
          <span role="columnheader">終末</span>
          <span role="columnheader">電位</span>
          <span role="columnheader">到達¹</span>
          <span role="columnheader">分岐後¹</span>
        </div>
        {BRANCHES.map((b, i) => {
          const arrival = model.firstArrival[b.end];
          return (
            <div role="row" key={b.id}>
              <span role="cell">
                <button
                  aria-label={"終末を記録 " + b.label}
                  aria-pressed={model.probe === b.end}
                  onClick={() => onProbe(b.end)}
                >
                  <i style={{ background: BRANCH_COLORS[i] }} />
                  {b.label}
                </button>
              </span>
              <span role="cell">
                {model.v[b.end].toFixed(1)} <small>mV</small>
              </span>
              <span role="cell">
                {Number.isFinite(arrival) ? arrival.toFixed(2) + " ms" : "–"}
              </span>
              <span role="cell">
                {Number.isFinite(arrival) && Number.isFinite(fork)
                  ? "+" + (arrival - fork).toFixed(2) + " ms"
                  : "–"}
              </span>
            </div>
          );
        })}
      </div>
      <p className="science-note">
        ¹ リセット後に初めて 0 mV を上向きに越えた時刻。表示は 40 ms 分です。単発スパイクの実験は 40 ms で自動的に一時停止します。この5本の説明用の分岐は長さも直径も異なります。実際の分岐軸索では伝導が遅れたり途切れたりすることもあり、終末の波形や到達時刻が一致するとは限りません。
      </p>
      <a
        className="science-link"
        href="https://doi.org/10.1371/journal.pcbi.0030079"
        target="_blank"
        rel="noreferrer"
      >
        分岐での伝導とチャネルノイズ · Faisal & Laughlin（2007）↗
      </a>
    </section>
  );
}
