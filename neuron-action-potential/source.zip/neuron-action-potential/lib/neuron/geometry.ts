import * as THREE from "three";
export const soma = new THREE.Vector3(-4.15, 0, 0);
export const axonCurve = new THREE.CatmullRomCurve3([
  new THREE.Vector3(-3.45, 0, 0),
  new THREE.Vector3(-2.3, -0.2, 0),
  new THREE.Vector3(-0.4, -0.55, 0.1),
  new THREE.Vector3(1.6, -0.48, -0.15),
  new THREE.Vector3(3.3, 0.05, 0),
  new THREE.Vector3(5.3, 0.1, 0.15),
  new THREE.Vector3(6.4, -0.15, 0),
]);
export function tube(
  points: THREE.Vector3[] | THREE.CatmullRomCurve3,
  radius: number,
  endRadius: number,
  segments = 36,
  cable = false,
  compartment = 0,
) {
  const curve =
    points instanceof THREE.CatmullRomCurve3
      ? points
      : new THREE.CatmullRomCurve3(points);
  const geo = new THREE.TubeGeometry(curve, segments, 1, 8, false);
  const p = geo.attributes.position;
  const u = new Float32Array(p.count);
  for (let j = 0; j <= segments; j++) {
    const t = j / segments,
      c = curve.getPointAt(t),
      r = radius + (endRadius - radius) * t;
    for (let k = 0; k <= 8; k++) {
      const i = j * 9 + k;
      p.setXYZ(
        i,
        c.x + (p.getX(i) - c.x) * r,
        c.y + (p.getY(i) - c.y) * r,
        c.z + (p.getZ(i) - c.z) * r,
      );
      u[i] = cable ? t : compartment;
    }
  }
  geo.setAttribute("aCable", new THREE.BufferAttribute(u, 1));
  geo.computeVertexNormals();
  return geo;
}
export function somaGeometry() {
  const g = new THREE.SphereGeometry(1, 48, 32),
    p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i),
      y = p.getY(i),
      z = p.getZ(i);
    const f =
      1 +
      0.065 * Math.sin(x * 7 + y * 3) * Math.cos(z * 8 - y * 3) +
      0.025 * Math.sin(y * 15 + z * 8);
    p.setXYZ(i, soma.x + x * 0.86 * f, y * 1.02 * f, z * 0.69 * f);
  }
  g.setAttribute(
    "aCable",
    new THREE.BufferAttribute(new Float32Array(p.count), 1),
  );
  g.computeVertexNormals();
  return g;
}
export function morphology() {
  const parts: THREE.BufferGeometry[] = [];
  const angles = [0.85, 1.45, 2.05, 2.65, 3.25, 3.8, 4.35, 5.0];
  for (let i = 0; i < angles.length; i++) {
    const a = angles[i],
      len = 2.1 + (i % 3) * 0.38,
      dir = new THREE.Vector3(Math.cos(a), Math.sin(a), Math.sin(i * 5) * 0.28);
    const base = soma.clone().addScaledVector(dir, 0.63),
      mid = soma.clone().addScaledVector(dir, 1.3),
      tip = soma.clone().addScaledVector(dir, len);
    tip.z += Math.cos(i * 3) * 0.5;
    parts.push(tube([base, mid, tip], 0.21, 0.047));
    for (let j = 0; j < 2; j++) {
      const split = mid.clone().lerp(tip, 0.3 + j * 0.28),
        ang = a + (j ? -0.5 : 0.55),
        side = split
          .clone()
          .add(
            new THREE.Vector3(
              Math.cos(ang) * 1.2,
              Math.sin(ang) * 1.2,
              Math.sin(i + j) * 0.4,
            ),
          );
      parts.push(
        tube(
          [
            split,
            split
              .clone()
              .lerp(side, 0.55)
              .add(new THREE.Vector3(0.08, 0, 0.08)),
            side,
          ],
          0.062,
          0.011,
          18,
        ),
      );
      const twig = side
        .clone()
        .add(
          new THREE.Vector3(
            Math.cos(ang + 0.6) * 0.55,
            Math.sin(ang + 0.6) * 0.55,
            0.12,
          ),
        );
      parts.push(
        tube([side.clone().lerp(split, 0.3), side, twig], 0.025, 0.004, 12),
      );
    }
  }
  const root = axonCurve.getPointAt(1);
  for (let i = 0; i < 5; i++) {
    const end = new THREE.Vector3(
        7.65 + (i % 2) * 0.65,
        (i - 2) * 0.69,
        Math.sin(i * 2) * 0.55,
      ),
      mid = root.clone().lerp(end, 0.55);
    mid.y += (i - 2) * 0.2;
    parts.push(tube([root, mid, end], 0.09, 0.025, 24, false, 1));
  }
  return parts;
}
export const channelSites = Array.from({ length: 14 }, (_, i) => ({
  t: 0.08 + i * 0.063,
  index: Math.round((0.08 + i * 0.063) * 63),
}));
export function membranePosition(t: number, angle: number, radius: number) {
  const p = axonCurve.getPointAt(t),
    tangent = axonCurve.getTangentAt(t),
    normal = new THREE.Vector3(0, Math.cos(angle), Math.sin(angle));
  normal.addScaledVector(tangent, -normal.dot(tangent)).normalize();
  return { p: p.addScaledVector(normal, radius), normal };
}
