"use client";
import { CableModel } from "@/lib/neuron/model.mjs";
export default function MembraneInset({ model }: { model: CableModel }) {
  const s = model.snapshot();
  const gapNa = 4 + Math.sqrt(s.openNa) * 21,
    gapK = 4 + Math.sqrt(s.openK) * 21;
  return (
    <div className="membrane-inset">
      <div className="inset-head">
        <span>MEMBRANE DETAIL</span>
        <span>schematic section</span>
      </div>
      <svg
        viewBox="0 0 286 135"
        role="img"
        aria-label="Membrane cross-section. Sodium flows inward through mint channels; potassium flows outward through gold channels. Pore width represents the open fraction."
      >
        <text x="4" y="19" className="space-label">
          EXTRACELLULAR
        </text>
        <text x="4" y="128" className="space-label">
          INTRACELLULAR
        </text>
        <rect x="0" y="49" width="286" height="31" fill="#1a2d37" />
        {Array.from({ length: 25 }, (_, i) => (
          <g key={i} opacity=".62">
            <path
              d={`M${i * 12} 55v18m3-18v18`}
              stroke="#546772"
              strokeWidth="1"
            />
            <circle cx={i * 12 + 1} cy="50" r="3" fill="#708792" />
            <circle cx={i * 12 + 1} cy="79" r="3" fill="#708792" />
          </g>
        ))}
        {[
          {
            x: 88,
            gap: gapNa,
            color: "#a1e8c9",
            clock: model.fluxNa[model.probe],
            na: true,
          },
          {
            x: 214,
            gap: gapK,
            color: "#eab67a",
            clock: model.fluxK[model.probe],
            na: false,
          },
        ].map((o) => (
          <g key={o.x}>
            <rect x={o.x - 27} y="45" width="54" height="40" fill="#0e1922" />
            <rect
              x={o.x - o.gap - 9}
              y="43"
              width="11"
              height="43"
              rx="5"
              fill={o.color}
              opacity=".8"
            />
            <rect
              x={o.x + o.gap - 2}
              y="43"
              width="11"
              height="43"
              rx="5"
              fill={o.color}
              opacity=".8"
            />
            {Array.from({ length: 4 }, (_, i) => {
              const t = (o.clock + i * 0.25) % 1,
                y = o.na ? 27 + t * 78 : 105 - t * 78;
              return (
                <circle
                  key={i}
                  cx={o.x}
                  cy={y}
                  r="3"
                  fill={o.color}
                  opacity={Math.min(1, t * 8, (1 - t) * 8)}
                />
              );
            })}
            <text
              x={o.x + 20}
              y={o.na ? 33 : 107}
              fill={o.color}
              className="ion-label"
            >
              {o.na ? "Na⁺ ↓" : "K⁺ ↑"}
            </text>
          </g>
        ))}
      </svg>
      <div className="channel-readouts">
        <div>
          <span className="na-dot" />
          Na⁺
          <strong>
            {s.m > 0.45 && s.h < 0.3
              ? "Inactivated"
              : s.openNa > 0.03
                ? "Open"
                : "Mostly closed"}
          </strong>
        </div>
        <div>
          <span className="k-dot" />
          K⁺<strong>{s.openK > 0.06 ? "Open" : "Mostly closed"}</strong>
        </div>
      </div>
      <div className="open-fractions">
        <span>m³h · {(s.openNa * 100).toFixed(1)}%</span>
        <span>n⁴ · {(s.openK * 100).toFixed(1)}%</span>
      </div>
    </div>
  );
}
