"use client";
import { useEffect, useRef } from "react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Pause, Play, RotateCcw, Zap } from "lucide-react";
export type Parameters = {
  current: number;
  gNa: number;
  gK: number;
  speed: number;
};
type Props = {
  params: Parameters;
  paused: boolean;
  labels: boolean;
  ions: boolean;
  setParam: (k: keyof Parameters, v: number) => void;
  togglePause: () => void;
  reset: () => void;
  pulse: () => void;
  setLabels: (b: boolean) => void;
  setIons: (b: boolean) => void;
};
export default function SimulationControls(p: Props) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    root.current?.querySelectorAll('[role="slider"]').forEach((element, i) => {
      element.setAttribute(
        "aria-label",
        [
          "Injected current",
          "Sodium conductance",
          "Potassium conductance",
          "Simulation speed",
        ][i],
      );
    });
  }, []);
  return (
    <div ref={root}>
      <div className="control-heading">
        <p className="eyebrow">EXPERIMENT</p>
        <span className="live-indicator">
          <i className={p.paused ? "paused" : ""} />
          {p.paused ? "PAUSED" : "RUNNING"}
        </span>
      </div>
      <h2>Drive the signal.</h2>
      <div className="transport">
        <button className="primary-button" onClick={p.togglePause}>
          {p.paused ? <Play size={15} /> : <Pause size={15} />}{" "}
          {p.paused ? "Resume" : "Pause"}
        </button>
        <button
          className="icon-button"
          onClick={p.reset}
          title="Reset parameters, voltage and time"
          aria-label="Reset simulation"
        >
          <RotateCcw size={16} />
        </button>
        <button
          className="pulse-button"
          onClick={p.pulse}
          disabled={p.paused}
          title="Add 35 μA/cm² for 1 simulated ms"
        >
          <Zap size={14} /> Pulse
        </button>
      </div>
      {[
        {
          key: "current" as const,
          label: "Injected current",
          unit: "μA/cm²",
          max: 40,
          step: 0.5,
          note: "Continuous input at the axon hillock.",
        },
        {
          key: "gNa" as const,
          label: "Sodium conductance",
          unit: "mS/cm²",
          max: 200,
          step: 1,
          note: "ḡNa · fast activation, then inactivation.",
        },
        {
          key: "gK" as const,
          label: "Potassium conductance",
          unit: "mS/cm²",
          max: 80,
          step: 1,
          note: "ḡK · delayed activation and recovery.",
        },
      ].map((o) => (
        <div className={"control-field " + o.key} key={o.key}>
          <label id={o.key + "-label"}>
            {o.label}
            <output>
              {p.params[o.key]} <small>{o.unit}</small>
            </output>
          </label>
          <Slider
            aria-labelledby={o.key + "-label"}
            value={[p.params[o.key]]}
            min={0}
            max={o.max}
            step={o.step}
            onValueChange={(v) => p.setParam(o.key, v[0])}
          />
          <p>{o.note}</p>
        </div>
      ))}
      <div className="speed-control">
        <label id="speed-label">
          Simulation speed <output>{p.params.speed.toFixed(1)}×</output>
        </label>
        <Slider
          aria-labelledby="speed-label"
          value={[p.params.speed]}
          min={0.1}
          max={4}
          step={0.1}
          onValueChange={(v) => p.setParam("speed", v[0])}
        />
        <p>1× = 8 ms of activity per second</p>
      </div>
      <div className="view-options">
        <label htmlFor="show-ions">
          Ion particles
          <Switch id="show-ions" checked={p.ions} onCheckedChange={p.setIons} />
        </label>
        <label htmlFor="show-labels">
          Anatomy labels
          <Switch
            id="show-labels"
            checked={p.labels}
            onCheckedChange={p.setLabels}
          />
        </label>
      </div>
    </div>
  );
}
