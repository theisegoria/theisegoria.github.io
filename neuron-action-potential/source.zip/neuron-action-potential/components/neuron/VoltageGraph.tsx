"use client";
import { useEffect, useRef } from "react";
import { CableModel } from "@/lib/neuron/model.mjs";
export default function VoltageGraph({ model }: { model: CableModel }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let raf = 0,
      last = 0;
    const canvas = ref.current!;
    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      if (now - last < 40) return;
      last = now;
      const box = canvas.getBoundingClientRect(),
        dpr = Math.min(devicePixelRatio, 2);
      if (
        canvas.width !== Math.round(box.width * dpr) ||
        canvas.height !== Math.round(box.height * dpr)
      ) {
        canvas.width = Math.round(box.width * dpr);
        canvas.height = Math.round(box.height * dpr);
      }
      const c = canvas.getContext("2d")!;
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      const w = box.width,
        h = box.height;
      c.clearRect(0, 0, w, h);
      const left = 43,
        right = w - 12,
        top = 10,
        bottom = h - 24;
      const end = Math.max(40, model.time),
        start = end - 40,
        x = (t: number) => left + ((t - start) / 40) * (right - left),
        y = (v: number) => top + ((50 - v) / 140) * (bottom - top);
      c.font = "11px ui-monospace, SFMono-Regular, monospace";
      c.lineWidth = 1;
      for (const v of [-80, -40, 0, 40]) {
        c.strokeStyle = "#20303a";
        c.beginPath();
        c.moveTo(left, y(v));
        c.lineTo(right, y(v));
        c.stroke();
        c.fillStyle = "#8496a5";
        c.fillText(String(v), v < 0 ? 10 : 17, y(v) + 4);
      }
      for (let k = 0; k <= 4; k++) {
        let t = start + k * 10;
        c.fillStyle = "#8496a5";
        c.fillText(t.toFixed(0), Math.min(right - 12, x(t) - 6), h - 5);
      }
      c.strokeStyle = "#59707a";
      c.setLineDash([3, 5]);
      c.beginPath();
      c.moveTo(left, y(-65));
      c.lineTo(right, y(-65));
      c.stroke();
      c.setLineDash([]);
      c.save();
      c.beginPath();
      c.rect(left, top, right - left, bottom - top);
      c.clip();
      for (let series = 0; series < 2; series++) {
        c.beginPath();
        c.strokeStyle = series ? "#a6eccb" : "#64798e";
        c.lineWidth = series ? 1.8 : 1;
        c.setLineDash(series ? [] : [3, 4]);
        let first = true;
        for (let j = 0; j < model.samples; j++) {
          const i =
              (model.head - model.samples + j + model.traceT.length) %
              model.traceT.length,
            t = model.traceT[i];
          if (t < start - 0.2) continue;
          const v = series ? model.traceV[i] : model.traceSoma[i];
          if (first) {
            c.moveTo(x(t), y(v));
            first = false;
          } else c.lineTo(x(t), y(v));
        }
        c.stroke();
      }
      c.setLineDash([]);
      const v = model.v[model.probe];
      c.fillStyle = "#bcf3d8";
      c.shadowColor = "#9be4c4";
      c.shadowBlur = 9;
      c.beginPath();
      c.arc(x(model.time), y(v), 3, 0, Math.PI * 2);
      c.fill();
      c.restore();
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [model]);
  return (
    <canvas
      ref={ref}
      className="voltage-canvas"
      role="img"
      aria-label="Live membrane voltage at the recording site in mint, compared with the axon hillock in grey. The horizontal window is 40 milliseconds."
    />
  );
}
