"use client";
import {
  useEffect,
  useMemo,
  useRef,
  Suspense,
  Component,
  type ReactNode,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html, Line, AdaptiveDpr } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { CableModel, COUNT } from "@/lib/neuron/model.mjs";
import {
  axonCurve,
  somaGeometry,
  morphology,
  tube,
  channelSites,
  membranePosition,
} from "@/lib/neuron/geometry";
import { makeVoltageMaterial } from "./VoltageMaterial";
const NA = "#9ae8c7",
  K = "#eab67a";
type Props = {
  model: CableModel;
  probeIndex: number;
  labels: boolean;
  ions: boolean;
  focus: boolean;
  viewRevision: number;
  onProbe: (i: number) => void;
};
function MembraneChannels({ model }: { model: CableModel }) {
  const naRef = useRef<THREE.InstancedMesh>(null),
    kRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    [naRef, kRef].forEach((ref, species) => {
      if (!ref.current) return;
      channelSites.forEach((site, si) => {
        const angle = species === 0 ? 1.14 : 2.1,
          { p, normal } = membranePosition(site.t, angle, 0.16);
        const tangent = axonCurve.getTangentAt(site.t),
          side = new THREE.Vector3().crossVectors(normal, tangent).normalize();
        const open =
          species === 0
            ? model.m[site.index] ** 3 * model.h[site.index]
            : model.n[site.index] ** 4;
        const spread = 0.037 + 0.15 * Math.sqrt(open);
        for (let j = 0; j < 5; j++) {
          const a = (j / 5) * Math.PI * 2;
          dummy.position
            .copy(p)
            .addScaledVector(tangent, Math.cos(a) * spread)
            .addScaledVector(side, Math.sin(a) * spread);
          dummy.quaternion.setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            normal,
          );
          dummy.scale.set(0.027, 0.11, 0.027);
          dummy.updateMatrix();
          ref.current!.setMatrixAt(si * 5 + j, dummy.matrix);
        }
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      <instancedMesh
        ref={naRef}
        args={[undefined, undefined, 70]}
        frustumCulled={false}
      >
        <cylinderGeometry args={[1, 1, 1, 6]} />
        <meshStandardMaterial
          color={NA}
          emissive={NA}
          emissiveIntensity={0.22}
          roughness={0.4}
        />
      </instancedMesh>
      <instancedMesh
        ref={kRef}
        args={[undefined, undefined, 70]}
        frustumCulled={false}
      >
        <cylinderGeometry args={[1, 1, 1, 6]} />
        <meshStandardMaterial
          color={K}
          emissive={K}
          emissiveIntensity={0.16}
          roughness={0.4}
        />
      </instancedMesh>
    </>
  );
}
function IonParticles({ model }: { model: CableModel }) {
  const refs = [
    useRef<THREE.InstancedMesh>(null),
    useRef<THREE.InstancedMesh>(null),
  ];
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    refs.forEach((ref, species) => {
      if (!ref.current) return;
      channelSites.forEach((site, si) => {
        for (let j = 0; j < 9; j++) {
          const clock =
            species === 0 ? model.fluxNa[site.index] : model.fluxK[site.index];
          const progress = (clock + j / 9 + si * 0.13) % 1;
          // Ions pass radially through the pore. At the wrap boundary their size fades to zero.
          const radius =
            species === 0 ? 0.56 - progress * 0.5 : 0.06 + progress * 0.5;
          const { p } = membranePosition(
            site.t +
              Math.sin(j * 9 + si) * 0.002 * (1 - Math.sin(progress * Math.PI)),
            species === 0 ? 1.14 : 2.1,
            radius,
          );
          dummy.position.copy(p);
          const scale = 0.027 * Math.min(1, progress * 12, (1 - progress) * 12);
          dummy.scale.setScalar(scale);
          dummy.updateMatrix();
          ref.current!.setMatrixAt(si * 9 + j, dummy.matrix);
        }
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      {refs.map((ref, i) => (
        <instancedMesh
          key={i}
          ref={ref}
          args={[undefined, undefined, 126]}
          frustumCulled={false}
        >
          <sphereGeometry args={[1, 6, 5]} />
          <meshBasicMaterial color={i ? K : NA} toneMapped={false} />
        </instancedMesh>
      ))}
    </>
  );
}
function Neuron({ model, labels, ions, onProbe }: Props) {
  const field = useMemo(() => new Float32Array(COUNT * 4), []);
  const texture = useMemo(() => {
    const t = new THREE.DataTexture(
      field,
      COUNT,
      1,
      THREE.RGBAFormat,
      THREE.FloatType,
    );
    t.minFilter = THREE.LinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.needsUpdate = true;
    return t;
  }, [field]);
  const material = useMemo(() => makeVoltageMaterial(texture), [texture]);
  const soma = useMemo(somaGeometry, []),
    dendrites = useMemo(morphology, []),
    axon = useMemo(() => tube(axonCurve, 0.145, 0.105, 180, true), []);
  const probe = axonCurve.getPointAt(model.probe / 63);
  useEffect(
    () => () => {
      texture.dispose();
      material.dispose();
      soma.dispose();
      axon.dispose();
      dendrites.forEach((g) => g.dispose());
    },
    [texture, material, soma, axon, dendrites],
  );
  useFrame(() => {
    for (let i = 0; i < COUNT; i++) {
      field[i * 4] = (model.v[i] + 85) / 130;
      field[i * 4 + 1] = model.m[i] ** 3 * model.h[i];
      field[i * 4 + 2] = model.n[i] ** 4;
      field[i * 4 + 3] = 1;
    }
    texture.needsUpdate = true;
  });
  return (
    <group>
      <mesh geometry={soma} material={material} />
      <mesh position={[-4.25, 0.04, 0.47]} scale={[0.4, 0.47, 0.3]}>
        <sphereGeometry args={[1, 36, 24]} />
        <meshPhysicalMaterial
          color="#203e4c"
          roughness={0.32}
          clearcoat={0.4}
        />
      </mesh>
      {dendrites.map((g, i) => (
        <mesh key={i} geometry={g} material={material} />
      ))}
      <mesh geometry={axon} material={material} />
      <mesh
        geometry={useMemo(() => tube(axonCurve, 0.3, 0.3, 90, true), [])}
        onClick={(e) => {
          e.stopPropagation();
          let best = 0,
            dist = Infinity;
          for (let i = 0; i < 64; i++) {
            const d = axonCurve.getPointAt(i / 63).distanceToSquared(e.point);
            if (d < dist) {
              dist = d;
              best = i;
            }
          }
          onProbe(best);
        }}
        onPointerOver={() => (document.body.style.cursor = "crosshair")}
        onPointerOut={() => (document.body.style.cursor = "auto")}
      >
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      {[0, 1, 2, 3, 4].map((i) => (
        <mesh
          key={i}
          position={[
            7.65 + (i % 2) * 0.65,
            (i - 2) * 0.69,
            Math.sin(i * 2) * 0.55,
          ]}
        >
          <sphereGeometry args={[0.095, 12, 8]} />
          <meshStandardMaterial
            color="#6daaa8"
            emissive="#365554"
            emissiveIntensity={0.3}
          />
        </mesh>
      ))}
      <MembraneChannels model={model} />
      {ions && <IonParticles model={model} />}
      <mesh position={probe}>
        <sphereGeometry args={[0.21, 24, 12]} />
        <meshBasicMaterial
          color="#edf4c9"
          wireframe
          transparent
          opacity={0.18}
        />
      </mesh>
      {labels && (
        <>
          <Html position={[-6.9, 2.7, 0]} center className="anatomy-label">
            <span>DENDRITES</span>
            <small>receive</small>
          </Html>
          <Html position={[-4.7, -1.65, 0.2]} center className="anatomy-label">
            <span>SOMA</span>
            <small>integrate</small>
          </Html>
          <Html position={[2, -1.3, 0.2]} center className="anatomy-label">
            <span>AXON</span>
            <small>propagate →</small>
          </Html>
          <Html position={[7.7, 2.05, 0]} center className="anatomy-label">
            <span>TERMINALS</span>
            <small>transmit</small>
          </Html>
        </>
      )}
      <Line
        points={[probe.toArray(), [probe.x, probe.y + 0.8, probe.z]]}
        color="#d2ddb0"
        lineWidth={0.8}
        transparent
        opacity={0.55}
      />
      <Html
        position={[probe.x, probe.y + 0.92, probe.z]}
        center
        className="probe-label"
      >
        RECORDING SITE
      </Html>
    </group>
  );
}
function CameraRig({
  focus,
  viewRevision,
  model,
}: {
  focus: boolean;
  viewRevision: number;
  model: CableModel;
}) {
  const controls = useRef<any>(null);
  const { camera, size } = useThree();
  useEffect(() => {
    const p = axonCurve.getPointAt(model.probe / 63);
    if (focus) {
      camera.position.set(p.x, p.y + 1.7, p.z + 3.4);
      controls.current?.target.copy(p);
    } else {
      camera.position.set(
        0.3,
        2.1,
        Math.max(
          13.4,
          18.5 /
            (2 * Math.tan((39 * Math.PI) / 360) * (size.width / size.height)),
        ),
      );
      controls.current?.target.set(0.1, 0, 0);
    }
    controls.current?.update();
  }, [focus, viewRevision, camera, size.width, size.height, model]);
  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.09}
      minDistance={1.25}
      maxDistance={36}
      enablePan
      rotateSpeed={0.5}
    />
  );
}
function DepthDust() {
  const points = useMemo(() => {
    const a = new Float32Array(150 * 3);
    for (let i = 0; i < 150; i++) {
      a[i * 3] = Math.sin(i * 54.21) * 18;
      a[i * 3 + 1] = Math.cos(i * 21.67) * 10;
      a[i * 3 + 2] = -3 - Math.abs(Math.sin(i * 3.81)) * 10;
    }
    return a;
  }, []);
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[points, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#567282"
        size={0.025}
        transparent
        opacity={0.35}
        depthWrite={false}
      />
    </points>
  );
}
class SceneBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="webgl-error">
        The 3D view needs WebGL 2. Enable hardware acceleration or try a current
        browser. The model and voltage trace remain available.
      </div>
    ) : (
      this.props.children
    );
  }
}
export default function NeuronScene(props: Props) {
  return (
    <SceneBoundary>
      <Canvas
        dpr={[1, 1.65]}
        camera={{ position: [0.3, 2.1, 19.3], fov: 39, near: 0.1, far: 90 }}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
        }}
        fallback={
          <div className="webgl-error">
            WebGL is unavailable. The live model and graph remain available
            below.
          </div>
        }
      >
        <fog attach="fog" args={["#0b141d", 24, 54]} />
        <ambientLight intensity={0.5} />
        <directionalLight position={[-4, 5, 8]} intensity={2} color="#bfe6f4" />
        <pointLight position={[4, -2, 5]} intensity={20} color="#8fcfb8" />
        <pointLight position={[-6, 3, -2]} intensity={25} color="#649dd9" />
        <Suspense fallback={null}>
          <Neuron {...props} />
          <DepthDust />
          <EffectComposer multisampling={0}>
            <Bloom
              intensity={0.32}
              luminanceThreshold={0.85}
              luminanceSmoothing={0.35}
              mipmapBlur
            />
          </EffectComposer>
        </Suspense>
        <CameraRig
          focus={props.focus}
          viewRevision={props.viewRevision}
          model={props.model}
        />
        <AdaptiveDpr pixelated />
      </Canvas>
    </SceneBoundary>
  );
}
