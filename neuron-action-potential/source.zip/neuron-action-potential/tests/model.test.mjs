import assert from "node:assert/strict";
import { CableModel, rates, COUNT } from "../lib/neuron/model.mjs";
function run(params = {}, duration = 80, dt = 0.01) {
  const m = new CableModel();
  Object.assign(m.params, params);
  const peaks = Array(COUNT).fill(-Infinity),
    first = Array(COUNT).fill(null);
  for (let t = 0; t < duration; t += dt) {
    m.step(dt);
    for (let i = 0; i < COUNT; i++) {
      assert(Number.isFinite(m.v[i]));
      assert(m.v[i] > -110 && m.v[i] < 65);
      peaks[i] = Math.max(peaks[i], m.v[i]);
      if (m.v[i] > 0 && first[i] === null) first[i] = m.time;
    }
  }
  return { m, peaks, first };
}
for (const v of [-40, -55])
  assert(rates(v).every(Number.isFinite), "removable rate singularity");
const rest = run({ current: 0 });
assert.equal(rest.m.spikes, 0);
assert(Math.abs(rest.m.v[0] + 65) < 0.05);
const active = run();
assert(active.m.spikes > 3);
assert(
  active.first[0] < active.first[18] && active.first[18] < active.first[63],
);
assert(
  active.peaks.every((v) => v > 20),
  "spikes reach every compartment",
);
const blocked = run({ gNa: 0 });
assert.equal(blocked.m.spikes, 0);
assert(blocked.peaks[63] < -60);
const low = run({ current: 10 }),
  high = run({ current: 30 });
assert(high.m.spikes > low.m.spikes, "current changes firing rate");
const fine = run({}, 25, 0.005);
assert(
  Math.abs(fine.first[63] - active.first[63]) < 0.35,
  "propagation converges when timestep is halved",
);
for (const params of [
  { current: 40, gNa: 200, gK: 0 },
  { current: 40, gNa: 0, gK: 80 },
  { current: 0, gNa: 200, gK: 80 },
])
  run(params, 50);
const paused = new CableModel();
paused.paused = true;
paused.advance(1);
assert.equal(paused.time, 0);
paused.paused = false;
paused.advance(0.05);
assert(paused.time > 0);
paused.reset();
assert.equal(paused.time, 0);
assert.equal(paused.v[18], -65);
const pulse = new CableModel();
pulse.params.current = 0;
pulse.pulse();
for (let i = 0; i < 2000; i++) pulse.step();
assert(pulse.spikes >= 1);
console.log(
  "PASS: rest, spiking, propagation, sodium blockade, current sensitivity, numerical convergence, parameter extremes, pause/reset and stimulus pulse.",
);
console.log(
  JSON.stringify({
    arrivalMs: {
      hillock: active.first[0],
      probe: active.first[18],
      terminal: active.first[63],
    },
    peakMv: active.peaks[18],
    spikes80ms: active.m.spikes,
  }),
);
