"use client";
import { lazy, Suspense, useState, useEffect, useRef, memo } from "react";
import {
  Activity,
  Move,
  Focus,
  Maximize2,
  ArrowUpRight,
  ChevronDown,
} from "lucide-react";
import { CableModel, DEFAULTS } from "@/lib/neuron/model.mjs";
import { registerSimulationTools } from "@/lib/neuron/webmcp";
import SimulationControls, {
  type Parameters,
} from "@/components/neuron/SimulationControls";
import VoltageGraph from "@/components/neuron/VoltageGraph";
import MembraneInset from "@/components/neuron/MembraneInset";
const NeuronScene = memo(lazy(() => import("@/components/neuron/NeuronScene")));
export default function Home() {
  const [model] = useState(() => new CableModel());
  const [mounted, setMounted] = useState(false);
  const [params, setParams] = useState<Parameters>({ ...DEFAULTS });
  const [paused, setPaused] = useState(false);
  const [labels, setLabels] = useState(true),
    [ions, setIons] = useState(true),
    [focus, setFocus] = useState(false),
    [viewRevision, setViewRevision] = useState(0);
  const [live, setLive] = useState(() => model.snapshot());
  const [pulseNote, setPulseNote] = useState("");
  const pulseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onProbe = useRef((i: number) => {
    model.setProbe(i);
    setLive(model.snapshot());
  }).current;
  useEffect(() => {
    setMounted(true);
    let raf = 0,
      previous = performance.now(),
      lastUI = 0;
    const tick = (now: number) => {
      model.advance((now - previous) / 1000);
      previous = now;
      if (now - lastUI > 66) {
        setLive(model.snapshot());
        lastUI = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const unregister = registerSimulationTools(model, () => {
      setParams({ ...model.params });
      setPaused(model.paused);
      setLive(model.snapshot());
    });
    return () => {
      cancelAnimationFrame(raf);
      unregister();
      if (pulseTimer.current) clearTimeout(pulseTimer.current);
    };
  }, [model]);
  const setParam = (k: keyof Parameters, v: number) => {
    model.params[k] = v;
    setParams({ ...model.params });
  };
  const togglePause = () => {
    model.paused = !model.paused;
    setPaused(model.paused);
  };
  const reset = () => {
    model.params = { ...DEFAULTS };
    model.paused = false;
    model.probe = 18;
    model.reset();
    setParams({ ...DEFAULTS });
    setPaused(false);
    setFocus(false);
    setViewRevision((n) => n + 1);
    setLive(model.snapshot());
    setPulseNote("");
  };
  const pulse = () => {
    model.pulse();
    setPulseNote("+35 μA/cm² · 1 ms");
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    pulseTimer.current = setTimeout(() => setPulseNote(""), 1800);
  };
  return (
    <main className="lab">
      <header>
        <div className="brand">
          <Activity size={24} strokeWidth={1.4} />
          <span>MEMBRANE</span>
        </div>
        <span className="eyebrow">INTERACTIVE NEUROSCIENCE</span>
        <span className="edition">
          FIGURE <b>01</b>
          <span className="edition-line" />
          LIVE MODEL
        </span>
      </header>
      <div className="workspace">
        <div className="figure-column">
          <section className="visual" aria-label="Interactive 3D neuron">
            <div className="figure-title">
              <p className="eyebrow">CELLULAR ELECTROPHYSIOLOGY</p>
              <h1>Action potential</h1>
              <p>One neuron. A travelling electrical signal.</p>
            </div>
            <div className="scene-badge">
              <span className="na-dot" />{" "}
              {focus ? "MEMBRANE CLOSE-UP" : "MULTIPOLAR NEURON"}
            </div>
            <div className="scene-canvas">
              {mounted && (
                <Suspense
                  fallback={
                    <div className="scene-loading">Preparing the neuron…</div>
                  }
                >
                  <NeuronScene
                    model={model}
                    probeIndex={model.probe}
                    labels={labels && !focus}
                    ions={ions}
                    focus={focus}
                    viewRevision={viewRevision}
                    onProbe={onProbe}
                  />
                </Suspense>
              )}
            </div>
            <div className="scene-tools">
              <button
                aria-pressed={focus}
                onClick={() => setFocus(!focus)}
                title="Inspect channels at the recording site"
              >
                <Focus size={16} />
                {focus ? "Whole neuron" : "Inspect membrane"}
              </button>
              <button
                className="icon-button"
                aria-label="Reset camera"
                onClick={() => {
                  setFocus(false);
                  setViewRevision((n) => n + 1);
                }}
              >
                <Maximize2 size={16} />
              </button>
            </div>
            <div className="voltage-legend">
              <span>MEMBRANE POTENTIAL</span>
              <div className="voltage-ramp" />
              <div>
                <span>−80</span>
                <span>−65</span>
                <span>+40 mV</span>
              </div>
            </div>
            <div className="scene-foot">
              <span>
                <Move size={13} /> Drag to orbit · Scroll to zoom · Right-drag
                to pan
              </span>
              <span>Click axon to move probe</span>
            </div>
            <span role="status" className="pulse-note">
              {pulseNote}
            </span>
          </section>
          <section
            className="trace-panel"
            aria-label="Membrane potential recording"
          >
            <div className="trace-header">
              <div>
                <p className="eyebrow">
                  MEMBRANE POTENTIAL <span className="unit">mV</span>
                </p>
                <div className="trace-key">
                  <span>
                    <i />
                    Recording site · {Math.round((model.probe / 63) * 100)}%
                    along axon
                  </span>
                  <span>
                    <i />
                    Hillock
                  </span>
                </div>
              </div>
              <div className="live-voltage">
                <strong>{live.v.toFixed(1)}</strong>
                <span>mV</span>
                <small className={"phase " + live.phase.toLowerCase()}>
                  {live.phase}
                </small>
              </div>
            </div>
            <VoltageGraph model={model} />
            <div className="trace-foot">
              <span>40 ms window · Resting reference −65 mV</span>
              <span>
                t = <b>{live.time.toFixed(1)}</b> ms
              </span>
            </div>
          </section>
        </div>
        <aside className="controls">
          <SimulationControls
            params={params}
            paused={paused}
            labels={labels}
            ions={ions}
            setParam={setParam}
            togglePause={togglePause}
            reset={reset}
            pulse={pulse}
            setLabels={setLabels}
            setIons={setIons}
          />
          <MembraneInset model={model} />
        </aside>
      </div>
      <footer>
        <div className="figure-caption">
          <span className="caption-number">01</span>
          <p>
            Depolarization admits <span className="sodium-text">Na⁺</span>.
            Delayed <span className="potassium-text">K⁺</span> efflux restores
            the membrane potential.
            <br />
            <span>
              Follow the green wave along the axon; inspect a membrane patch to
              see the gates respond.
            </span>
          </p>
        </div>
        <details className="model-details">
          <summary>
            About the model <ChevronDown size={14} />
          </summary>
          <div>
            <p>
              64 electrically coupled compartments solve a Hodgkin–Huxley cable
              with voltage-dependent m, h and n gates. Injected current enters
              the first four compartments. Each segment’s local voltage colours
              the membrane; its ionic currents drive the particle crossings.
            </p>
            <p className="equation">
              Cₘ dV/dt = Iᵢₙⱼ + Iₐₓᵢₐₗ − ḡNa m³h(V − ENa) − ḡK n⁴(V − EK) − gL(V
              − EL)
            </p>
            <p>
              Classic squid-axon kinetics at 6.3 °C: Cₘ = 1 μF/cm²; ENa = +50
              mV; EK = −77 mV; EL = −54.387 mV; gL = 0.3 mS/cm². Sealed cable
              ends; neighbour coupling 4 mS/cm²; time step 0.01 ms. Gates use an
              exponential update and voltage uses frozen conductances within
              each step.
            </p>
            <p>
              An educational approximation: a stylized multipolar morphology
              carries an unmyelinated, uniform cable. Dendrites and soma share
              the hillock colour; terminal branches share the distal voltage.
              Shapes, channel sizes and ion counts are illustrative. Pore width
              depicts an ensemble open fraction, not individual stochastic
              gates; particle flux is scaled for visibility. Distances and
              conduction speed are not calibrated to a specific neuron. Reset
              restores all electrical settings and clears the recording.
            </p>
            <a
              href="https://neuronaldynamics.epfl.ch/online/Ch2.S2.html"
              target="_blank"
              rel="noreferrer"
            >
              Hodgkin–Huxley model · Neuronal Dynamics{" "}
              <ArrowUpRight size={13} />
            </a>
            <a
              href="https://doi.org/10.1113/jphysiol.1952.sp004764"
              target="_blank"
              rel="noreferrer"
            >
              Hodgkin & Huxley, 1952 · original model <ArrowUpRight size={13} />
            </a>
          </div>
        </details>
      </footer>
    </main>
  );
}
