# Membrane: an interactive action potential

A complete client-side React / Three.js / React Three Fiber / Drei app. A 64-compartment Hodgkin–Huxley cable drives the voltage colour, gates, ions and live graph. No prerecorded spike timeline or hosted API is used.

## Run

Node.js 22.13 or newer is required.

```sh
npm ci
npm run dev
```

Open the printed local address. `npm run build` creates portable static files in `dist/`; `npm start` previews the production build. Relative asset URLs support both Sites and a GitHub Pages subdirectory.

## Verify

```sh
npm test
npm run typecheck
npm run build
```

Numerical tests cover rest, spiking, forward propagation, sodium blockade, firing-rate response to current, halved-step convergence, parameter extremes, pause/reset and a stimulus pulse. UI validation includes desktop and mobile layouts, WebMCP settings and invalid-input rejection, channel inspection, pause/resume, camera controls, sliders and visibility toggles.

## Components

- `lib/neuron/model.mjs`: fixed-step membrane solver, gates, ionic currents, integrated flux and bounded trace buffers. Its `.d.mts` declaration exposes the typed interface.
- `lib/neuron/geometry.ts`: soma surface, tapered dendrites, continuous axon and branching terminals.
- `components/neuron/NeuronScene.tsx`: instanced channels and ions, orbit camera, lighting and bloom.
- `components/neuron/VoltageMaterial.tsx`: GLSL membrane shader sampling a live 64-pixel voltage texture.
- `components/neuron/VoltageGraph.tsx`: canvas oscilloscope, with the hillock and selected compartment on the same time axis.
- `components/neuron/MembraneInset.tsx`: annotated cross-section of the same recording site.
- `components/neuron/SimulationControls.tsx`: accessible current, conductance, time and display controls.
- `lib/neuron/webmcp.ts`: optional, feature-detected tools backed by the same state as the UI.
- `app/page.tsx`: experiment composition; `client-entry.tsx` is the static application entry.

## Interpretation

Classic squid-axon kinetics at 6.3 °C are placed in an illustrative multipolar morphology. This is not a calibrated model of a specific human neuron. Current is applied continuously to the first four compartments; a pulse adds 35 μA/cm² for 1 ms. The 0.01 ms integration step is independent of display refresh and speed. At 1×, eight simulated milliseconds pass per wall-clock second. Long background-tab delays are capped rather than replayed.

Capacitance is 1 μF/cm². Sodium, potassium and leak reversal potentials are +50, −77 and −54.387 mV. Leak conductance is 0.3 mS/cm² and nearest-neighbour coupling is 4 mS/cm², with sealed ends. Default maximal sodium/potassium conductances are 120/36 mS/cm². Channel gates use exact frozen-voltage exponential updates; voltage uses an exponential frozen-conductance update with explicit axial current.

Each segment has its own V, m, h and n. Pore width shows a scaled ensemble open fraction (m³h or n⁴). Sodium influx and potassium efflux can overlap, as they do in the underlying model. Visible ion transport integrates the signed ionic current, scaled and capped for readability; particle counts do not represent concentrations. Dendrites and soma use the first compartment's voltage, and terminal branches use the last. Geometry, channel size, propagation distance and particle speed are not to scale. Rest and the travelling spikes emerge from the model.

References: [Hodgkin & Huxley (1952)](https://doi.org/10.1113/jphysiol.1952.sp004764) and [Neuronal Dynamics, chapter 2.2](https://neuronaldynamics.epfl.ch/online/Ch2.S2.html). The latter explains the formulation; its cortical parameter table is not used as the classic squid-axon parameter set.
