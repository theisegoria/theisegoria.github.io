"use client";
import { lazy, Suspense, useState, useEffect, useRef, memo } from "react";
import {
  Activity,
  Move,
  Focus,
  Maximize2,
  ArrowUpRight,
  ChevronDown,
} from "lucide-react";
import { CableModel, DEFAULTS, BRANCHES } from "@/lib/neuron/model.mjs";
import { registerSimulationTools } from "@/lib/neuron/webmcp";
import SimulationControls, {
  type Parameters,
} from "@/components/neuron/SimulationControls";
import VoltageGraph from "@/components/neuron/VoltageGraph";
import ChannelPopulation from "@/components/neuron/ChannelPopulation";
import BranchSignals from "@/components/neuron/BranchSignals";
import { probeLabel } from "@/lib/neuron/topology.mjs";
import CircuitControls from "@/components/neuron/CircuitControls";
import CircuitPlots from "@/components/neuron/CircuitPlots";
import {CIRCUIT_DEFAULTS,CONTACTS} from "@/lib/neuron/circuit.mjs";
import MyelinLab from "@/components/neuron/MyelinLab";
import MembraneInset from "@/components/neuron/MembraneInset";
const NeuronScene = memo(lazy(() => import("@/components/neuron/NeuronScene")));
export default function Home() {
  const [sceneMode,setSceneMode]=useState<"axon"|"synapse"|"circuit">("axon");
  const [selectedContact,setSelectedContact]=useState(0);
  const [model] = useState(() => new CableModel());
  const [mounted, setMounted] = useState(false);
  const [params, setParams] = useState<Parameters>({ ...DEFAULTS });
  const [paused, setPaused] = useState(false);
  const [labels, setLabels] = useState(true),
    [ions, setIons] = useState(true),
    [focus, setFocus] = useState(false),
    [branchView, setBranchView] = useState(false),
    [viewRevision, setViewRevision] = useState(0);
  const [live, setLive] = useState(() => model.snapshot());
  const [cutaway, setCutaway] = useState(false);
  const [myelinRevision, setMyelinRevision] = useState(0);
  const changeMyelin = (config: Partial<CableModel["myelin"]>) => {
    model.configureMyelin(config);
    setMyelinRevision(n=>n+1);
    setLive(model.snapshot());
  };
  const onCell = (id:number) => changeMyelin({removed: model.myelin.removed.includes(id) ? model.myelin.removed.filter(x=>x!==id) : [...model.myelin.removed,id]});
  const editCircuit=()=>{model.reset();setLive(model.snapshot());setViewRevision(n=>n+1);};
  const protocol=(mode:"message"|"burst"|"inhibit"|"learning")=>{
    if(mode==='inhibit')model.circuit.params.mode='feedforward';
    if(mode==='learning')model.circuit.params.plasticity=true;
    model.params.current=0;model.reset();model.paused=false;
    model.scheduledPulses=mode==='burst'?[0,12,24,36,48]:mode==='learning'?[0,30,60,90,120,150]:[0];
    model.circuit.inhibitoryPulse=mode==='inhibit';model.stopAt=mode==='learning'?220:mode==='burst'?130:90;
    setParams({...model.params});setPaused(false);setLive(model.snapshot());setViewRevision(n=>n+1);
  };
  const selectContact=(i:number)=>{setSelectedContact(i);};
  const [pulseNote, setPulseNote] = useState("");
  const pulseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onProbe = useRef((i: number) => {
    model.setProbe(i);
    setViewRevision((n) => n + 1);
    setLive(model.snapshot());
  }).current;
  useEffect(() => {
    setMounted(true);
    let raf = 0,
      previous = performance.now(),
      lastUI = 0;
    const tick = (now: number) => {
      model.advance((now - previous) / 1000);
      previous = now;
      if (now - lastUI > 66) {
        setLive(model.snapshot());
        setPaused(model.paused);
        lastUI = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const unregister = registerSimulationTools(model, () => {
      setParams({ ...model.params });
      setPaused(model.paused);
      setLive(model.snapshot());
    });
    return () => {
      cancelAnimationFrame(raf);
      unregister();
      if (pulseTimer.current) clearTimeout(pulseTimer.current);
    };
  }, [model]);
  const setParam = (k: keyof Parameters, v: number) => {
    model.params[k] = v;
    setParams({ ...model.params });
  };
  const togglePause = () => {
    model.paused = !model.paused;
    setPaused(model.paused);
  };
  const reset = () => {
    model.params = { ...DEFAULTS };
    model.circuit.params={...CIRCUIT_DEFAULTS};
    model.circuit.synapses.forEach((s,i)=>Object.assign(s.config,CONTACTS[i],{enabled:true,density:1,delay:.3}));
    setSelectedContact(0);
    model.paused = false;
    model.probe = 18;
    model.configureMyelin({enabled:false,length:5,gap:1,removed:[]});
    setMyelinRevision(n=>n+1);
    setParams({ ...DEFAULTS });
    setPaused(false);
    setFocus(false);
    setCutaway(false);
    setBranchView(false);
    setViewRevision((n) => n + 1);
    setLive(model.snapshot());
    setPulseNote("");
  };
  const pulse = () => {
    model.pulse();
    setPulseNote("+35 μA/cm² · 1 ms");
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    pulseTimer.current = setTimeout(() => setPulseNote(""), 1800);
  };
  const scenario = (mode: "rest" | "single" | "train") => {
    model.params = {
      ...DEFAULTS,
      current: mode === "train" ? 18 : 0,
      speed: params.speed,
    };
    model.paused = false;
    model.reset();
    if (mode === "single") {
      model.pulse();
      model.stopAt = 40;
    }
    setParams({ ...model.params });
    setPaused(false);
    setLive(model.snapshot());
    setPulseNote(
      mode === "single"
        ? "Single spike · 35 μA/cm² for 1 ms"
        : mode === "rest"
          ? "No injected current"
          : "Continuous current · 18 μA/cm²",
    );
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    pulseTimer.current = setTimeout(() => setPulseNote(""), 2200);
  };
  const viewBranches = () => {
    setFocus(false);
    setBranchView(true);
    setViewRevision((n) => n + 1);
    document.querySelector(".visual")?.scrollIntoView({
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
      block: "start",
    });
  };
  return (
    <main className="lab">
      <header>
        <div className="brand">
          <Activity size={24} strokeWidth={1.4} />
          <span>MEMBRANE</span>
        </div>
        <span className="eyebrow">INTERACTIVE NEUROSCIENCE</span>
        <span className="edition">
          FIGURE <b>01</b>
          <span className="edition-line" />
          LIVE MODEL
        </span>
      </header>
      <div className={`workspace ${sceneMode!=="axon"?"circuit-workspace":""}`}>
        <div className="figure-column">
          <section className="visual" aria-label="Interactive 3D neuron">
            <div className="figure-title">
              <p className="eyebrow">CELLULAR ELECTROPHYSIOLOGY</p>
              <h1>{sceneMode==="synapse"?"Across the synapse":sceneMode==="circuit"?"A connected circuit":"Action potential"}</h1>
              <p>{sceneMode==="axon"?"One neuron. A travelling electrical signal.":sceneMode==="synapse"?"An electrical signal becomes a chemical message.":"Local dynamics. Shared consequences."}</p>
            </div>
            <div className="scene-mode-tabs" aria-label="3D inspection view">{(["axon","synapse","circuit"] as const).map(mode=><button key={mode} aria-pressed={sceneMode===mode} onClick={()=>{setSceneMode(mode);setFocus(false);setBranchView(false);setViewRevision(n=>n+1);}}>{mode==="axon"?"Axon & myelin":mode==="synapse"?"Synaptic cleft":"Neural circuit"}</button>)}</div>
            <div className="scene-badge">
              <span className="na-dot" />{" "}
              {sceneMode!=="axon" ? (sceneMode==="synapse" ? `CONTACT ${selectedContact+1} · CUTAWAY` : "LIVE CIRCUIT") : focus
                ? "MEMBRANE CLOSE-UP"
                : branchView
                  ? "BRANCHING AXON"
                  : "MULTIPOLAR NEURON"}
            </div>
            <div className="scene-canvas">
              {mounted && (
                <Suspense
                  fallback={
                    <div className="scene-loading">Preparing the neuron…</div>
                  }
                >
                  <NeuronScene
                    model={model}
                    mode={sceneMode}
                    selectedContact={selectedContact}
                    onContact={selectContact}
                    myelinRevision={myelinRevision}
                    cutaway={cutaway}
                    onCell={onCell}
                    probeIndex={model.probe}
                    labels={labels && (sceneMode!=="axon" || !focus)}
                    ions={ions}
                    focus={focus}
                    branchView={branchView}
                    viewRevision={viewRevision}
                    onProbe={onProbe}
                  />
                </Suspense>
              )}
            </div>
            {sceneMode==="axon" && <div className="scene-tools">
              {model.myelin.enabled && <button aria-pressed={cutaway} onClick={()=>setCutaway(v=>!v)}>{cutaway?"Close cutaway":"Myelin cutaway"}</button>}
              <button
                aria-pressed={focus}
                onClick={() => {
                  setFocus(!focus);
                  setBranchView(false);
                }}
                title="Inspect channels at the recording site"
              >
                <Focus size={16} />
                {focus ? "Whole neuron" : "Inspect membrane"}
              </button>
              <button
                aria-pressed={branchView}
                onClick={() => {
                  setFocus(false);
                  setBranchView(!branchView);
                }}
              >
                Branches
              </button>
              <button
                className="icon-button"
                aria-label="Reset camera"
                onClick={() => {
                  setFocus(false);
                  setBranchView(false);
                  setViewRevision((n) => n + 1);
                }}
              >
                <Maximize2 size={16} />
              </button>
            </div>
            }
            {sceneMode!=="axon" && <div className="scene-tools">{sceneMode==="synapse"&&<button aria-pressed={focus} onClick={()=>setFocus(!focus)}><Focus size={16}/>{focus?"Synapse overview":"Receptor close-up"}</button>}<button onClick={()=>{setFocus(false);setViewRevision(n=>n+1);}}>Reset view</button></div>}
            <div className="voltage-legend">
              <span>MEMBRANE POTENTIAL</span>
              <div className="voltage-ramp" />
              <div>
                <span>−80</span>
                <span>−65</span>
                <span>+40 mV</span>
              </div>
            </div>
            <div className="scene-foot">
              <span>
                <Move size={13} /> Drag to orbit · Scroll to zoom · Right-drag
                to pan
              </span>
              <span>{sceneMode==="synapse"?"Gold: transmitter · violet: calcium":sceneMode==="circuit"?"Select a numbered synaptic contact":cutaway ? "Cutaway · illustrative layers" : "Click axon to move probe"}</span>
            </div>
            <span role="status" className="pulse-note">
              {pulseNote}
            </span>
          </section>
          {sceneMode!=="axon" ? <CircuitPlots model={model} selected={selectedContact}/> : <section
            className="trace-panel"
            aria-label="Membrane potential recording"
          >
            <div className="trace-header">
              <div>
                <p className="eyebrow">
                  MEMBRANE POTENTIAL <span className="unit">mV</span>
                </p>
                <div className="trace-key">
                  <span>
                    <i />
                    {probeLabel(model.probe)}
                  </span>
                  <span>
                    <i />
                    Hillock
                  </span>
                </div>
              </div>
              <div className="live-voltage">
                <strong>{live.v.toFixed(1)}</strong>
                <span>mV</span>
                <small className={"phase " + live.phase.toLowerCase()}>
                  {live.phase}
                </small>
              </div>
            </div>
            <div className="probe-selector">
              <label htmlFor="probe-location">Recording site</label>
              <select
                id="probe-location"
                value={model.probe}
                onChange={(e) => {
                  onProbe(Number(e.target.value));
                  setViewRevision((n) => n + 1);
                }}
              >
                {[
                  0,
                  18,
                  40,
                  63,
                  ...BRANCHES.map((b) => b.end),
                  ...(![0, 18, 40, 63, ...BRANCHES.map((b) => b.end)].includes(
                    model.probe,
                  )
                    ? [model.probe]
                    : []),
                ].map((i) => (
                  <option key={i} value={i}>
                    {probeLabel(i)}
                  </option>
                ))}
              </select>
            </div>
            <VoltageGraph model={model} />
            <div className="trace-foot">
              <span>40 ms window · Resting reference −65 mV</span>
              <span>
                t = <b>{live.time.toFixed(1)}</b> ms
              </span>
            </div>
          </section>}
        </div>
        <aside className="controls">
          <SimulationControls
            params={params}
            paused={paused}
            labels={labels}
            ions={ions}
            setParam={setParam}
            togglePause={togglePause}
            reset={reset}
            pulse={pulse}
            setLabels={setLabels}
            setIons={setIons}
          />
          {sceneMode!=="axon"?<CircuitControls model={model} selected={selectedContact} onSelect={selectContact} onEdit={editCircuit} onProtocol={protocol}/>:<MyelinLab model={model} onChange={changeMyelin} onInspect={()=>{ onProbe(32); setFocus(true); setBranchView(false); setViewRevision(n=>n+1); document.querySelector(".visual")?.scrollIntoView({block:"start"}); }} />}
          {sceneMode==="axon" && <MembraneInset model={model} />}
        </aside>
      </div>
      {sceneMode==="axon" && <div className="mechanism-grid">
        <ChannelPopulation model={model} />
        <BranchSignals
          model={model}
          onProbe={onProbe}
          onView={viewBranches}
          onScenario={scenario}
          onPause={togglePause}
        />
      </div>}
      <footer>
        <div className="figure-caption">
          <span className="caption-number">01</span>
          <p>
            Depolarization admits <span className="sodium-text">Na⁺</span>.
            Delayed <span className="potassium-text">K⁺</span> efflux restores
            the membrane potential.
            <br />
            <span>
              Follow the green wave along the axon; inspect a membrane patch to
              see the gates respond.
            </span>
          </p>
        </div>
        <details className="model-details">
          <summary>
            About the model <ChevronDown size={14} />
          </summary>
          <div>
            <p>The synapse and circuit views add four receiving cells with five HH compartments each. Terminal voltage drives calcium entry, finite vesicle pools, transmitter binding, receptor opening and desensitization. Transport, optional enzyme degradation and diffusion conserve transmitter mass. Excitatory and inhibitory currents drive the receiving cells; seeded release and bounded spike-timing plasticity are optional. All parameters are illustrative, not a fitted biological preparation. Particles represent population flux, not individually tracked molecules.</p>
            <p>
              144 electrically coupled compartments solve a Hodgkin–Huxley cable
              with voltage-dependent m, h and n gates: 64 in the parent axon and
              80 across five daughter branches. Injected current enters the
              first four compartments. Each segment’s local voltage colours the
              membrane; its ionic currents drive the particle crossings.
            </p>
            <p className="equation">
              Cₘ dV/dt = Iᵢₙⱼ + Iₐₓᵢₐₗ − ḡNa m³h(V − ENa) − ḡK n⁴(V − EK) − gL(V
              − EL)
            </p>
            <p>
              Classic squid-axon kinetics at 6.3 °C: Cₘ = 1 μF/cm²; ENa = +50
              mV; EK = −77 mV; EL = −54.387 mV; gL = 0.3 mS/cm². Sealed cable
              ends; parent neighbour coupling 4 mS/cm²; time step 0.01 ms.
              Daughter membrane areas scale with relative diameter, axial
              conductances with diameter squared; each junction conserves axial
              current. Gates use an exponential update and voltage uses frozen
              conductances within each step.
            </p>
            <p>
              An educational approximation: a stylized multipolar morphology
              carries an unmyelinated branched cable. Dendrites and soma share
              the hillock colour; each daughter segment and terminal uses its
              own solved voltage. Relative daughter diameters are 0.32–0.36 of
              the parent; equal segment lengths are assumed. Shapes, channel
              sizes and ion counts are illustrative. In 3D and the
              cross-section, pore width depicts an ensemble open fraction; the
              64-channel patch separately samples individual HH gates. Particle
              flux is scaled for visibility. Fixed reversal potentials assume
              maintained concentration gradients. Slow ion-gradient regulation and metabolism are outside this model. Distances
              and conduction speed are not calibrated to a specific neuron.
              Reset restores all electrical settings and clears the recording.
            </p>
            <a
              href="https://neuronaldynamics.epfl.ch/online/Ch2.S2.html"
              target="_blank"
              rel="noreferrer"
            >
              Hodgkin–Huxley model · Neuronal Dynamics{" "}
              <ArrowUpRight size={13} />
            </a>
            <a
              href="https://doi.org/10.1113/jphysiol.1952.sp004764"
              target="_blank"
              rel="noreferrer"
            >
              Hodgkin & Huxley, 1952 · original model <ArrowUpRight size={13} />
            </a>
          </div>
        </details>
      </footer>
    </main>
  );
}
