#!/usr/bin/env python3
"""Build the English and Japanese bundles and publish them into ../site/neuron-action-potential/.
The site's own index.html files (with the ISEGORIA shell blocks) are kept; only their bundle
references are rewritten. Run: python3 scripts/publish-site.py"""
import pathlib, re, shutil, subprocess
root = pathlib.Path(__file__).resolve().parent.parent
site = root.parent / 'site'
subprocess.run(['npx', 'vite', 'build', '--config', 'vite.static.config.ts'], cwd=root, check=True)
subprocess.run(['npx', 'vite', 'build', '--config', 'vite.ja.config.ts'], cwd=root, check=True)
assets = site / 'neuron-action-potential' / 'assets'
shutil.rmtree(assets, ignore_errors=True)
assets.mkdir(parents=True)
for d in ('dist', 'dist-ja'):
    for f in (root / d / 'assets').iterdir():
        shutil.copy2(f, assets / f.name)
def entry(d):
    html = (root / d / 'index.html').read_text()
    return (re.search(r'assets/(index-[\w-]+\.js)', html).group(1), re.search(r'assets/(index-[\w-]+\.css)', html).group(1))
for d, page in (('dist', site / 'neuron-action-potential' / 'index.html'), ('dist-ja', site / 'ja' / 'neuron-action-potential' / 'index.html')):
    js, css = entry(d)
    html = page.read_text()
    html = re.sub(r'(assets/)index-[\w-]+\.js', r'\g<1>' + js, html)
    html = re.sub(r'(assets/)index-[\w-]+\.css', r'\g<1>' + css, html)
    page.write_text(html)
    print(page, js, css)
