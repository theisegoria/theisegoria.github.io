"use client";
import { useMemo, useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { Line } from "@react-three/drei";
import * as THREE from "three";
import { CableModel } from "@/lib/neuron/model.mjs";
import Callouts, { isJa, type Callout } from "./Callouts";
// A magnified patch of membrane at the recording site: a phospholipid bilayer with one voltage-gated
// Na+ channel and one K+ channel. Pore dilation follows the local ensemble open fraction (m^3 h, n^4),
// the S4 voltage-sensor helices rise with activation (m, n), and the Na+ inactivation gate swings
// under the pore as h falls. Ions cross at the local integrated flux. Not to scale.
const NA = "#8fe3c0",
  K = "#efb86f";
const T = (en: string, ja: string) => (isJa() ? ja : en);
type Domain = { group: THREE.Group; angle: number };
function buildChannel(color: string, sensor: string) {
  const g = new THREE.Group();
  const body = new THREE.MeshPhysicalMaterial({ color, roughness: 0.55, sheen: 0.6, sheenColor: new THREE.Color("#ffffff"), clearcoat: 0.2 });
  const s4 = new THREE.MeshPhysicalMaterial({ color: sensor, roughness: 0.4, emissive: sensor, emissiveIntensity: 0.25 });
  const helix = new THREE.CapsuleGeometry(0.032, 0.46, 6, 12);
  const domains: Domain[] = [];
  const sensors: THREE.Mesh[] = [];
  for (let d = 0; d < 4; d++) {
    const angle = (d * Math.PI) / 2 + Math.PI / 4;
    const dg = new THREE.Group();
    // Six transmembrane helices per domain: S1-S4 sensor bundle outside, S5-S6 lining the pore.
    const layout = [
      [0.0, 0.0], [0.07, 0.035], [0.07, -0.04], [0.14, 0.0], [0.13, 0.07], [0.13, -0.07],
    ];
    layout.forEach(([r, t], i) => {
      const m = new THREE.Mesh(helix, i === 3 ? s4 : body);
      m.position.set(r, 0, t);
      m.rotation.z = (i % 2 ? 1 : -1) * 0.18;
      m.rotation.x = t * 1.5;
      m.castShadow = true;
      dg.add(m);
      if (i === 3) sensors.push(m);
    });
    // Extracellular turret loop and a cytoplasmic linker stub.
    const loop = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.016, 8, 18, Math.PI), body);
    loop.position.set(0.04, 0.29, 0);loop.scale.setScalar(1.4);
    dg.add(loop);
    const stub = new THREE.Mesh(new THREE.SphereGeometry(0.065, 16, 12), body);
    stub.position.set(0.08, -0.31, 0);
    stub.scale.set(1, 0.7, 1);
    dg.add(stub);
    dg.rotation.y = -angle;
    g.add(dg);
    domains.push({ group: dg, angle });
  }
  return { g, domains, sensors, body };
}
function Lipids() {
  const heads = useRef<THREE.InstancedMesh>(null),
    tails = useRef<THREE.InstancedMesh>(null);
  const grid = useMemo(() => {
    const pts: [number, number, number][] = [];
    for (const y of [0.15, -0.15])
      for (let i = 0; i < 30; i++)
        for (let j = 0; j < 14; j++) {
          const x = -1.1 + i * 0.076 + (j % 2) * 0.038,
            z = -0.5 + j * 0.076;
          if (Math.hypot(x + 0.5, z) < 0.27 || Math.hypot(x - 0.5, z) < 0.27) continue;
          pts.push([x, y, z]);
        }
    return pts;
  }, []);
  useEffect(() => {
    const m = new THREE.Matrix4(),
      q = new THREE.Quaternion();
    grid.forEach(([x, y, z], i) => {
      const wob = Math.sin(i * 12.9) * 0.012;
      m.compose(new THREE.Vector3(x, y + wob, z), q, new THREE.Vector3(1, 1, 1));
      heads.current?.setMatrixAt(i, m);
      for (let k = 0; k < 2; k++) {
        const tilt = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.sin(i + k) * 0.18, 0, Math.cos(i * 3 + k) * 0.18));
        m.compose(new THREE.Vector3(x + (k ? 0.012 : -0.012), y - Math.sign(y) * 0.075, z), tilt, new THREE.Vector3(1, 1, 1));
        tails.current?.setMatrixAt(i * 2 + k, m);
      }
    });
    if (heads.current) heads.current.instanceMatrix.needsUpdate = true;
    if (tails.current) tails.current.instanceMatrix.needsUpdate = true;
  }, [grid]);
  return (
    <>
      <instancedMesh ref={heads} args={[undefined, undefined, grid.length]} castShadow receiveShadow>
        <sphereGeometry args={[0.036, 14, 10]} />
        <meshPhysicalMaterial color="#e9b9a3" roughness={0.42} sheen={0.7} sheenColor="#fff2e6" clearcoat={0.3} />
      </instancedMesh>
      <instancedMesh ref={tails} args={[undefined, undefined, grid.length * 2]}>
        <capsuleGeometry args={[0.009, 0.1, 4, 6]} />
        <meshStandardMaterial color="#f2dc9a" roughness={0.6} />
      </instancedMesh>
    </>
  );
}
export default function MembranePatch({ model, origin }: { model: CableModel; origin: THREE.Vector3 }) {
  const group = useRef<THREE.Group>(null);
  const na = useMemo(() => buildChannel("#3fb68a", "#c9ffe9"), []);
  const k = useMemo(() => buildChannel("#d8903c", "#ffe9c4"), []);
  const gate = useMemo(() => {
    const g = new THREE.Group();
    const mat = new THREE.MeshPhysicalMaterial({ color: "#5aa58a", roughness: 0.5, sheen: 0.5 });
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.055, 18, 14), mat);
    g.add(ball);
    return { g, ball, mat };
  }, []);
  const ionRefs = [useRef<THREE.InstancedMesh>(null), useRef<THREE.InstancedMesh>(null)];
  const bath = useMemo(() => {
    const r = (s: number) => {
      const x = Math.sin(s * 91.7) * 43758.5;
      return x - Math.floor(x);
    };
    return Array.from({ length: 36 }, (_, i) => [-1.05 + 2.1 * r(i + 1), 0.36 + 0.3 * r(i + 7), -0.45 + 0.9 * r(i + 13)]);
  }, []);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(({ clock }) => {
    const i = model.probe;
    const m = model.m[i],
      h = model.h[i],
      n = model.n[i];
    const openNa = m ** 3 * h,
      openK = n ** 4;
    // Pore dilation from the ensemble open fraction; S4 rises with the activation variable.
    na.domains.forEach((d) => {
      const r = 0.1 + 0.07 * Math.sqrt(openNa);
      d.group.position.set(Math.cos(d.angle) * r, 0, Math.sin(d.angle) * r);
    });
    k.domains.forEach((d) => {
      const r = 0.1 + 0.07 * Math.sqrt(openK);
      d.group.position.set(Math.cos(d.angle) * r, 0, Math.sin(d.angle) * r);
    });
    na.sensors.forEach((s) => (s.position.y = (m - 0.3) * 0.12));
    k.sensors.forEach((s) => (s.position.y = (n - 0.3) * 0.12));
    // Inactivation gate: tethered beside the pore when h is high, under the pore when h falls.
    const plug = new THREE.Vector3(-0.5, -0.36, 0),
      away = new THREE.Vector3(-0.2, -0.5, 0.14);
    gate.g.position.copy(away.lerp(plug, 1 - h));
    gate.mat.emissive.set("#2a8a6a");
    gate.mat.emissiveIntensity = (1 - h) * 0.6;
    // Ions through the pores, at the local integrated flux; a bath of Na+ outside and K+ inside.
    const clocks = [model.fluxNa[i], model.fluxK[i]];
    ionRefs.forEach((ref, sp) => {
      if (!ref.current) return;
      let idx = 0;
      for (let j = 0; j < 6; j++) {
        const p = (clocks[sp] + j / 6) % 1;
        const y = sp === 0 ? 0.55 - p * 1.1 : -0.55 + p * 1.1;
        const s = 0.032 * Math.min(1, p * 8, (1 - p) * 8) * ((sp === 0 ? openNa : openK) > 0.002 ? 1 : 0);
        dummy.position.set(sp === 0 ? -0.5 : 0.5, y, Math.sin(j * 2.1) * 0.02);
        dummy.scale.setScalar(s);
        dummy.updateMatrix();
        ref.current.setMatrixAt(idx++, dummy.matrix);
      }
      bath.forEach(([x, y, z], b) => {
        const t = clock.elapsedTime * 0.25 + b;
        dummy.position.set(x + Math.sin(t) * 0.03, sp === 0 ? y : -y, z + Math.cos(t * 1.3) * 0.03);
        dummy.scale.setScalar(b % 2 === sp ? 0.022 : 0);
        dummy.updateMatrix();
        ref.current!.setMatrixAt(idx++, dummy.matrix);
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
    if (group.current) group.current.position.copy(origin).add(new THREE.Vector3(0, 1.05, 0));
  });
  const items = useMemo<Callout[]>(() => {
    const at = (x: number, y: number, z: number) => () => (group.current ? group.current.localToWorld(new THREE.Vector3(x, y, z)) : new THREE.Vector3());
    return [
      { id: "out", text: T("EXTRACELLULAR|Na⁺ high, K⁺ low", "細胞外|Na⁺ が多く K⁺ が少ない"), anchor: at(-1.0, 0.48, 0), label: at(-1.75, 0.55, 0), side: -1 },
      { id: "lipid", text: T("LIPID BILAYER|about 5 nm thick", "脂質二重層|厚さ約 5 nm"), anchor: at(-1.0, 0.15, 0.45), label: at(-1.75, 0.05, 0), side: -1 },
      { id: "in", text: T("CYTOPLASM|K⁺ high, Na⁺ low", "細胞質|K⁺ が多く Na⁺ が少ない"), anchor: at(-1.0, -0.5, 0), label: at(-1.75, -0.5, 0), side: -1 },
      { id: "na", text: T("Na⁺ CHANNEL|opens fast, then inactivates", "Na⁺ チャネル|すばやく開き、その後不活性化"), anchor: at(-0.5, 0.36, 0.12), label: at(-0.25, 0.9, 0), side: 1 },
      { id: "k", text: T("K⁺ CHANNEL|opens slowly, restores rest", "K⁺ チャネル|ゆっくり開き、静止電位に戻す"), anchor: at(0.55, 0.36, 0.12), label: at(1.5, 0.7, 0), side: 1 },
      { id: "s4", text: T("VOLTAGE SENSOR (S4)|rises with depolarization", "電位センサー（S4）|脱分極で持ち上がる"), anchor: at(0.72, 0.05, 0.12), label: at(1.5, 0.1, 0), side: 1 },
      { id: "gate", text: T("INACTIVATION GATE|plugs the pore as h falls", "不活性化ゲート|h が下がると孔をふさぐ"), anchor: () => (group.current ? group.current.localToWorld(gate.g.position.clone()) : new THREE.Vector3()), label: at(0.3, -0.85, 0), side: 1 },
    ];
  }, [gate]);
  return (
    <group>
      <group ref={group}>
        <Lipids />
        <primitive object={na.g} position={[-0.5, 0, 0]} />
        <primitive object={k.g} position={[0.5, 0, 0]} />
        <primitive object={gate.g} />
        {ionRefs.map((ref, i) => (
          <instancedMesh key={i} ref={ref} args={[undefined, undefined, 6 + bath.length]} frustumCulled={false}>
            <sphereGeometry args={[1, 12, 8]} />
            <meshBasicMaterial color={i ? K : NA} toneMapped={false} />
          </instancedMesh>
        ))}
      </group>
      {/* Magnifier: where this patch sits on the axon */}
      {[[-1.1, -0.55], [1.1, -0.55], [-1.1, 0.5], [1.1, 0.5]].map(([x, z], i) => (
        <Line key={i} points={[origin.toArray(), [origin.x + x, origin.y + 1.05 - 0.2, origin.z + z]]} color="#9fc2c8" lineWidth={0.8} transparent opacity={0.28} />
      ))}
      <Callouts items={items} safe={{ leftTop: 0.42, top: 0.06, bottom: 96 }} />
    </group>
  );
}
