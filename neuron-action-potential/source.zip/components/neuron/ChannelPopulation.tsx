import { CableModel } from "@/lib/neuron/model.mjs";
import { probeLabel } from "@/lib/neuron/topology.mjs";
// The parent page refreshes readouts at 15 Hz; gate transitions use solver time.
export default function ChannelPopulation({ model }: { model: CableModel }) {
  const states = [model.population.naState, model.population.kState];
  const s = model.snapshot();
  return (
    <section className="population-panel" aria-labelledby="population-title">
      <p className="eyebrow">02 / LOCAL MEMBRANE PATCH</p>
      <div className="section-heading">
        <h2 id="population-title">One voltage. Many gates.</h2>
        <span className="patch-voltage">
          {s.v.toFixed(1)} <small>mV</small>
        </span>
      </div>
      <p>
        All channels in this patch experience the same local voltage. Individual
        gates fluctuate; they do not open in lockstep.
      </p>
      <div className="patch-location">
        Recording: <strong>{probeLabel(model.probe)}</strong>
      </div>
      <div className="channel-populations">
        {states.map((array, species) => {
          const open = Array.from(array).filter((v) => v === 1).length;
          const blocked =
            species === 0 ? model.params.gNa === 0 : model.params.gK === 0;
          return (
            <div
              className={species ? "population potassium" : "population sodium"}
              key={species}
            >
              <div className="population-heading">
                <h3>{species ? "K⁺" : "Na⁺"} channels</h3>
                <span>{open} / 32 open</span>
              </div>
              <div
                className="pore-grid"
                role="img"
                aria-label={`${open} of 32 ${species ? "potassium" : "sodium"} gates open. ${blocked ? "Conductance is zero; no transport." : ""}`}
              >
                {Array.from(array).map((state, i) => (
                  <span
                    key={i}
                    className={"pore state-" + state}
                    aria-hidden="true"
                  >
                    <i />
                    {state === 1 && !blocked && <b>{species ? "↑" : "↓"}</b>}
                  </span>
                ))}
              </div>
              <div className="population-bottom">
                <span>
                  {species ? "↑ K⁺ efflux" : "↓ Na⁺ influx"}
                  {blocked ? " · blocked" : ""}
                </span>
                <span>
                  HH fraction{" "}
                  {((species ? s.openK : s.openNa) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="pore-legend">
        <span>
          <i className="open-symbol" /> Open
        </span>
        <span>
          <i /> Closed
        </span>
        <span>
          <i className="unavailable-symbol" /> Na⁺ unavailable
        </span>
      </div>
      <p className="science-note">
        Top view, schematic. Arrows indicate the dominant transport direction. A
        seeded sample of 32 Na⁺ and 32 K⁺ channels follows voltage-dependent HH
        gate rates. The cable uses the ensemble conductance; this finite sample
        does not feed noise back into the voltage. Zero conductance blocks
        transport while voltage sensing continues.
      </p>
    </section>
  );
}
