import {useMemo,useRef,useEffect} from 'react';
import {useFrame,useThree} from '@react-three/fiber';
import {Html,Line} from '@react-three/drei';
import * as THREE from 'three';
import {CableModel} from '@/lib/neuron/model.mjs';
import {somaGeometry,morphology} from '@/lib/neuron/geometry';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {CELL_NAMES} from '@/lib/neuron/circuit.mjs';

function Shell({lower=false,voltage}:{lower?:boolean;voltage:()=>number}) {
 const material=useRef<THREE.MeshPhysicalMaterial>(null);
 useFrame(()=>{if(material.current)material.current.emissiveIntensity=Math.max(0,(voltage()+50)/100)*.5;});
 const geometry=useMemo(()=>{const points=[
  new THREE.Vector2(1.45,.48),new THREE.Vector2(1.6,.65),new THREE.Vector2(1.58,1),new THREE.Vector2(1.3,1.5),new THREE.Vector2(.65,1.9),new THREE.Vector2(.3,2.3),new THREE.Vector2(.29,3.1),
 ];const profile=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(p.x,p.y,0)));return new THREE.LatheGeometry(profile.getPoints(64).map(p=>new THREE.Vector2(p.x,p.y)),96,Math.PI/2,Math.PI);},[]);
 const rims=useMemo(()=>{const p=geometry.getAttribute("position");return [0,96].map(edge=>Array.from({length:65},(_,i)=>new THREE.Vector3().fromBufferAttribute(p,edge*65+i)));},[geometry]);
 useEffect(()=>()=>geometry.dispose(),[geometry]);
 return <group rotation={lower?[0,0,Math.PI]:[0,0,0]}>{rims.map((points,i)=><Line key={i} points={points} color="#c0b69c" lineWidth={2}/>)}<mesh geometry={geometry}><meshPhysicalMaterial ref={material} emissive="#72c9ad" color={lower?'#ad7f8d':'#6aafb0'} side={THREE.DoubleSide} roughness={.38} clearcoat={.35}/></mesh><mesh position={[0,.48,-.5]} scale={[1.43,.045,.53]}><sphereGeometry args={[1,48,24]}/><meshPhysicalMaterial color={lower?'#bd96a0':'#91c4bd'} roughness={.48}/></mesh></group>;
}
function Receptor({model,index,x,onSelect}:{model:CableModel;index:number;x:number;onSelect:()=>void}) {
 const body=useRef<THREE.Group>(null),bound=useRef<THREE.Mesh>(null),material=useRef<THREE.MeshPhysicalMaterial>(null);
 useFrame(()=>{const s=model.circuit.synapses[index];if(body.current){const scale=.9+s.states[2]*1.2;body.current.scale.set(scale,1,scale);}if(bound.current)bound.current.scale.setScalar(Math.sqrt(Math.max(0,1-s.states[0])));if(material.current)material.current.color.setRGB(.2+s.states[3]*.35,.48+s.states[2]*.35,.42);});
 return <group position={[x,-.48,.12]} onClick={e=>{e.stopPropagation();onSelect();}}>
  <group ref={body}>{[0,1,2,3].map(j=><mesh key={j} position={[Math.cos(j*Math.PI/2)*.10,0,Math.sin(j*Math.PI/2)*.10]} scale={[.065,.2,.065]}><sphereGeometry args={[1,16,16]}/><meshPhysicalMaterial ref={j===0?material:undefined} color="#58aa8a" roughness={.35} clearcoat={.35}/></mesh>)}</group>
  <mesh ref={bound} position={[0,.24,0]}><sphereGeometry args={[.07,16,12]}/><meshStandardMaterial color="#efc071" emissive="#a8772e" emissiveIntensity={.3}/></mesh>
 </group>;
}
export function SynapticWorld({model,selected,onSelect,labels,ions,closeup}:{model:CableModel;selected:number;onSelect:(i:number)=>void;labels:boolean;ions:boolean;closeup:boolean}) {
 const vesicles=useRef<THREE.InstancedMesh>(null),particles=useRef<THREE.InstancedMesh>(null),calcium=useRef<THREE.InstancedMesh>(null),clearance=useRef<THREE.InstancedMesh>(null),products=useRef<THREE.InstancedMesh>(null),unbound=useRef<THREE.InstancedMesh>(null);
 const dummy=useMemo(()=>new THREE.Object3D(),[]);
 const label=useRef<HTMLSpanElement>(null);
 const syn=model.circuit.synapses[selected];const compact=useThree(s=>s.size.width<600);
 useFrame(()=>{
  const s=model.circuit.synapses[selected];
  if(label.current)label.current.textContent=`${s.C.toFixed(1)} µM · ${(s.states[2]*100).toFixed(0)}% open`;
  for(let i=0;i<8;i++) {const row=Math.floor(i/3);dummy.position.set((i%3-1)*.65*(1-.2*row),1+row*.47,-.15);if(i===0)dummy.position.y-=.45*s.releaseActivity;dummy.scale.setScalar(.22*Math.sqrt(Math.max(0,Math.min(1,s.ready-i))));if(i===0){dummy.scale.y*=1-.7*s.releaseActivity;dummy.scale.x*=1+.3*s.releaseActivity;}dummy.updateMatrix();vesicles.current?.setMatrixAt(i,dummy.matrix);}
  if(vesicles.current)vesicles.current.instanceMatrix.needsUpdate=true;
  for(let i=0;i<96;i++){
   const phase=s.released/80+i*.618;
   // Representative dispersion in a well-mixed compartment, not tracked molecules.
   dummy.position.set(Math.sin(i*2.4+phase*.16)*1.3,.32-((i*.414+s.motion*.11)%1)*.68,Math.sin(i*4.7+phase*.13)*.6+.1);
   dummy.scale.setScalar(.045*Math.sqrt(s.C/(s.C+15+i*.8)));dummy.updateMatrix();particles.current?.setMatrixAt(i,dummy.matrix);
  }if(particles.current)particles.current.instanceMatrix.needsUpdate=true;
  for(let i=0;i<24;i++){const p=(s.caFlux/.2+i/24)%1;dummy.position.set((i%3-1)*.65,.5+Math.abs(p)*.7,.22);dummy.scale.setScalar(.036*Math.sqrt(s.q));dummy.updateMatrix();calcium.current?.setMatrixAt(i,dummy.matrix);}if(calcium.current)calcium.current.instanceMatrix.needsUpdate=true;
  for(let i=0;i<18;i++){const p=(s.uptaken/25+i/18)%1;dummy.position.set(1.3+p*.9,.1+Math.sin(i*3)*.23,.1);dummy.scale.setScalar(.035*Math.sqrt(s.S/(s.S+3)));dummy.updateMatrix();clearance.current?.setMatrixAt(i,dummy.matrix);}if(clearance.current)clearance.current.instanceMatrix.needsUpdate=true;
  for(let i=0;i<12;i++){const p=(s.degraded/15+i/12)%1;dummy.position.set(-1.7-p*.65,-.1+Math.sin(i*3)*.23,.1);dummy.scale.setScalar(.035*Math.sqrt(model.circuit.params.enzyme*s.C/(s.C+15)));dummy.updateMatrix();products.current?.setMatrixAt(i,dummy.matrix);
   const u=(s.dissociated*15+i/12)%1;dummy.position.set((i%5-2)*.23,-.26+u*.48,.28);dummy.scale.setScalar(.033*Math.sqrt(s.states[1]));dummy.updateMatrix();unbound.current?.setMatrixAt(i,dummy.matrix);}
  if(products.current)products.current.instanceMatrix.needsUpdate=true;if(unbound.current)unbound.current.instanceMatrix.needsUpdate=true;
 });
 return <group>
  <Shell voltage={()=>model.circuit.synapses[selected].preVoltage}/><Shell lower voltage={()=>model.circuit.v[(syn.config.target-1)*5+syn.config.site]}/>
  <instancedMesh ref={vesicles} args={[undefined,undefined,8]} frustumCulled={false}><sphereGeometry args={[1,28,20]}/><meshPhysicalMaterial color="#d4bb84" roughness={.37} clearcoat={.4}/></instancedMesh>
  <instancedMesh visible={ions} ref={particles} args={[undefined,undefined,96]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshStandardMaterial color="#f3c168" emissive="#c58a36" emissiveIntensity={.3}/></instancedMesh>
  <instancedMesh visible={ions} ref={calcium} args={[undefined,undefined,24]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshStandardMaterial color="#a69ae7" emissive="#8370db" emissiveIntensity={.4}/></instancedMesh>
  <instancedMesh visible={ions} ref={clearance} args={[undefined,undefined,18]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshStandardMaterial color="#66b8d0"/></instancedMesh>
  <instancedMesh visible={ions} ref={products} args={[undefined,undefined,12]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshStandardMaterial color="#db9dba"/></instancedMesh>
  <instancedMesh visible={ions} ref={unbound} args={[undefined,undefined,12]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshStandardMaterial color="#f3c168"/></instancedMesh>
  {model.circuit.params.enzyme>0&&<group position={[-1.7,0,0]}>{[-1,1].map(i=><mesh key={i} position={[i*.07,0,0]} scale={[.09,.18,.13]}><sphereGeometry args={[1,20,16]}/><meshPhysicalMaterial color="#bd829f" roughness={.4}/></mesh>)}</group>}
  {[-.65,0,.65].map(x=><mesh key={x} position={[x,.47,.15]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.105,.037,12,24]}/><meshPhysicalMaterial color="#9681cc" roughness={.4}/></mesh>)}
  {Array.from({length:Math.max(0,Math.round(syn.config.density*5))},(_,j)=><Receptor key={j} model={model} index={selected} x={(j-(Math.round(syn.config.density*5)-1)/2)*.23} onSelect={()=>onSelect(selected)}/>)}
  {[0,1,2].map(i=><mesh key={i} position={[1.65,.25-i*.23,0]} scale={[.12,.15,.1]}><sphereGeometry args={[1,20,16]}/><meshPhysicalMaterial color="#5fa6bd" roughness={.45}/></mesh>)}
  {labels && <><Html position={[compact?-1.25:-2.5,closeup?.6:1.05,0]} center className="synapse-label"><b>Presynaptic bouton</b><small>Ca²⁺ entry · vesicle release</small></Html>
  <Html position={[compact?-1.25:-2.5,closeup?-.85:-1.55,0]} center className="synapse-label"><b>{CELL_NAMES[syn.config.target]}</b><small>{syn.config.site===0?'Soma':`Dendritic site ${syn.config.site}`} · receptor channels</small></Html>
  <Html position={[compact?1.45:2.5,closeup?.3:1,0]} center className="synapse-label"><b>Uptake</b><small>Blue · transporters</small></Html>
  {model.circuit.params.enzyme>0&&<Html position={[compact?-1.4:-2.5,0,0]} center className="synapse-label"><b>Degradation</b><small>Rose · enzyme products</small></Html>}
  {!closeup&&<Html position={[0,-2.6,.3]} center className="synapse-readout"><span ref={label}/><small>Cleft widened · representative particles</small></Html>}</>}
 </group>;
}
const POS:[number,number,number][]=[[-4,0,0],[-1,0,0],[1.6,1.6,0],[.5,-2.2,0],[4,.25,0]];
function CircuitCell({model,id,labels}:{model:CableModel;id:number;labels:boolean}) {
 const geometry=useMemo(()=>{const g=somaGeometry();g.translate(4.15,0,0);g.scale(.45,.45,.45);return g;},[]);
 const dendrites=useMemo(()=>{const parts=morphology();const merged=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());merged.translate(4.15,0,0);merged.scale(.34,.34,.34);return merged;},[]);
 useEffect(()=>()=>{geometry.dispose();dendrites.dispose();},[geometry,dendrites]);
 const soma=useRef<THREE.MeshPhysicalMaterial>(null),label=useRef<HTMLSpanElement>(null);
 useFrame(()=>{const v=id===0?model.v[0]:model.circuit.v[(id-1)*5];if(soma.current){soma.current.emissiveIntensity=Math.max(0,(v+50)/100)*.7;}if(label.current)label.current.textContent=`${v.toFixed(0)} mV`;});
 return <group position={POS[id]}>
  <mesh geometry={geometry}><meshPhysicalMaterial ref={soma} color={id===3?'#b993a8':'#7ab1b1'} emissive={id===3?'#ce93b4':'#87d9b5'} roughness={.4} clearcoat={.3}/></mesh>
  <mesh geometry={dendrites}><meshPhysicalMaterial color={id===3?"#957989":"#537d82"} roughness={.48}/></mesh>
  <Line points={[[0,0,.05],[-.16,.12,.05],[-.32,.24,.05],[-.48,.36,.05],[-.64,.48,.05]]} color="#b9c5ad" lineWidth={4}/>
  {labels&&<Html position={id===3?[1.3,-.1,0]:[0,1,0]} center className="circuit-cell-label"><b>{CELL_NAMES[id]}</b><span ref={label}/></Html>}
 </group>;
}
function ContactLink({model,id,selected,onSelect}:{model:CableModel;id:number;selected:number;onSelect:(i:number)=>void}){
 const s=model.circuit.synapses[id],marker=useRef<THREE.Mesh>(null);
 const curve=useMemo(()=>{const a=new THREE.Vector3(...POS[s.config.source]),b=new THREE.Vector3(...POS[s.config.target]).add(new THREE.Vector3(-.16*s.config.site,.12*s.config.site,.05));const middle=a.clone().lerp(b,.5).add(new THREE.Vector3(0,(id<4?(id-1.5)*1.4:(id%4-1.5)*.32),.15));return new THREE.QuadraticBezierCurve3(a,middle,b);},[id,s.config.source,s.config.target,s.config.site]);
 useFrame(()=>{if(marker.current){const age=model.time-s.lastRelease;const p=Math.min(1,Math.max(0,age/3));marker.current.position.copy(curve.getPoint(p));marker.current.scale.setScalar(age<3?.065:0);}});
 return <group><Line points={curve.getPoints(40)} color={s.config.kind==='I'?'#d694b3':'#83bdab'} lineWidth={selected===id?3:1.2} transparent opacity={selected===id?1:.55}/><mesh position={curve.getPoint(id<4?.30+id*.15:.65)} onClick={e=>{e.stopPropagation();onSelect(id);}}><sphereGeometry args={[selected===id?.13:.09,16,12]}/><meshStandardMaterial color={s.config.kind==='I'?'#d694b3':'#edc17a'}/></mesh><mesh ref={marker}><sphereGeometry args={[1,12,8]}/><meshBasicMaterial color="#ecdfac"/></mesh><Html position={curve.getPoint(id<4?.30+id*.15:.65).add(new THREE.Vector3(0,.2,0))} center className="contact-label"><button aria-label={`Inspect contact ${id+1}`} onClick={()=>onSelect(id)}>{id+1}</button></Html></group>;
}
export function CircuitWorld({model,selected,onSelect,labels}:{model:CableModel;selected:number;onSelect:(i:number)=>void;labels:boolean}) {
 return <group>{model.circuit.synapses.filter(s=>model.circuit.active(s)).map(s=><ContactLink key={s.id} model={model} id={s.id} selected={selected} onSelect={onSelect}/>)}{[0,1,2,3,4].filter(i=>model.circuit.cellActive(i)).map(i=><CircuitCell labels={labels} key={i} model={model} id={i}/>)}</group>;
}
