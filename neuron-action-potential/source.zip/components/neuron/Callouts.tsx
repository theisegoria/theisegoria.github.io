"use client";
import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
// Leader-line labels laid over the canvas as plain DOM: a dot on the structure, an elbowed line,
// and a two-line label ("NAME|role"). Projected every frame; clamped clear of the stage's own controls.
export type Callout = {
  id: string;
  text: string;
  anchor: () => THREE.Vector3;
  label: () => THREE.Vector3;
  side: 1 | -1;
};
const NS = "http://www.w3.org/2000/svg";
export const isJa = () =>
  typeof document !== "undefined" && document.documentElement.lang === "ja";
export default function Callouts({
  items,
  safe = { leftTop: 0.4, top: 0.08, bottom: 92 },
}: {
  items: Callout[];
  safe?: { leftTop: number; top: number; bottom: number };
}) {
  const { camera, size, gl } = useThree();
  const els = useRef<{ it: Callout; l: SVGPolylineElement; d: SVGCircleElement; t: HTMLDivElement }[]>([]);
  const root = useRef<HTMLDivElement | null>(null),
    svg = useRef<SVGSVGElement | null>(null);
  useEffect(() => {
    const host = gl.domElement.parentElement;
    if (!host) return;
    if (getComputedStyle(host).position === "static") host.style.position = "relative";
    const div = document.createElement("div");
    div.className = "callouts";
    div.setAttribute("aria-hidden", "true");
    const s = document.createElementNS(NS, "svg");
    div.appendChild(s);
    host.appendChild(div);
    root.current = div;
    svg.current = s;
    return () => {
      div.remove();
      root.current = null;
    };
  }, [gl]);
  useEffect(() => {
    const div = root.current,
      s = svg.current;
    if (!div || !s) return;
    s.replaceChildren();
    div.querySelectorAll(".callout-text").forEach((n) => n.remove());
    els.current = items.map((it) => {
      const l = document.createElementNS(NS, "polyline");
      l.setAttribute("fill", "none");
      const d = document.createElementNS(NS, "circle");
      d.setAttribute("r", "3");
      s.appendChild(l);
      s.appendChild(d);
      const t = document.createElement("div");
      t.className = "callout-text";
      const [name, role] = it.text.split("|");
      const b = document.createElement("b");
      b.textContent = name;
      t.appendChild(b);
      if (role) {
        const sm = document.createElement("small");
        sm.textContent = role;
        t.appendChild(sm);
      }
      t.style.opacity = "0";
      div.appendChild(t);
      return { it, l, d, t };
    });
  }, [items]);
  const v = new THREE.Vector3();
  useFrame(() => {
    const W = size.width,
      H = size.height;
    const P = (p: THREE.Vector3) => {
      v.copy(p).project(camera);
      return [(v.x * 0.5 + 0.5) * W, (-v.y * 0.5 + 0.5) * H, v.z];
    };
    svg.current?.setAttribute("width", String(W));
    svg.current?.setAttribute("height", String(H));
    // Project, clamp into the free part of the stage, then push labels in each column apart.
    const placed = els.current.map((e) => {
      const [ax, ay, az] = P(e.it.anchor());
      let [lx, ly] = P(e.it.label());
      const w = e.t.offsetWidth || 110,
        h = e.t.offsetHeight || 30;
      if (e.it.side < 0) lx = Math.max(lx, w + 14);
      else lx = Math.min(lx, W - w - 14);
      const top = e.it.side < 0 && lx < W * 0.45 ? safe.leftTop * H : safe.top * H;
      return { ...e, ax, ay, az, lx, ly, w, h, top, bottom: H - safe.bottom };
    });
    for (const side of [-1, 1]) {
      const col = placed.filter((p) => p.it.side === side).sort((a, b) => a.ly - b.ly);
      for (let i = 0; i < col.length; i++) {
        col[i].ly = Math.max(col[i].ly, col[i].top + col[i].h / 2);
        if (i) {
          const prev = col[i - 1];
          const overlapX = Math.abs(prev.lx - col[i].lx) < Math.max(prev.w, col[i].w) + 10;
          if (overlapX) col[i].ly = Math.max(col[i].ly, prev.ly + (prev.h + col[i].h) / 2 + 6);
        }
      }
      for (let i = col.length - 1; i >= 0; i--) {
        const lim = i === col.length - 1 ? col[i].bottom - col[i].h / 2 : col[i + 1].ly - (col[i + 1].h + col[i].h) / 2 - 6;
        if (col[i].ly > lim) col[i].ly = Math.max(lim, col[i].top + col[i].h / 2);
      }
    }
    for (const { it, l, d, t, ax, ay, az, lx, ly } of placed) {
      const op = az > 1 ? "0" : "1";
      const ex = lx - it.side * 12;
      l.setAttribute("points", `${ax},${ay} ${ex},${ly} ${lx},${ly}`);
      d.setAttribute("cx", String(ax));
      d.setAttribute("cy", String(ay));
      l.style.opacity = op;
      d.style.opacity = op;
      t.style.opacity = op;
      t.style.transform = `translate(${it.side > 0 ? lx + 5 : lx - 5}px,${ly}px) translate(${it.side > 0 ? "0" : "-100%"},-50%)`;
    }
  });
  return null;
}
