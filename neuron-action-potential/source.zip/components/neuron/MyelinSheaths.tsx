import { useMemo, useEffect } from 'react';
import * as THREE from 'three';
import { CableModel } from '@/lib/neuron/model.mjs';
import { axonCurve } from '@/lib/neuron/geometry';

// Smooth curved sleeves with narrowed paranodal ends. The displayed thickness
// and exposed gaps are magnified; electrical segments come from the same layout.
export default function MyelinSheaths({ model, onCell, cutaway }: {model: CableModel; onCell: (id:number)=>void; cutaway:boolean}) {
  const cells = model.membrane.cells;
  const meshes = useMemo(()=>cells.filter(c=>c.present).flatMap(c=> Array.from({length:cutaway?4:1},(_,layer)=> {
    const start=(c.start-.45)/63, end=(c.end+.45)/63;
    const path=new THREE.CatmullRomCurve3(Array.from({length:20},(_,i)=>axonCurve.getPointAt(start+(end-start)*i/19)));
    const g=new THREE.TubeGeometry(path,48,1,40,false);

    const p=g.attributes.position;
    for(let j=0;j<=48;j++) {
      const t=j/48, centre=path.getPointAt(t);
      const radius=.143+(.087-layer*.017)*(.12+.88*Math.pow(Math.sin(Math.PI*t),.4));
      for(let k=0;k<=40;k++) {
        const angle=(cutaway?.86:0)+(k/40)*(cutaway?Math.PI*2-1.72:Math.PI*2);
        const tangent=path.getTangentAt(t);
        const normal=new THREE.Vector3(0,0,1).addScaledVector(tangent,-tangent.z).normalize();
        const side=new THREE.Vector3().crossVectors(tangent,normal).normalize();
        const offset=normal.multiplyScalar(Math.cos(angle)*radius).addScaledVector(side,Math.sin(angle)*radius);
        p.setXYZ(j*41+k,centre.x+offset.x,centre.y+offset.y,centre.z+offset.z);
      }
    }
    g.computeVertexNormals();
    const nucleus=path.getPointAt(.52).add(new THREE.Vector3(0,.19,.075));
    return { id:c.id, layer, geometry:g, nucleus };
  })),[cells,cutaway]);
  useEffect(()=>()=>meshes.forEach(m=>m.geometry.dispose()),[meshes]);
  return <group>{meshes.map(m=><group key={`${m.id}-${m.layer}`}>
    <mesh geometry={m.geometry} onClick={e=>{e.stopPropagation();onCell(m.id);}}>
      <meshPhysicalMaterial color={m.layer%2 ? "#829d97" : "#c4d0bc"} roughness={.38} clearcoat={.32} clearcoatRoughness={.3} sheen={.25} sheenColor="#dce7cd" side={THREE.DoubleSide}/>
    </mesh>
    {m.layer===0 && <mesh position={m.nucleus} scale={[.12,.06,.055]} onClick={e=>{e.stopPropagation();onCell(m.id);}}><sphereGeometry args={[1,16,12]}/><meshStandardMaterial color="#6c8586" roughness={.8}/></mesh>}
  </group>)}</group>;
}
