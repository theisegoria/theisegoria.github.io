import {useState,useRef,useEffect} from 'react';
import {CableModel} from '@/lib/neuron/model.mjs';
import type {CircuitParameters,Contact} from '@/lib/neuron/circuit.mjs';
type Protocol='message'|'burst'|'inhibit'|'learning';
export default function CircuitControls({model,selected,onSelect,onEdit,onProtocol}:{model:CableModel;selected:number;onSelect:(i:number)=>void;onEdit:()=>void;onProtocol:(p:Protocol)=>void}){
 const c=model.circuit,s=c.synapses[selected];
 const [burstResult,setBurstResult]=useState<{key:string;pulse:number[];burst:number[]}|null>(null);
 const [trials,setTrials]=useState<{key:string;values:number[]}|null>(null),[busy,setBusy]=useState(false);const cancel=useRef(false);
 useEffect(()=>()=>{cancel.current=true;},[]);
 const key=JSON.stringify([selected,c.params,c.synapses.map(s=>s.config),model.myelin,model.params.gNa,model.params.gK]);
 const set=(k:keyof CircuitParameters,v:any)=>{Object.assign(c.params,{[k]:v});onEdit();};
 const edit=(k:keyof Contact,v:any)=>{Object.assign(s.config,{[k]:v});onEdit();};
 const compareBurst=()=>{
   const settings={params:{...c.params},contacts:c.synapses.map(s=>({...s.config})),myelin:{...model.myelin,removed:[...model.myelin.removed]},membrane:{...model.params,current:0}};
   onProtocol('burst');
   const run=(burst:boolean)=>{const m=new CableModel();m.params={...settings.membrane};m.circuit.params={...settings.params};m.circuit.synapses.forEach((s,i)=>Object.assign(s.config,settings.contacts[i]));m.configureMyelin(settings.myelin);m.scheduledPulses=burst?[0,12,24,36,48]:[0];let peak=0,minReady=8;for(let i=0;i<13000;i++){m.step();peak=Math.max(peak,m.circuit.synapses[selected].C);minReady=Math.min(minReady,m.circuit.synapses[selected].ready);}return [m.circuit.spikes[1],peak,minReady,m.circuit.synapses[selected].released];};
   setBusy(true);setTimeout(()=>{try{setBurstResult({key,pulse:run(false),burst:run(true)});}finally{setBusy(false);}},30);
 };
 const repeat=async()=>{
  setBusy(true);cancel.current=false;const settings={params:{...c.params,stochastic:true},contacts:c.synapses.map(s=>({...s.config})),myelin:{...model.myelin,removed:[...model.myelin.removed]},membrane:{...model.params,current:0}};const values:number[]=[];
  try{for(let seed=0;seed<12;seed++){if(cancel.current)break;const m=new CableModel();m.params={...settings.membrane};m.circuit.params={...settings.params,seed:settings.params.seed+seed};m.circuit.synapses.forEach((s,i)=>Object.assign(s.config,settings.contacts[i]));m.configureMyelin(settings.myelin);m.pulse();for(let i=0;i<8000;i++)m.step();values.push(m.circuit.spikes[1]);setTrials({key,values:[...values]});await new Promise(r=>setTimeout(r,0));}}finally{if(!cancel.current)setBusy(false);}
 };
 return <section className="circuit-controls" aria-labelledby="circuit-controls-title">
  <p className="eyebrow">SYNAPTIC TRANSMISSION</p><h2 id="circuit-controls-title">Follow the message.</h2>
  <label>Network<select aria-label="Circuit topology" value={c.params.mode} onChange={e=>{set('mode',e.target.value);onSelect(0);}}><option value="pair">Two neurons · distributed contacts</option><option value="chain">Three neurons · relay chain</option><option value="feedforward">Five neurons · feedforward inhibition</option><option value="feedback">Five neurons · feedback circuit</option></select></label>
  <div className="protocol-buttons">{([['message','Does the message arrive?'],['burst','One pulse vs a burst'],['inhibit','Can inhibition stop it?'],['learning','Repeated activity & learning']] as const).map(([p,label])=><button key={p} disabled={busy} onClick={()=>p==='burst'?compareBurst():onProtocol(p)}>{label}</button>)}</div>
  {burstResult&&burstResult.key===key&&<div className="burst-result"><b>Matched pulse / burst comparison</b><table><thead><tr><th>Outcome</th><th>Pulse</th><th>Burst</th></tr></thead><tbody>{['Receiver spikes','Peak cleft µM','Minimum ready','Released dose¹'].map((label,i)=><tr key={label}><th>{label}</th><td>{burstResult.pulse[i].toFixed(i===0?0:1)}</td><td>{burstResult.burst[i].toFixed(i===0?0:1)}</td></tr>)}</tbody></table><small>130 ms trials. Same seed and settings; burst has five pulses 12 ms apart. ¹ µM × cleft volume at selected contact.</small></div>}
  <label>Selected contact<select aria-label="Selected synaptic contact" value={selected} onChange={e=>onSelect(+e.target.value)}>{c.synapses.filter(s=>c.active(s)||s.id===selected||!s.config.enabled).map(s=><option value={s.id} key={s.id}>{s.id+1}. {s.config.label}</option>)}</select></label>
  <label className="check-line"><input type="checkbox" checked={s.config.enabled} onChange={e=>edit('enabled',e.target.checked)}/> Contact enabled</label>
  <div className="contact-buttons">{c.synapses.filter(s=>s.id<4||c.params.mode==='feedback'||(c.params.mode==='feedforward'&&s.id<8)||(c.params.mode==='chain'&&s.id===5)).map(s=><button key={s.id} aria-pressed={s.id===selected} onClick={()=>onSelect(s.id)}>{s.id+1}</button>)}</div>
  <label>Receptor effect<select aria-label="Receptor effect" value={s.config.kind} onChange={e=>edit('kind',e.target.value)}><option value="E">Excitatory · reversal 0 mV</option><option value="I">Inhibitory · reversal −75 mV</option></select></label>
  <label>Postsynaptic location<select aria-label="Postsynaptic location" value={s.config.site} onChange={e=>edit('site',+e.target.value)}>{['Soma','Proximal dendrite','Middle dendrite','Distal dendrite','Dendritic tip'].map((x,i)=><option key={x} value={i}>{x}</option>)}</select></label>
  {([['weight','Initial strength',0,3,.05,'×'],['density','Binding-site density',0,2,.1,'×'],['delay','Input delay',0,8,.1,'ms']] as const).map(([k,label,min,max,step,unit])=><label key={k}>{label}<output>{s.config[k].toFixed(2)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={s.config[k]} onChange={e=>edit(k,+e.target.value)}/></label>)}
  <details open><summary>Release & clearance</summary>
   <label className="check-line"><input type="checkbox" checked={c.params.stochastic} onChange={e=>set('stochastic',e.target.checked)}/> Probabilistic vesicle release</label>
   <label>Random seed<input aria-label="Random seed" type="number" min="1" max="99999" value={c.params.seed} onChange={e=>set('seed',Math.max(1,Math.min(99999,Math.round(+e.target.value)||1)))}/></label>
   {([['release','Release drive',0,1,.01,'×'],['recovery','Vesicle recovery',10,300,10,'ms'],['clearance','Transporter capacity',0,3,.1,'×'],['enzyme','Enzyme clearance',0,3,.1,'×']] as const).map(([k,label,min,max,step,unit])=><label key={k}>{label}<output>{c.params[k].toFixed(2)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={c.params[k]} onChange={e=>set(k,+e.target.value)}/></label>)}
  </details>
  <label className="check-line"><input type="checkbox" checked={c.params.plasticity} onChange={e=>set('plasticity',e.target.checked)}/> Spike-timing plasticity</label>
  <p className="science-note">Illustrative pair-based rule: a presynaptic spike before a postsynaptic spike strengthens an excitatory contact; reverse ordering weakens it. Weights stay between 0.05 and 3. Reset restores initial weights.</p>
  <label>Inhibitory stimulus time<output>{c.params.inhibitionTime} ms</output><input aria-label="Inhibitory stimulus time" type="range" min="0" max="45" step="1" value={c.params.inhibitionTime} onChange={e=>set('inhibitionTime',+e.target.value)}/></label>
  <p className="science-note">Used by “Can inhibition stop it?”: a direct 1 ms pulse drives the interneuron at this time after the source stimulus.</p>
  <button className="run-trials" disabled={busy} onClick={repeat}>{busy?'Running trials…':'Repeat 12 stochastic trials'}</button>
  {trials&&trials.key===key&&<div className="trial-result" role="status"><b>{trials.values.filter(n=>n>0).length} / {trials.values.length} trials reached the receiver</b><div className="trial-dots">{trials.values.map((n,i)=><span key={i} title={`Seed ${c.params.seed+i}: ${n} receiver spikes`} className={n?'success':''}>{n}</span>)}</div><small>Numbers are receiver spikes in 80 ms. Consecutive seeds; same single pulse and settings. This batch does not alter the live recording.</small></div>}
  <p className="science-note">Changes reset recordings. Fast receptor kinetics and transmitter clearance are generic teaching models. Enzyme clearance is optional and off by default; this is not a calibrated glutamatergic or cholinergic synapse.</p>
 </section>;
}
