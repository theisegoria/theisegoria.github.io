"use client";
import {
  useEffect,
  useMemo,
  useRef,
  Suspense,
  Component,
  type ReactNode,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html, Line, AdaptiveDpr, Environment, Lightformer } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { CableModel, COUNT, BRANCHES } from "@/lib/neuron/model.mjs";
import {
  axonCurve,
  somaGeometry,
  morphology,
  tube,
  channelSites,
  membranePosition,
  branchCurves,
  probePosition,
} from "@/lib/neuron/geometry";
import {SynapticWorld,CircuitWorld} from "./SynapticWorld";
import MyelinSheaths from "./MyelinSheaths";
import { makeVoltageMaterial } from "./VoltageMaterial";
const NA = "#9ae8c7",
  K = "#eab67a";
type Props = {
  model: CableModel;
  mode: "axon"|"synapse"|"circuit";
  selectedContact:number;
  onContact:(i:number)=>void;
  myelinRevision: number;
  cutaway: boolean;
  onCell: (id:number)=>void;
  probeIndex: number;
  labels: boolean;
  ions: boolean;
  focus: boolean;
  branchView: boolean;
  viewRevision: number;
  onProbe: (i: number) => void;
};
function useChannelSites(model: CableModel) {
  return useMemo(()=>model.myelin.enabled ? [
    ...model.membrane.cells.map(cell=> { const index=cell.end+1,t=index/63; return {index,t,curve:axonCurve,radius:.145-.04*t,scale:.8}; }),
    ...channelSites.filter(site=>site.index>=64),
  ] : channelSites,[model.myelin.enabled,model.membrane.cells]);
}
function MembraneChannels({ model }: { model: CableModel }) {
  const sites=useChannelSites(model);
  const naRef = useRef<THREE.InstancedMesh>(null),
    kRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    [naRef, kRef].forEach((ref, species) => {
      if (!ref.current) return;
      sites.forEach((site, si) => {
        const angle = species === 0 ? 1.14 : 2.1,
          { p, normal } = membranePosition(
            site.t,
            angle,
            site.radius,
            site.curve,
          );
        const tangent = site.curve.getTangentAt(site.t),
          side = new THREE.Vector3().crossVectors(normal, tangent).normalize();
        const open =
          species === 0
            ? model.m[site.index] ** 3 * model.h[site.index]
            : model.n[site.index] ** 4;
        const spread = (0.037 + 0.15 * Math.sqrt(open)) * site.scale;
        for (let j = 0; j < 5; j++) {
          const a = (j / 5) * Math.PI * 2;
          dummy.position
            .copy(p)
            .addScaledVector(tangent, Math.cos(a) * spread)
            .addScaledVector(side, Math.sin(a) * spread);
          dummy.quaternion.setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            normal,
          );
          dummy.scale.set(0.027, 0.11, 0.027).multiplyScalar(model.membrane.channels[site.index] < .1 ? 0 : site.scale);
          dummy.updateMatrix();
          ref.current!.setMatrixAt(si * 5 + j, dummy.matrix);
        }
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      <instancedMesh
        ref={naRef}
        args={[undefined, undefined, sites.length * 5]}
        frustumCulled={false}
      >
        <cylinderGeometry args={[1, 1, 1, 6]} />
        <meshStandardMaterial
          color={NA}
          emissive={NA}
          emissiveIntensity={0.22}
          roughness={0.4}
        />
      </instancedMesh>
      <instancedMesh
        ref={kRef}
        args={[undefined, undefined, sites.length * 5]}
        frustumCulled={false}
      >
        <cylinderGeometry args={[1, 1, 1, 6]} />
        <meshStandardMaterial
          color={K}
          emissive={K}
          emissiveIntensity={0.16}
          roughness={0.4}
        />
      </instancedMesh>
    </>
  );
}
function IonParticles({ model }: { model: CableModel }) {
  const sites=useChannelSites(model);
  const refs = [
    useRef<THREE.InstancedMesh>(null),
    useRef<THREE.InstancedMesh>(null),
  ];
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    refs.forEach((ref, species) => {
      if (!ref.current) return;
      sites.forEach((site, si) => {
        for (let j = 0; j < 9; j++) {
          const clock =
            species === 0 ? model.fluxNa[site.index] : model.fluxK[site.index];
          const progress = (clock + j / 9 + si * 0.13) % 1;
          // Ions pass radially through the pore. At the wrap boundary their size fades to zero.
          const radius =
            species === 0
              ? site.radius + 0.4 * site.scale - progress * 0.5 * site.scale
              : site.radius - 0.1 * site.scale + progress * 0.5 * site.scale;
          const { p } = membranePosition(
            site.t +
              Math.sin(j * 9 + si) * 0.002 * (1 - Math.sin(progress * Math.PI)),
            species === 0 ? 1.14 : 2.1,
            radius,
            site.curve,
          );
          dummy.position.copy(p);
          const scale =
            site.scale *
            0.027 *
            Math.min(1, progress * 12, (1 - progress) * 12);
          dummy.scale.setScalar(model.membrane.channels[site.index] < .1 ? 0 : scale);
          dummy.updateMatrix();
          ref.current!.setMatrixAt(si * 9 + j, dummy.matrix);
        }
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      {refs.map((ref, i) => (
        <instancedMesh
          key={i}
          ref={ref}
          args={[undefined, undefined, sites.length * 9]}
          frustumCulled={false}
        >
          <sphereGeometry args={[1, 6, 5]} />
          <meshBasicMaterial color={i ? K : NA} toneMapped={false} />
        </instancedMesh>
      ))}
    </>
  );
}
function Neuron({ model, onCell, cutaway, labels, ions, onProbe }: Props) {
  const field = useMemo(() => new Float32Array(COUNT * 4), []);
  const texture = useMemo(() => {
    const t = new THREE.DataTexture(
      field,
      COUNT,
      1,
      THREE.RGBAFormat,
      THREE.FloatType,
    );
    t.minFilter = THREE.LinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.needsUpdate = true;
    return t;
  }, [field]);
  const material = useMemo(() => makeVoltageMaterial(texture), [texture]);
  const soma = useMemo(somaGeometry, []),
    dendrites = useMemo(morphology, []),
    axon = useMemo(() => tube(axonCurve, 0.145, 0.105, 180, true), []);
  const branches = useMemo(
    () =>
      BRANCHES.map((b, i) =>
        tube(
          branchCurves[i],
          0.105 * b.diameter,
          0.105 * b.diameter,
          60,
          true,
          b.start,
          b.end,
        ),
      ),
    [],
  );
  const bulbs = useMemo(
    () =>
      BRANCHES.map((b) => {
        const g = new THREE.SphereGeometry(0.1, 16, 12);
        g.setAttribute(
          "aCable",
          new THREE.BufferAttribute(
            new Float32Array(g.attributes.position.count).fill(b.end),
            1,
          ),
        );
        return g;
      }),
    [],
  );
  const hitTube = useMemo(() => tube(axonCurve, 0.14, 0.14, 90, true), []);
  const probe = probePosition(model.probe);
  useEffect(
    () => () => {
      texture.dispose();
      material.dispose();
      soma.dispose();
      axon.dispose();
      dendrites.forEach((g) => g.dispose());
      [...branches, ...bulbs, hitTube].forEach((g) => g.dispose());
    },
    [texture, material, soma, axon, dendrites, branches, bulbs, hitTube],
  );
  useFrame(() => {
    for (let i = 0; i < COUNT; i++) {
      field[i * 4] = (model.v[i] + 85) / 130;
      field[i * 4 + 1] = model.m[i] ** 3 * model.h[i];
      field[i * 4 + 2] = model.n[i] ** 4;
      field[i * 4 + 3] = 1;
    }
    texture.needsUpdate = true;
  });
  return (
    <group>
      <mesh geometry={soma} material={material} />
      <mesh position={[-4.25, 0.04, 0.47]} scale={[0.4, 0.47, 0.3]}>
        <sphereGeometry args={[1, 36, 24]} />
        <meshPhysicalMaterial
          color="#203e4c"
          roughness={0.32}
          clearcoat={0.4}
        />
      </mesh>
      {dendrites.map((g, i) => (
        <mesh key={i} geometry={g} material={material} />
      ))}
      <mesh geometry={axon} material={material} />
      <MyelinSheaths model={model} onCell={onCell} cutaway={cutaway} />
      <mesh
        geometry={hitTube}
        onClick={(e) => {
          e.stopPropagation();
          let best = 0,
            dist = Infinity;
          for (let i = 0; i < 64; i++) {
            const d = axonCurve.getPointAt(i / 63).distanceToSquared(e.point);
            if (d < dist) {
              dist = d;
              best = i;
            }
          }
          onProbe(best);
        }}
        onPointerOver={() => (document.body.style.cursor = "crosshair")}
        onPointerOut={() => (document.body.style.cursor = "auto")}
      >
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      {BRANCHES.map((b, i) => (
        <group key={b.id}>
          <mesh
            geometry={branches[i]}
            material={material}
            onClick={(e) => {
              e.stopPropagation();
              onProbe(b.end);
            }}
          />
          <mesh
            position={branchCurves[i].getPointAt(1)}
            geometry={bulbs[i]}
            material={material}
            onClick={(e) => {
              e.stopPropagation();
              onProbe(b.end);
            }}
          />
          {labels && (
            <Html
              position={branchCurves[i]
                .getPointAt(1)
                .add(new THREE.Vector3(0.24, 0.04, 0))}
              center
              className="terminal-label"
            >
              <button
                aria-label={"Record terminal " + b.label}
                onClick={() => onProbe(b.end)}
              >
                {b.label}
              </button>
            </Html>
          )}
        </group>
      ))}
      <MembraneChannels model={model} />
      {ions && <IonParticles model={model} />}
      <mesh position={probe}>
        <sphereGeometry args={[0.21, 24, 12]} />
        <meshBasicMaterial
          color="#edf4c9"
          wireframe
          transparent
          opacity={0.18}
        />
      </mesh>
      {labels && (
        <>
          <Html position={[-6.9, 2.7, 0]} center className="anatomy-label">
            <span>DENDRITES</span>
            <small>receive</small>
          </Html>
          <Html position={[-4.7, -1.65, 0.2]} center className="anatomy-label">
            <span>SOMA</span>
            <small>integrate</small>
          </Html>
          <Html position={[2, -1.3, 0.2]} center className="anatomy-label">
            <span>AXON</span>
            <small>propagate →</small>
          </Html>
          <Html position={[7.7, 2.65, 0]} center className="anatomy-label">
            <span>TERMINALS</span>
            <small>transmit</small>
          </Html>
        </>
      )}
      <Line
        points={[probe.toArray(), [probe.x, probe.y + 0.8, probe.z]]}
        color="#d2ddb0"
        lineWidth={0.8}
        transparent
        opacity={0.55}
      />
      <Html
        position={[probe.x, probe.y + 0.92, probe.z]}
        center
        className="probe-label"
      >
        RECORDING SITE
      </Html>
    </group>
  );
}
function CameraRig({
  mode,
  focus,
  branchView,
  viewRevision,
  model,
}: {
  mode: "axon"|"synapse"|"circuit";
  focus: boolean;
  branchView: boolean;
  viewRevision: number;
  model: CableModel;
}) {
  const controls = useRef<any>(null);
  const { camera, size } = useThree();
  const destination = useRef({
    position: new THREE.Vector3(),
    target: new THREE.Vector3(),
    moving: false,
  });
  const initialized = useRef(false);
  useEffect(() => {
    const target = mode!=="axon" ? new THREE.Vector3(mode==="circuit"?(model.circuit.params.mode==="pair"?-2.5:model.circuit.params.mode==="chain"?-1:0):0,0,0) : focus
      ? probePosition(model.probe)
      : branchView
        ? new THREE.Vector3(7.6, 0, 0)
        : new THREE.Vector3(0.4, 0, 0);
    const distance = mode!=="axon" ? Math.max(mode==="synapse"?(focus?4.6:9):(model.circuit.params.mode==="pair"?8:11),(mode==="synapse"?(focus?4.5:8):(model.circuit.params.mode==="pair"?6:10))/(size.width/size.height)) : focus
      ? 3.4
      : branchView
        ? Math.max(size.width < 600 ? 10.5 : 7, 6 / (size.width / size.height))
        : Math.max(
            14,
            20 /
              (2 * Math.tan((39 * Math.PI) / 360) * (size.width / size.height)),
          );
    destination.current = {
      position: target
        .clone()
        .add(new THREE.Vector3(0, focus ? 1.4 : 1.7, distance)),
      target,
      moving: true,
    };
    if (
      !initialized.current ||
      matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      camera.position.copy(destination.current.position);
      controls.current?.target.copy(target);
      controls.current?.update();
      destination.current.moving = false;
    }
    initialized.current = true;
  }, [mode, focus, branchView, viewRevision, model, camera, size.width, size.height]);
  useFrame((_, dt) => {
    const d = destination.current;
    if (!d.moving || !controls.current) return;
    const a = 1 - Math.exp(-7 * dt);
    camera.position.lerp(d.position, a);
    controls.current.target.lerp(d.target, a);
    if (camera.position.distanceTo(d.position) < 0.005) d.moving = false;
    controls.current.update();
  });
  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.09}
      minDistance={1.25}
      maxDistance={70}
      enablePan
      rotateSpeed={0.5}
      onStart={() => (destination.current.moving = false)}
    />
  );
}
function DepthDust() {
  const points = useMemo(() => {
    const a = new Float32Array(150 * 3);
    for (let i = 0; i < 150; i++) {
      a[i * 3] = Math.sin(i * 54.21) * 18;
      a[i * 3 + 1] = Math.cos(i * 21.67) * 10;
      a[i * 3 + 2] = -3 - Math.abs(Math.sin(i * 3.81)) * 10;
    }
    return a;
  }, []);
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[points, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#567282"
        size={0.025}
        transparent
        opacity={0.35}
        depthWrite={false}
      />
    </points>
  );
}
class SceneBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="webgl-error">
        The 3D view needs WebGL 2. Enable hardware acceleration or try a current
        browser. The model and voltage trace remain available.
      </div>
    ) : (
      this.props.children
    );
  }
}
export default function NeuronScene(props: Props) {
  return (
    <SceneBoundary>
      <Canvas
        dpr={[1, 1.65]}
        camera={{ position: [0.3, 2.1, 19.3], fov: 39, near: 0.1, far: 90 }}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
        }}
        fallback={
          <div className="webgl-error">
            WebGL is unavailable. The live model and graph remain available
            below.
          </div>
        }
      >
        <fog attach="fog" args={["#0b141d", 24, 54]} />
        <ambientLight intensity={0.25} />
        <hemisphereLight args={["#c7e5ef", "#172332", .7]} />
        <directionalLight position={[-4, 5, 8]} intensity={2} color="#bfe6f4" />
        <pointLight position={[4, -2, 5]} intensity={20} color="#8fcfb8" />
        <pointLight position={[-6, 3, -2]} intensity={25} color="#649dd9" />
        <Suspense fallback={null}>
          <Environment frames={1} resolution={128}>
            <Lightformer intensity={2.5} color="#e5f3ed" position={[0,5,-4]} rotation={[Math.PI/2,0,0]} scale={[14,5,1]} />
            <Lightformer intensity={1.5} color="#8fc1e0" position={[-7,1,3]} rotation={[0,Math.PI/2,0]} scale={[5,7,1]} />
            <Lightformer intensity={1} color="#e5c8a0" position={[8,2,2]} rotation={[0,-Math.PI/2,0]} scale={[3,6,1]} />
          </Environment>
          {props.mode==="axon"?<Neuron {...props}/>:props.mode==="synapse"?<SynapticWorld closeup={props.focus} labels={props.labels} ions={props.ions} model={props.model} selected={props.selectedContact} onSelect={props.onContact}/>:<CircuitWorld labels={props.labels} model={props.model} selected={props.selectedContact} onSelect={props.onContact}/>}
          <DepthDust />
          <EffectComposer multisampling={0}>
            <Bloom
              intensity={0.32}
              luminanceThreshold={0.85}
              luminanceSmoothing={0.35}
              mipmapBlur
            />
          </EffectComposer>
        </Suspense>
        <CameraRig
          mode={props.mode}
          focus={props.focus}
          branchView={props.branchView}
          viewRevision={props.viewRevision}
          model={props.model}
        />
        <AdaptiveDpr pixelated />
      </Canvas>
    </SceneBoundary>
  );
}
