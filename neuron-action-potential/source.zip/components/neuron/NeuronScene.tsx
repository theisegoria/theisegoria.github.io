"use client";
import {
  useEffect,
  useMemo,
  useRef,
  Suspense,
  Component,
  type ReactNode,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html, Line, AdaptiveDpr, Environment, Lightformer } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette, ToneMapping } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import * as THREE from "three";
import { CableModel, COUNT, BRANCHES } from "@/lib/neuron/model.mjs";
import {
  axonCurve,
  axonRadius,
  branchRadius,
  boutonGeometry,
  somaGeometry,
  morphology,
  tube,
  channelSites,
  membranePosition,
  branchCurves,
  probePosition,
  soma as somaCentre,
} from "@/lib/neuron/geometry";
import {SynapticWorld,CircuitWorld} from "./SynapticWorld";
import MyelinSheaths from "./MyelinSheaths";
import MembranePatch from "./MembranePatch";
import Callouts, { isJa, type Callout } from "./Callouts";
import { makeVoltageMaterial } from "./VoltageMaterial";
const NA = "#9ae8c7",
  K = "#eab67a";
const T = (en: string, ja: string) => (isJa() ? ja : en);
type Props = {
  model: CableModel;
  mode: "axon"|"synapse"|"circuit";
  selectedContact:number;
  onContact:(i:number)=>void;
  myelinRevision: number;
  cutaway: boolean;
  onCell: (id:number)=>void;
  probeIndex: number;
  labels: boolean;
  ions: boolean;
  focus: boolean;
  branchView: boolean;
  viewRevision: number;
  onProbe: (i: number) => void;
};
function useChannelSites(model: CableModel) {
  return useMemo(()=>model.myelin.enabled ? [
    ...model.membrane.cells.map(cell=> { const index=cell.end+1,t=index/63; return {index,t,curve:axonCurve,radius:.145-.04*t,scale:.8}; }),
    ...channelSites.filter(site=>site.index>=64),
  ] : channelSites,[model.myelin.enabled,model.membrane.cells]);
}
// Channel clusters sit in the membrane as low protein lumps (four domains around a pore).
// A bright core inside each cluster grows with the local open fraction, so open channels light up.
function MembraneChannels({ model }: { model: CableModel }) {
  const sites=useChannelSites(model);
  const lumpRefs = [useRef<THREE.InstancedMesh>(null), useRef<THREE.InstancedMesh>(null)];
  const coreRefs = [useRef<THREE.InstancedMesh>(null), useRef<THREE.InstancedMesh>(null)];
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const up = useMemo(() => new THREE.Vector3(0, 1, 0), []);
  useFrame(() => {
    [0, 1].forEach((species) => {
      const lumps = lumpRefs[species].current, cores = coreRefs[species].current;
      if (!lumps || !cores) return;
      sites.forEach((site, si) => {
        const angle = species === 0 ? 1.14 : 2.1,
          { p, normal } = membranePosition(site.t, angle, site.radius * .96, site.curve);
        const tangent = site.curve.getTangentAt(site.t),
          side = new THREE.Vector3().crossVectors(normal, tangent).normalize();
        const open = species === 0 ? model.m[site.index] ** 3 * model.h[site.index] : model.n[site.index] ** 4;
        const hidden = model.membrane.channels[site.index] < .1;
        const spread = (0.024 + 0.03 * Math.sqrt(open)) * site.scale;
        for (let j = 0; j < 4; j++) {
          const a = (j / 4) * Math.PI * 2 + Math.PI / 4;
          dummy.position.copy(p).addScaledVector(tangent, Math.cos(a) * spread).addScaledVector(side, Math.sin(a) * spread);
          dummy.quaternion.setFromUnitVectors(up, normal);
          dummy.scale.set(0.026, 0.045, 0.026).multiplyScalar(hidden ? 0 : site.scale);
          dummy.updateMatrix();
          lumps.setMatrixAt(si * 4 + j, dummy.matrix);
        }
        dummy.position.copy(p).addScaledVector(normal, .01 * site.scale);
        dummy.scale.setScalar(hidden ? 0 : (0.008 + 0.03 * Math.sqrt(open)) * site.scale);
        dummy.updateMatrix();
        cores.setMatrixAt(si, dummy.matrix);
      });
      lumps.instanceMatrix.needsUpdate = true;
      cores.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      {[NA, K].map((c, i) => (
        <group key={c}>
          <instancedMesh ref={lumpRefs[i]} args={[undefined, undefined, sites.length * 4]} frustumCulled={false}>
            <sphereGeometry args={[1, 14, 10]} />
            <meshPhysicalMaterial color={i ? "#c99a62" : "#6fbf9f"} roughness={0.5} sheen={0.6} sheenColor="#ffffff" />
          </instancedMesh>
          <instancedMesh ref={coreRefs[i]} args={[undefined, undefined, sites.length]} frustumCulled={false}>
            <sphereGeometry args={[1, 12, 8]} />
            <meshBasicMaterial color={c} toneMapped={false} />
          </instancedMesh>
        </group>
      ))}
    </>
  );
}
function IonParticles({ model }: { model: CableModel }) {
  const sites=useChannelSites(model);
  const refs = [
    useRef<THREE.InstancedMesh>(null),
    useRef<THREE.InstancedMesh>(null),
  ];
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(() => {
    refs.forEach((ref, species) => {
      if (!ref.current) return;
      sites.forEach((site, si) => {
        for (let j = 0; j < 9; j++) {
          const clock =
            species === 0 ? model.fluxNa[site.index] : model.fluxK[site.index];
          const progress = (clock + j / 9 + si * 0.13) % 1;
          // Ions pass radially through the pore. At the wrap boundary their size fades to zero.
          const radius =
            species === 0
              ? site.radius + 0.4 * site.scale - progress * 0.5 * site.scale
              : site.radius - 0.1 * site.scale + progress * 0.5 * site.scale;
          const { p } = membranePosition(
            site.t +
              Math.sin(j * 9 + si) * 0.002 * (1 - Math.sin(progress * Math.PI)),
            species === 0 ? 1.14 : 2.1,
            radius,
            site.curve,
          );
          dummy.position.copy(p);
          const scale =
            site.scale *
            0.022 *
            Math.min(1, progress * 12, (1 - progress) * 12);
          dummy.scale.setScalar(model.membrane.channels[site.index] < .1 ? 0 : scale);
          dummy.updateMatrix();
          ref.current!.setMatrixAt(si * 9 + j, dummy.matrix);
        }
      });
      ref.current.instanceMatrix.needsUpdate = true;
    });
  });
  return (
    <>
      {refs.map((ref, i) => (
        <instancedMesh
          key={i}
          ref={ref}
          args={[undefined, undefined, sites.length * 9]}
          frustumCulled={false}
        >
          <sphereGeometry args={[1, 8, 6]} />
          <meshBasicMaterial color={i ? K : NA} toneMapped={false} />
        </instancedMesh>
      ))}
    </>
  );
}
function Neuron({ model, onCell, cutaway, labels, ions, onProbe, focus }: Props) {
  const narrow = useThree((s) => s.size.width < 600);
  const field = useMemo(() => new Float32Array(COUNT * 4), []);
  const texture = useMemo(() => {
    const t = new THREE.DataTexture(
      field,
      COUNT,
      1,
      THREE.RGBAFormat,
      THREE.FloatType,
    );
    t.minFilter = THREE.LinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.needsUpdate = true;
    return t;
  }, [field]);
  const material = useMemo(() => makeVoltageMaterial(texture), [texture]);
  const somaMaterial = useMemo(() => makeVoltageMaterial(texture, { translucent: true }), [texture]);
  const soma = useMemo(somaGeometry, []),
    dendrites = useMemo(morphology, []),
    axon = useMemo(() => tube(axonCurve, 0, 0, 220, true, 0, 63, axonRadius, 24), []);
  const branches = useMemo(
    () =>
      BRANCHES.map((b, i) =>
        tube(branchCurves[i], 0, 0, 90, true, b.start, b.end, branchRadius(b.diameter, i), 16),
      ),
    [],
  );
  const bulbs = useMemo(() => BRANCHES.map((b) => boutonGeometry(b.end)), []);
  const hitTube = useMemo(() => tube(axonCurve, 0.14, 0.14, 90, true), []);
  const probe = probePosition(model.probe);
  useEffect(
    () => () => {
      texture.dispose();
      material.dispose();
      somaMaterial.dispose();
      soma.dispose();
      axon.dispose();
      dendrites.forEach((g) => g.dispose());
      [...branches, ...bulbs, hitTube].forEach((g) => g.dispose());
    },
    [texture, material, somaMaterial, soma, axon, dendrites, branches, bulbs, hitTube],
  );
  useFrame(() => {
    for (let i = 0; i < COUNT; i++) {
      field[i * 4] = (model.v[i] + 85) / 130;
      field[i * 4 + 1] = model.m[i] ** 3 * model.h[i];
      field[i * 4 + 2] = model.n[i] ** 4;
      field[i * 4 + 3] = 1;
    }
    texture.needsUpdate = true;
  });
  const items = useMemo<Callout[]>(() => {
    if (!labels) return [];
    const V = (x: number, y: number, z = 0) => () => new THREE.Vector3(x, y, z);
    const dend = new THREE.Vector3(Math.cos(3.8), Math.sin(3.8), Math.sin(5 * 5) * 0.28).normalize();
    const list: Callout[] = [
      { id: "dend", text: T("DENDRITES|receive inputs on spines", "樹状突起|スパインで入力を受ける"), anchor: () => somaCentre.clone().addScaledVector(dend, 1.75), label: V(-7.9, 0.5), side: -1 },
      { id: "soma", text: T("SOMA|integrates; nucleus inside", "細胞体|入力を統合する（中に核）"), anchor: V(-4.2, -0.35, 0.6), label: V(-7.6, -1.75), side: -1 },
      { id: "hill", text: T("AXON HILLOCK|the spike starts here", "軸索小丘|活動電位はここで始まる"), anchor: () => axonCurve.getPointAt(0.035).add(new THREE.Vector3(0, -0.2, 0.05)), label: V(-2.4, -2.6), side: 1 },
      { id: "axon", text: T("AXON|carries the spike", "軸索|活動電位を運ぶ"), anchor: () => axonCurve.getPointAt(0.52).add(new THREE.Vector3(0, -0.13, 0.05)), label: V(1.6, -2.6), side: 1 },
      { id: "term", text: T("TERMINALS · BOUTONS|release transmitter", "軸索終末とボタン|伝達物質を放出する"), anchor: () => branchCurves[4].getPointAt(1).add(new THREE.Vector3(0.1, 0.1, 0)), label: V(9.4, 3.4), side: -1 },
    ];
    if (model.myelin.enabled) {
      const cells = model.membrane.cells.filter((c) => c.present);
      if (cells.length) {
        const c = cells[Math.min(1, cells.length - 1)];
        list.push({ id: "myelin", text: T("MYELIN · SCHWANN CELL|insulates the internode", "ミエリン（シュワン細胞）|節間を絶縁する"), anchor: () => axonCurve.getPointAt(((c.start + c.end) / 2) / 63).add(new THREE.Vector3(0, 0.22, 0.05)), label: V(-1.2, 2.2), side: 1 });
        const node = (c.end + 1) / 63;
        if (node < 1) list.push({ id: "node", text: T("NODE OF RANVIER|regenerates the spike", "ランヴィエ絞輪|活動電位を再生する"), anchor: () => axonCurve.getPointAt(node).add(new THREE.Vector3(0, 0.15, 0.05)), label: V(3.0, 2.2), side: 1 });
      }
    }
    // On a phone the whole cell is small: keep the four main structures, names only.
    if (narrow)
      return list
        .filter((c) => ["dend", "soma", "axon", "term", "myelin"].includes(c.id))
        .map((c) => ({ ...c, text: c.text.split("|")[0], label: c.id === "axon" ? V(1.6, -3.4) : c.id === "soma" ? V(-7.6, -3.2) : c.id === "term" ? V(8.2, -3.4) : c.label }));
    return list;
  }, [labels, narrow, model.myelin.enabled, model.membrane.cells]);
  return (
    <group>
      <mesh geometry={soma} material={somaMaterial} renderOrder={2} />
      {/* Nucleus and nucleolus, seen through the translucent cell body */}
      <mesh position={[-4.2, 0.05, 0.12]} scale={[0.36, 0.4, 0.3]}>
        <sphereGeometry args={[1, 48, 32]} />
        <meshPhysicalMaterial color="#2c5f70" roughness={0.5} sheen={0.6} sheenColor="#8fd0dc" clearcoat={0.3} />
      </mesh>
      <mesh position={[-4.13, 0.12, 0.33]} scale={0.1}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshPhysicalMaterial color="#173946" roughness={0.6} />
      </mesh>
      {dendrites.map((g, i) => (
        <mesh key={i} geometry={g} material={material} />
      ))}
      <mesh geometry={axon} material={material} />
      <MyelinSheaths model={model} onCell={onCell} cutaway={cutaway} />
      <mesh
        geometry={hitTube}
        onClick={(e) => {
          e.stopPropagation();
          let best = 0,
            dist = Infinity;
          for (let i = 0; i < 64; i++) {
            const d = axonCurve.getPointAt(i / 63).distanceToSquared(e.point);
            if (d < dist) {
              dist = d;
              best = i;
            }
          }
          onProbe(best);
        }}
        onPointerOver={() => (document.body.style.cursor = "crosshair")}
        onPointerOut={() => (document.body.style.cursor = "auto")}
      >
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      {BRANCHES.map((b, i) => (
        <group key={b.id}>
          <mesh
            geometry={branches[i]}
            material={material}
            onClick={(e) => {
              e.stopPropagation();
              onProbe(b.end);
            }}
          />
          <mesh
            position={branchCurves[i].getPointAt(1)}
            quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), branchCurves[i].getTangentAt(1))}
            geometry={bulbs[i]}
            material={material}
            onClick={(e) => {
              e.stopPropagation();
              onProbe(b.end);
            }}
          />
          {labels && (
            <Html
              position={branchCurves[i]
                .getPointAt(1)
                .add(new THREE.Vector3(0.44, 0.04, 0))}
              center
              zIndexRange={[2, 0]}
              className="terminal-label"
            >
              <button
                aria-label={T("Record terminal ", "終末を記録 ") + b.label}
                onClick={() => onProbe(b.end)}
              >
                {b.label}
              </button>
            </Html>
          )}
        </group>
      ))}
      <MembraneChannels model={model} />
      {ions && <IonParticles model={model} />}
      <mesh position={probe}>
        <sphereGeometry args={[0.21, 24, 12]} />
        <meshBasicMaterial
          color="#edf4c9"
          wireframe
          transparent
          opacity={0.18}
        />
      </mesh>
      {focus && <MembranePatch model={model} origin={probe} />}
      {!focus && <Callouts items={items} />}
      {!focus && (
        <>
          <Line
            points={[probe.toArray(), [probe.x, probe.y + 0.8, probe.z]]}
            color="#d2ddb0"
            lineWidth={0.8}
            transparent
            opacity={0.55}
          />
          <Html
            position={[probe.x, probe.y + 0.92, probe.z]}
            center
            zIndexRange={[2, 0]}
            className="probe-label"
          >
            {T("RECORDING SITE", "記録部位")}
          </Html>
        </>
      )}
    </group>
  );
}
function CameraRig({
  mode,
  focus,
  branchView,
  viewRevision,
  model,
}: {
  mode: "axon"|"synapse"|"circuit";
  focus: boolean;
  branchView: boolean;
  viewRevision: number;
  model: CableModel;
}) {
  const controls = useRef<any>(null);
  const { camera, size } = useThree();
  const destination = useRef({
    position: new THREE.Vector3(),
    target: new THREE.Vector3(),
    moving: false,
  });
  const initialized = useRef(false);
  useEffect(() => {
    const target = mode!=="axon" ? new THREE.Vector3(mode==="circuit"?(model.circuit.params.mode==="pair"?-2.5:model.circuit.params.mode==="chain"?-1:0):0,0,0) : focus
      ? probePosition(model.probe).add(new THREE.Vector3(-0.35, 0.95, 0))
      : branchView
        ? new THREE.Vector3(7.6, 0, 0)
        : new THREE.Vector3(0.6, 0.05, 0);
    const aspect = size.width / size.height;
    const distance = mode!=="axon" ? Math.max(mode==="synapse"?(focus?4.6:9):(model.circuit.params.mode==="pair"?8:11),(mode==="synapse"?(focus?4.5:8):(model.circuit.params.mode==="pair"?6:10))/aspect) : focus
      ? Math.max(3.0, 3.6 / Math.min(1.4, aspect))
      : branchView
        ? Math.max(size.width < 600 ? 10.5 : 7, 6 / aspect)
        : Math.max(
            12.5,
            (aspect < 1 ? 15.5 : 19) /
              (2 * Math.tan((34 * Math.PI) / 360) * aspect),
          );
    destination.current = {
      position: target
        .clone()
        .add(new THREE.Vector3(0, focus ? 0.55 : 1.5, distance)),
      target,
      moving: true,
    };
    if (
      !initialized.current ||
      matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      camera.position.copy(destination.current.position);
      controls.current?.target.copy(target);
      controls.current?.update();
      destination.current.moving = false;
    }
    initialized.current = true;
  }, [mode, focus, branchView, viewRevision, model, camera, size.width, size.height]);
  useFrame((_, dt) => {
    const d = destination.current;
    if (!d.moving || !controls.current) return;
    const a = 1 - Math.exp(-6 * dt);
    camera.position.lerp(d.position, a);
    controls.current.target.lerp(d.target, a);
    if (camera.position.distanceTo(d.position) < 0.005) d.moving = false;
    controls.current.update();
  });
  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.09}
      minDistance={1.25}
      maxDistance={70}
      enablePan
      rotateSpeed={0.5}
      onStart={() => (destination.current.moving = false)}
    />
  );
}
function DepthDust() {
  const points = useMemo(() => {
    const a = new Float32Array(220 * 3);
    for (let i = 0; i < 220; i++) {
      a[i * 3] = Math.sin(i * 54.21) * 18;
      a[i * 3 + 1] = Math.cos(i * 21.67) * 10;
      a[i * 3 + 2] = -3 - Math.abs(Math.sin(i * 3.81)) * 10;
    }
    return a;
  }, []);
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[points, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#5f8592"
        size={0.03}
        transparent
        opacity={0.35}
        depthWrite={false}
      />
    </points>
  );
}
class SceneBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="webgl-error">
        {T("The 3D view needs WebGL 2. Enable hardware acceleration or try a current browser. The model and voltage trace remain available.", "3D 表示には WebGL 2 が必要です。ハードウェアアクセラレーションを有効にするか、新しいブラウザでお試しください。モデルと電位の記録はそのまま使えます。")}
      </div>
    ) : (
      this.props.children
    );
  }
}
export default function NeuronScene(props: Props) {
  const small = typeof window !== "undefined" && window.innerWidth < 700;
  return (
    <SceneBoundary>
      <Canvas
        dpr={[1, 1.75]}
        camera={{ position: [0.3, 2.1, 19.3], fov: 34, near: 0.1, far: 90 }}
        gl={{
          antialias: false,
          alpha: true,
          powerPreference: "high-performance",
        }}
        fallback={
          <div className="webgl-error">
            {T("WebGL is unavailable. The live model and graph remain available below.", "WebGL を利用できません。モデルとグラフは下で引き続き使えます。")}
          </div>
        }
      >
        <fog attach="fog" args={["#0b141d", 24, 54]} />
        <ambientLight intensity={0.18} />
        <hemisphereLight args={["#c7e5ef", "#172332", .55]} />
        <directionalLight position={[-4, 5, 8]} intensity={1.8} color="#d6eef6" />
        <directionalLight position={[3, -2, -6]} intensity={1.6} color="#7fd0c2" />
        <pointLight position={[4, -2, 5]} intensity={16} color="#8fcfb8" />
        <pointLight position={[-6, 3, -2]} intensity={22} color="#649dd9" />
        <Suspense fallback={null}>
          <Environment frames={1} resolution={128}>
            <Lightformer intensity={2.5} color="#e5f3ed" position={[0,5,-4]} rotation={[Math.PI/2,0,0]} scale={[14,5,1]} />
            <Lightformer intensity={1.5} color="#8fc1e0" position={[-7,1,3]} rotation={[0,Math.PI/2,0]} scale={[5,7,1]} />
            <Lightformer intensity={1} color="#e5c8a0" position={[8,2,2]} rotation={[0,-Math.PI/2,0]} scale={[3,6,1]} />
            <Lightformer intensity={1.2} color="#7fd6c4" position={[0,-3,-6]} rotation={[0,0,0]} scale={[12,4,1]} />
          </Environment>
          {props.mode==="axon"?<Neuron {...props}/>:props.mode==="synapse"?<SynapticWorld closeup={props.focus} labels={props.labels} ions={props.ions} model={props.model} selected={props.selectedContact} onSelect={props.onContact}/>:<CircuitWorld labels={props.labels} model={props.model} selected={props.selectedContact} onSelect={props.onContact}/>}
          <DepthDust />
          <EffectComposer multisampling={small ? 0 : 4}>
            <Bloom
              intensity={0.55}
              luminanceThreshold={0.72}
              luminanceSmoothing={0.3}
              mipmapBlur
            />
            <Vignette eskil={false} offset={0.28} darkness={0.55} />
            <ToneMapping mode={ToneMappingMode.AGX} />
          </EffectComposer>
        </Suspense>
        <CameraRig
          mode={props.mode}
          focus={props.focus}
          branchView={props.branchView}
          viewRevision={props.viewRevision}
          model={props.model}
        />
        <AdaptiveDpr pixelated />
      </Canvas>
    </SceneBoundary>
  );
}
