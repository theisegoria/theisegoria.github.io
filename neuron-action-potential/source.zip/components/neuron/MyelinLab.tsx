import { useState } from 'react';
import { CableModel } from '@/lib/neuron/model.mjs';

type Trial = { arrivals: number[]; delay: number | null };
export function trial(model: CableModel, intact = false): Trial {
  const test = new CableModel();
  test.params = { ...model.params, current: 0 };
  test.configureMyelin({ ...model.myelin, removed: intact ? [] : model.myelin.removed });
  test.pulse();
  for (let i = 0; i < 4000; i++) test.step();
  const a = test.firstArrival;
  return { arrivals: Array.from(a.slice(0,64)), delay: Number.isFinite(a[63]) && Number.isFinite(a[0]) ? a[63]-a[0] : null };
}
export default function MyelinLab({ model, onChange, onInspect }: {
  model: CableModel; onChange: (config: Partial<CableModel['myelin']>) => void; onInspect: () => void;
}) {
  const [comparison, setComparison] = useState<{ selected: Trial; intact: Trial; key: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const c = model.myelin;
  const key = JSON.stringify([c,model.params.gNa,model.params.gK]);
  const result = comparison?.key === key ? comparison : null;
  const cells = model.membrane.cells;
  const toggle = (id: number) => onChange({removed: c.removed.includes(id) ? c.removed.filter(x=>x!==id) : [...c.removed,id]});
  const compare = () => {
    setBusy(true);
    const experiment = new CableModel();
    experiment.params = {...model.params};
    experiment.configureMyelin({...model.myelin,removed:[...model.myelin.removed]});
    // Yield a paint before the bounded numerical experiment.
    setTimeout(() => { try { setComparison({ selected: trial(experiment), intact: trial(experiment,true), key }); } finally { setBusy(false); } }, 30);
  };
  const delay = (v: number|null) => v === null ? 'No arrival within 40 ms' : `${v.toFixed(2)} ms`;
  return <section className="myelin-panel" aria-labelledby="myelin-title">
    <p className="eyebrow">MYELIN & PROPAGATION</p>
    <div className="section-heading"><h2 id="myelin-title">Build the insulation.</h2><button onClick={onInspect}>Inspect axon ↗</button></div>
    <label className="myelin-enable"><input type="checkbox" checked={c.enabled} onChange={e=>onChange({enabled:e.target.checked,removed:[]})}/> Myelinated axon</label>
    <p>Each sheath represents one Schwann cell. Gaps expose nodes where the spike regenerates.</p>
    <fieldset disabled={!c.enabled || busy}>
      <label htmlFor="internode-length">Sheath length <output>{c.length} compartments</output></label>
      <input id="internode-length" type="range" min="2" max="10" step="1" value={c.length} onChange={e=>onChange({length:+e.target.value,removed:[]})}/>
      <label htmlFor="node-gap">Exposed spacing <output>{c.gap} compartment{c.gap===1?'':'s'}</output></label>
      <input id="node-gap" type="range" min="1" max="4" step="1" value={c.gap} onChange={e=>onChange({gap:+e.target.value,removed:[]})}/>
      <div className="myelin-actions"><button onClick={()=>onChange({removed:[]})}>Add all</button><button onClick={()=>onChange({removed:cells.map(x=>x.id)})}>Remove all</button></div>
      <div className="cell-toggles" aria-label="Individual Schwann cells">{cells.map(cell=><button key={cell.id} aria-label={`Schwann cell ${cell.id+1}`} aria-pressed={cell.present} title={`${cell.present?'Remove':'Add'} cell ${cell.id+1}`} onClick={()=>toggle(cell.id)}>{cell.id+1}</button>)}</div>
      <p className="science-note">{cells.filter(x=>x.present).length} / {cells.length} cells present · tap a number or a sheath to remove it. Length and spacing changes rebuild the layout.</p>
      <button className="primary-button" onClick={compare}>{busy?'Measuring…':'Compare with intact myelin'}</button>
    </fieldset>
    {result && <div className="myelin-result" role="status">
      <div><span>Selected layout</span><b>{delay(result.selected.delay)}</b></div>
      <div><span>All sheaths intact</span><b>{delay(result.intact.delay)}</b></div>
      <svg viewBox="0 0 300 150" role="img" aria-label="First spike arrival versus position along the parent axon. Gold is selected; grey is intact myelin.">
        {[0,10,20,30,40].map(ms=><g key={ms}><line x1="30" x2="280" y1={120-ms*2.5} y2={120-ms*2.5} stroke="#30414b"/><text x="4" y={124-ms*2.5} fill="#b4c2cc" fontSize="10">{ms}</text></g>)}
        {[result.intact,result.selected].map((r,j)=> <path key={j} d={r.arrivals.map((t,i)=>Number.isFinite(t)?`${i===0 || !Number.isFinite(r.arrivals[i-1])?'M':'L'}${30+i/63*250},${120-t*2.5}`:'').join(' ')} fill="none" stroke={j?'#e8bb78':'#92a4ae'} strokeWidth="2"/>)}
        <text x="30" y="143" fill="#b4c2cc" fontSize="11">Hillock</text><text x="210" y="143" fill="#b4c2cc" fontSize="11">Branch point</text><text x="30" y="12" fill="#b4c2cc" fontSize="11">Arrival from stimulus (ms)</text>
      </svg>
      <p className="science-note">Gold: selected · grey: intact. Delay is hillock → branch point. Missing line segments indicate no upward 0 mV crossing within 40 ms. Both trials use the same 1 ms pulse and channel conductances.</p>
    </div>}
    <p className="science-note">Geometry edits restart the recording. Sheath removal raises capacitance and leak while internodal channels remain sparse. Turning myelination off restores the original unmyelinated cable. Dimensions are illustrative; gaps are enlarged for inspection.</p>
    <a className="science-link" href="https://pmc.ncbi.nlm.nih.gov/articles/PMC1331199/" target="_blank" rel="noreferrer">Demyelination & conduction · model background ↗</a>
  </section>;
}
