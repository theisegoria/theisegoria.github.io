import { CableModel, BRANCHES } from "@/lib/neuron/model.mjs";
import VoltageGraph, { BRANCH_COLORS } from "./VoltageGraph";
export default function BranchSignals({
  model,
  onProbe,
  onView,
  onScenario,
  onPause,
}: {
  model: CableModel;
  onProbe: (i: number) => void;
  onView: () => void;
  onPause: () => void;
  onScenario: (mode: "rest" | "single" | "train") => void;
}) {
  const fork = model.firstArrival[63];
  return (
    <section className="branches-panel" aria-labelledby="branches-title">
      <p className="eyebrow">03 / BRANCHING & REGENERATION</p>
      <div className="section-heading">
        <h2 id="branches-title">One spike. Separate arrivals.</h2>
        <button onClick={onView}>View branches ↗</button>
      </div>
      <p>
        Local current excites each daughter branch; its own Na⁺ channels
        regenerate the spike. Similar peak voltages do not imply identical
        voltage at the same instant.
      </p>
      <div className="scenario-buttons" aria-label="Experiments">
        <button onClick={() => onScenario("rest")}>Rest</button>
        <button onClick={() => onScenario("single")}>Send one spike</button>
        <button onClick={() => onScenario("train")}>Spike train</button>
        <button onClick={onPause}>
          {model.paused ? "Resume experiment" : "Pause experiment"}
        </button>
      </div>
      <VoltageGraph model={model} branches />
      <div
        className="branch-table"
        role="table"
        aria-label="Terminal recordings"
      >
        <div role="row" className="branch-table-head">
          <span role="columnheader">Terminal</span>
          <span role="columnheader">Voltage</span>
          <span role="columnheader">Arrival¹</span>
          <span role="columnheader">After fork¹</span>
        </div>
        {BRANCHES.map((b, i) => {
          const arrival = model.firstArrival[b.end];
          return (
            <div role="row" key={b.id}>
              <span role="cell">
                <button
                  aria-label={"Record terminal " + b.label}
                  aria-pressed={model.probe === b.end}
                  onClick={() => onProbe(b.end)}
                >
                  <i style={{ background: BRANCH_COLORS[i] }} />
                  {b.label}
                </button>
              </span>
              <span role="cell">
                {model.v[b.end].toFixed(1)} <small>mV</small>
              </span>
              <span role="cell">
                {Number.isFinite(arrival) ? arrival.toFixed(2) + " ms" : "—"}
              </span>
              <span role="cell">
                {Number.isFinite(arrival) && Number.isFinite(fork)
                  ? "+" + (arrival - fork).toFixed(2) + " ms"
                  : "—"}
              </span>
            </div>
          );
        })}
      </div>
      <p className="science-note">
        ¹ First upward crossing of 0 mV since reset. Traces span 40 ms. A
        single-spike experiment automatically pauses at 40 ms. These five
        illustrative branches have different lengths and diameters. Real
        branching axons can also delay or fail to conduct; matching terminal
        waveforms or arrival times is not guaranteed.
      </p>
      <a
        className="science-link"
        href="https://doi.org/10.1371/journal.pcbi.0030079"
        target="_blank"
        rel="noreferrer"
      >
        Branch propagation & channel noise · Faisal & Laughlin, 2007 ↗
      </a>
    </section>
  );
}
