"use client";
import * as THREE from 'three';
// Use Three's physical lighting and tone mapping; voltage remains a data field,
// never an sRGB texture. Surface detail is a presentation layer only.
export function makeVoltageMaterial(texture: THREE.DataTexture) {
  const material = new THREE.MeshPhysicalMaterial({
    color:'#3d727b', roughness:.4, metalness:0, clearcoat:.25,
    clearcoatRoughness:.3, sheen:.22, sheenColor:new THREE.Color('#86b2bb'),
  });
  material.onBeforeCompile = shader => {
    shader.uniforms.voltageMap={value:texture};
    shader.uniforms.mapWidth={value:texture.image.width};
    shader.vertexShader='attribute float aCable; varying float vCable; varying vec3 vSurface;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvCable=aCable; vSurface=position;');
    shader.fragmentShader='uniform sampler2D voltageMap; uniform float mapWidth; varying float vCable; varying vec3 vSurface;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
      vec4 state=texture2D(voltageMap,vec2((vCable+.5)/mapWidth,.5));
      float dep=smoothstep(.22,.88,state.r);
      float recovery=1.-smoothstep(.02,.17,state.r);
      float grain=sin(vSurface.x*46.+sin(vSurface.y*29.))*sin(vSurface.z*39.+vSurface.y*23.);
      vec3 resting=mix(vec3(.08,.23,.27),vec3(.12,.15,.32),recovery*.5);
      diffuseColor.rgb=mix(resting,vec3(.23,.75,.48),dep)*(1.+grain*.035);`);
    shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\ntotalEmissiveRadiance+=vec3(.15,.7,.35)*dep*.48;');
  };
  material.customProgramCacheKey=()=> 'membrane-physical-voltage-v1';
  return material;
}
