"use client";
import * as THREE from "three";
export function makeVoltageMaterial(texture: THREE.DataTexture) {
  return new THREE.ShaderMaterial({
    uniforms: {
      voltageMap: { value: texture },
      mapWidth: { value: texture.image.width },
    },
    vertexShader: `
 attribute float aCable; varying float vCable; varying vec3 vNormal; varying vec3 vView; varying vec2 vUv;
 void main(){vCable=aCable;vUv=uv;vec4 p=modelViewMatrix*vec4(position,1.);vNormal=normalize(normalMatrix*normal);vView=normalize(-p.xyz);gl_Position=projectionMatrix*p;}`,
    fragmentShader: `
 uniform sampler2D voltageMap; uniform float mapWidth; varying float vCable; varying vec3 vNormal; varying vec3 vView; varying vec2 vUv;
 void main(){ vec4 state=texture2D(voltageMap,vec2((vCable+.5)/mapWidth,.5));
 float dep=smoothstep(.22,.88,state.r); float recovery=1.-smoothstep(.02,.17,state.r);
 vec3 base=mix(vec3(.075,.19,.235),vec3(.32,.61,.56),.24);
 base=mix(base,vec3(.19,.23,.51),recovery*.48);
 vec3 n=normalize(vNormal);float light=.28+.65*max(dot(n,normalize(vec3(-.3,.7,.9))),0.);
 float rim=pow(1.-abs(dot(n,normalize(vView))),2.7);
 float grain=sin(vUv.x*220.+sin(vUv.y*50.)*2.)*.015;
 vec3 color=base*(light+grain)+vec3(.2,.52,.60)*rim*.57;
 color=mix(color,vec3(.45,1.25,.87)*(light+.32)+vec3(.3,.65,.39)*rim,dep);
 gl_FragColor=vec4(color,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 }`,
  });
}
