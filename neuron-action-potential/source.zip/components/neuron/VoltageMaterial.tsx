"use client";
import * as THREE from 'three';
// Use Three's physical lighting and tone mapping; voltage remains a data field, never an sRGB texture.
// Surface detail is a presentation layer only. Colour follows the legend ramp (-80 violet-blue,
// -65 teal, +40 mint). The depolarisation wave glows where sodium channels are open (m^3 h), and
// a faint amber afterglow marks open potassium channels (n^4) during repolarisation.
// A wrapped, back-scattered rim term imitates light diffusing through a living membrane.
export function makeVoltageMaterial(texture: THREE.DataTexture, opts: {translucent?: boolean} = {}) {
  const material = new THREE.MeshPhysicalMaterial({
    color:'#3d727b', roughness:.46, metalness:0, clearcoat:.35,
    clearcoatRoughness:.35, sheen:.6, sheenRoughness:.5, sheenColor:new THREE.Color('#9fd6d2'),
    ...(opts.translucent ? {transparent:true, opacity:.72} : {}),
  });
  material.onBeforeCompile = shader => {
    shader.uniforms.voltageMap={value:texture};
    shader.uniforms.mapWidth={value:texture.image.width};
    shader.vertexShader='attribute float aCable; varying float vCable; varying vec3 vSurface;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvCable=aCable; vSurface=position;');
    shader.fragmentShader='uniform sampler2D voltageMap; uniform float mapWidth; varying float vCable; varying vec3 vSurface;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
      vec4 state=texture2D(voltageMap,vec2((vCable+.5)/mapWidth,.5));
      float dep=smoothstep(.22,.88,state.r);
      float recovery=1.-smoothstep(.02,.17,state.r);
      float grain=sin(vSurface.x*46.+sin(vSurface.y*29.))*sin(vSurface.z*39.+vSurface.y*23.);
      float mottle=sin(vSurface.x*7.3+vSurface.z*5.1)*sin(vSurface.y*6.7-vSurface.x*3.1);
      vec3 resting=mix(vec3(.07,.25,.29),vec3(.13,.16,.36),recovery*.6);
      diffuseColor.rgb=mix(resting,vec3(.30,.84,.56),dep)*(1.+grain*.03+mottle*.06);`);
    shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
      vec3 vdir=normalize(vViewPosition);
      float facing=abs(dot(normal,vdir));
      float rim=pow(1.-facing,2.2);
      float naOpen=clamp(state.g*4.,0.,1.);
      float kOpen=clamp(state.b*2.5,0.,1.);
      totalEmissiveRadiance+=mix(vec3(.05,.22,.25),vec3(.25,.9,.6),dep)*rim*.55;
      totalEmissiveRadiance+=vec3(.15,.7,.35)*dep*.42;
      totalEmissiveRadiance+=vec3(.55,1.15,.85)*naOpen*1.35;
      totalEmissiveRadiance+=vec3(.55,.33,.08)*kOpen*(1.-dep)*.35;`);
  };
  material.customProgramCacheKey=()=> 'membrane-physical-voltage-v2'+(opts.translucent?'-t':'');
  return material;
}
