# Membrane: an interactive action potential

A complete client-side React / Three.js / React Three Fiber / Drei app. A 144-compartment branched Hodgkin–Huxley cable drives the voltage colour, gates, ions and live graph. No prerecorded spike timeline or hosted API is used.

## Run

Node.js 22.13 or newer is required.

```sh
npm ci
npm run dev
```

Open the printed local address. `npm run build` creates portable static files in `dist/`; `npm start` previews the production build. Relative asset URLs support both Sites and a GitHub Pages subdirectory.

## Verify

```sh
npm test
npm run typecheck
npm run build
```

Numerical tests cover rest, spiking, forward propagation, sodium blockade, firing-rate response to current, halved-step convergence, parameter extremes, pause/reset and a stimulus pulse. Additional tests verify area-weighted axial-current balance, distinct terminal arrivals, branch timestep convergence, terminal sodium blockade, sampled equilibrium gate probabilities, repeatable seeds and pause/reset. UI validation includes desktop and mobile layouts, WebMCP settings and invalid-input rejection, channel inspection, pause/resume, camera controls, sliders and visibility toggles.

## Components

- `lib/neuron/model.mjs`: fixed-step membrane solver, gates, ionic currents, integrated flux and bounded trace buffers. Its `.d.mts` declaration exposes the typed interface.
- `lib/neuron/topology.mjs`: conservative branched cable graph, relative dimensions and recording labels.
- `lib/neuron/channels.mjs`: seeded two-state stochastic HH gates for 32 Na and 32 K channels at the selected voltage.
- `components/neuron/ChannelPopulation.tsx`: individual open, closed and unavailable channel states. This finite sample does not feed noise into the deterministic cable.
- `components/neuron/BranchSignals.tsx`: five simultaneous terminal traces and first upward 0 mV arrival times; rest, single-pulse and continuous-current experiments.
- `lib/neuron/geometry.ts`: soma surface, tapered dendrites, continuous axon and branching terminals.
- `components/neuron/NeuronScene.tsx`: instanced channels and ions, orbit camera, lighting and bloom.
- `components/neuron/VoltageMaterial.tsx`: GLSL membrane shader sampling a live 144-pixel voltage texture.
- `components/neuron/VoltageGraph.tsx`: canvas oscilloscope, with the hillock and selected compartment on the same time axis.
- `components/neuron/MembraneInset.tsx`: annotated cross-section of the same recording site.
- `components/neuron/SimulationControls.tsx`: accessible current, conductance, time and display controls.
- `lib/neuron/webmcp.ts`: optional, feature-detected tools backed by the same state as the UI.
- `app/page.tsx`: experiment composition; `client-entry.tsx` is the static application entry.

## Interpretation

Classic squid-axon kinetics at 6.3 °C are placed in an illustrative multipolar morphology. This is not a calibrated model of a specific human neuron. Current is applied continuously to the first four compartments; a pulse adds 35 μA/cm² for 1 ms. The 0.01 ms integration step is independent of display refresh and speed. At 1×, eight simulated milliseconds pass per wall-clock second. Long background-tab delays are capped rather than replayed.

Capacitance is 1 μF/cm². Sodium, potassium and leak reversal potentials are +50, −77 and −54.387 mV. Leak conductance is 0.3 mS/cm² and nearest-neighbour coupling is 4 mS/cm², with sealed ends. Five daughter branches contain 18, 14, 12, 16 and 20 compartments, with relative diameters .36, .34, .32, .35 and .33. Equal segment lengths are assumed. Membrane areas scale with diameter; axial conductance scales with diameter squared. Junction edge currents are applied with opposite signs before division by membrane area. Default maximal sodium/potassium conductances are 120/36 mS/cm². Channel gates use exact frozen-voltage exponential updates; voltage uses an exponential frozen-conductance update with explicit axial current.

Each segment has its own V, m, h and n. Pore width shows a scaled ensemble open fraction (m³h or n⁴). Sodium influx and potassium efflux can overlap, as they do in the underlying model. Visible ion transport integrates the signed ionic current, scaled and capped for readability; particle counts do not represent concentrations. Dendrites and soma use the first compartment's voltage, while each terminal and daughter segment uses its own integrated voltage. Geometry, channel size, propagation distance and particle speed are not to scale. Rest and the travelling spikes emerge from the model.

References: [Hodgkin & Huxley (1952)](https://doi.org/10.1113/jphysiol.1952.sp004764) and [Neuronal Dynamics, chapter 2.2](https://neuronaldynamics.epfl.ch/online/Ch2.S2.html). The latter explains the formulation; its cortical parameter table is not used as the classic squid-axon parameter set.

Branch/patch interpretation: a shared local membrane voltage does not synchronize every gate. Daughter branches regenerate action potentials locally; matching peaks do not imply equal voltage at the same instant. Branch dimensions are illustrative and conduction times are not calibrated to a specific neuron. Fixed reversal potentials assume maintained gradients; slow gradient-regulating pumps and metabolism are omitted. Synaptic transmission is described below. See [Faisal & Laughlin (2007)](https://doi.org/10.1371/journal.pcbi.0030079).

## Schwann cells and myelin

Enable **Myelinated axon**, change sheath length (2–10 compartments) and exposed
spacing (1–4 compartments), or add/remove individual numbered Schwann cells.
The sleeves follow the same trunk-compartment layout used by the solver.
**Inspect axon** and **Myelin cutaway** reveal the curved sleeves and illustrative
layers; cutaway changes presentation only. Node markers sample local ionic flux.
The physical membrane material samples the voltage field; studio environment
lighting is generated locally, with no external HDR download.

Geometry changes clear recordings and restart at rest. Existing rest/pulse/train
experiments preserve the selected myelin layout. Global reset restores the
original unmyelinated model. **Compare with intact myelin** runs two matched
40 ms single-pulse experiments at the current Na/K conductances: selected layout
versus all sheaths intact at the same spacing. The chart shows first upward
0 mV crossings; delay is hillock to branch point. No crossing within 40 ms is
reported as no arrival, not an infinite delay or a measured clinical block.

This is an illustrative single-cable extension of the existing squid-kinetics
model, not a calibrated peripheral nerve. Trunk internodes use effective
capacitance 0.2 μF/cm², leak 0.03 mS/cm², leak reversal −65 mV, and 1% of the
original voltage-gated conductance densities. Removing a sheath restores
capacitance to 1 and leak to 0.3, retaining sparse internodal channels; it does
not simulate slow channel redistribution or Schwann-cell metabolism. Exposed
nodes, the hillock and daughter branches retain the existing HH parameters.
The optional myelin scenario is a peripheral-axon teaching abstraction applied
to the existing illustrative morphology; Schwann cells are not CNS myelin cells.

The voltage update uses C dV/dt = I_injected + I_axial − I_Na − I_K − I_leak.
Axial-current conservation is unchanged. Myelinated runs substep at ≤0.0025 ms
for the lower capacitance. Tests compare 0.00125 ms steps and exercise geometry
limits, intact/focal/extensive loss, quiet rest, reset and invalid inputs. Lengths
are relative compartments, not micrometres; no m/s velocity claim is made.

Mechanistic references: [Koles & Rasminsky, 1972](https://pmc.ncbi.nlm.nih.gov/articles/PMC1331199/)
for capacitance/conductance changes with demyelination and
[Arancibia-Cárcamo et al., 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC5313058/)
for node/internode effects on timing. Parameters above are illustrative, not fits
to either study. Procedural geometry is original and not an anatomical scan.

## Synapses and small circuits

**Synaptic cleft** opens a model-driven 3D cutaway. **Receptor close-up** zooms into
channels; orbit, zoom and reset remain available. **Neural circuit** shows two,
three or five cells with selectable numbered contacts. Changing a contact's
location changes its compartment and connection endpoint. Source morphology is
illustrative; the other cells each have a soma and four serial active dendritic
compartments (20 additional HH compartments total), with axial coupling 3 mS/cm².
Cell geometry is not an anatomical reconstruction. Link markers indicate release
activity, not measured propagation velocity through the displayed curves.

`lib/neuron/circuit.mjs` advances on the same fixed timestep as the cable. Each
source contact reads its own actual terminal voltage through an interpolated
delay history. Other contacts read their source cell's soma voltage. The delay
control adds 0–8 ms; the five source branches already have distinct conduction
times. Geometry, camera and particles never advance the solver. Pause freezes
state-driven animation and recordings together.

The chemical teaching model uses ms and µM:

- Calcium activation relaxes toward `q∞ = 1/(1+exp(-(V+20)/6))` with τ=0.25 ms.
  Evoked influx is `max(0, 3q(80−V)/100 − Jrest)`; basal pumping balances resting
  influx. Free calcium relaxes with τ=5 ms toward `0.05 + 5 Jinflux`.
- Release hazard is `0.7 × drive × (1+2F) × x⁴/(0.65⁴+x⁴)`, where
  `x=max(Ca−0.05,0)`. Presynaptic spikes increment facilitation F by
  `0.15(1−F)`; it decays over 80 ms. Eight vesicles cycle between ready and
  recycling pools. Recovery defaults to 80 ms. Each release adds 40 µM to the
  cleft. Deterministic mode uses expected transitions; probabilistic mode draws
  seeded binomial transitions for integer vesicles. Neither mode creates vesicles.
- Receptor states are unbound R, bound closed B, open O and desensitized D.
  Rates are R→B `0.03C`, B→R `0.3`, B→O `1.5`, O→B `0.4`, B→D `0.07`,
  D→B `0.008` per ms. Bound receptors retain one transmitter. Total receptor
  concentration is `0.2 × density` µM. Frozen-rate probability transfers preserve
  nonnegativity and unit total probability; binding is limited by available ligand.
- Cleft C exchanges with a perisynaptic pool S ten times its volume at rate
  `0.4(C−S)`. Uptake has Km=20 µM and Vmax=8 in the cleft, 2 in the surround,
  scaled by transporter capacity. Optional enzyme degradation has Vmax=8 in
  the cleft, scaled by enzyme clearance. Surround escape is 0.015/ms.
  Saturating losses use bounded exponential updates. The conservation check is
  `C + 10S + 0.2 density (1−R) + uptake + degradation + escape = released dose`.
- Synaptic conductance is `gmax × density × weight × O`, with gmax=1.8 for
  excitation and 12 for inhibition, and reversal 0 or −75 mV. Signed inward
  current `g(E−V)` enters the selected postsynaptic compartment's voltage equation.
  This permits excitation, shunting/hyperpolarization, spatial summation and
  local active regeneration. Fixed reversal potentials assume maintained gradients.
- Optional illustrative STDP uses pre/post traces with 20 ms decay. A pre spike
  subtracts `0.018 × postTrace`; a post spike adds `0.015 × preTrace`. Excitatory
  weights are bounded to 0.05–3. A postsynaptic crossing is delivered to the rule
  one integration step later. Reset restores initial weights.

The continuous transmitter states are well-mixed compartments. Gold particles
represent concentration and dispersion; violet entry tracks integrated calcium
influx; blue particles track uptake; rose products track degradation. Gold markers
leaving receptors track cumulative dissociation. Vesicle size shows available
inventory, while release activity deforms a fusing vesicle. Receptor pore expansion
shows open probability; bound markers show occupancy. These are population
visual encodings, not molecule-resolved Brownian paths or calibrated dimensions.

Plots include membrane voltage, calcium, cleft/surround concentration, signed
synaptic current, all four receptor probabilities, vesicle availability, weights,
transmitter fate and a spike raster. Recordings retain 240 ms; the raster is
bounded to 800 crossings. The live source voltage trace is terminal A.

Experiments preserve the chosen membrane/myelin settings:

- **Does the message arrive?**: one 1 ms source pulse, observed for 90 ms.
- **One pulse vs a burst**: matched 130 ms runs with one pulse or five pulses
  spaced 12 ms apart; compares spikes, peak cleft concentration, depletion and dose.
- **Can inhibition stop it?**: feedforward topology plus a direct 1 ms, 70 µA/cm²
  interneuron pulse at the selected time (default 15 ms); observed for 90 ms.
- **Repeated activity & learning**: six source pulses spaced 30 ms apart with
  plasticity enabled, observed for 220 ms.
- **Repeat 12 stochastic trials**: independent 80 ms single-pulse runs with
  consecutive seeds and matched settings, without changing the live recording.

Tests cover chemical mass balance, receptor probabilities, vesicle inventory,
no-stimulus/release/binding controls, downstream spikes, timestep convergence,
inhibition, relay/feedback, seeded successes/failures, plasticity, delays,
myelin conduction loss preventing release, and reset. These establish internal
consistency, not biological validation. Enzyme clearance is off by default; the
model deliberately does not identify a specific transmitter/receptor subtype.

Mechanistic context: [Destexhe et al., kinetic synaptic models](https://neurocompute.cnrs.fr/abstracts/synapse/)
and [Bi & Poo, 1998, spike timing and plasticity](https://pmc.ncbi.nlm.nih.gov/articles/PMC6793365/).
The above constants are teaching choices, not parameter fits to those studies.
